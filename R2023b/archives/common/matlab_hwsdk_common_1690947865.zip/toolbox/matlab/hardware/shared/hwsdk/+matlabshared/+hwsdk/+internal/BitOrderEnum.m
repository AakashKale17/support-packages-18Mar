
%   Copyright 2017 The MathWorks, Inc.

classdef BitOrderEnum
    enumeration
        msbfirst, lsbfirst
    end
 end