
%   Copyright 2017 The MathWorks, Inc.

classdef EndiannessEnum
    enumeration
        littleendian, bigendian
    end
 end