classdef (Hidden) StringValidator < matlabshared.hwsdk.internal.BasePinValidator
% Handles string validations

%   Copyright 2023 The MathWorks, Inc.

    methods (Hidden)
        function validateI2CPinType(~, i2cPinsArray)
            for i = 1:numel(i2cPinsArray)
                assert(isstring(i2cPinsArray(i).SCLPin));
                assert(isstring(i2cPinsArray(i).SDAPin));
            end
        end

        function validateSPIPinType(~, spiPinsArray)
            for i = 1:numel(spiPinsArray)
                assert(isstring(spiPinsArray(i).SCLPin));
                assert(isstring(spiPinsArray(i).SDIPin));
                assert(isstring(spiPinsArray(i).SDOPin));
            end
        end

        function pinString = renderPinsToStringImpl(~, pinCell)
            charPins = all(cellfun(@ischar, pinCell));
            if charPins
                pinString = matlabshared.hwsdk.internal.renderCellArrayOfCharVectorsToCharVector(pinCell, ', ');
            else
                pinString = matlabshared.hwsdk.internal.renderCellArrayOfCharVectorsToCharVector(cellstr(pinCell), ', ');
            end
        end

        function charPin = getPinForErrorDisplay(~, pin)
            charPin = char(pin);
        end

        function validatePWMPinType(~, pins)
            assert(isstring(pins), ...
                   'ASSERT: getAvailablePWMPinsImpl must return a row based array of strings');
        end

        function pin = validateControllerPin(~, pin, validPins, boardName)
            assert(isstring(validPins), 'validateControllerPin: validPins must be a string array');
            assert(ischar(boardName) || isstring(boardName), 'validateControllerPin: boardName must be a string');
            if ischar(pin)
                pin = string(pin);
            end

            if isscalar(pin) && isstring(pin)
                iPin = find(strcmpi(pin, validPins));
                if ~isempty(iPin)
                    pin = validPins(iPin);
                    return;
                else
                    matlabshared.hwsdk.internal.localizedError('MATLAB:hwsdk:general:invalidPinNumber', char(boardName), char(matlabshared.hwsdk.internal.renderArrayOfPinStringsToRangedString(validPins)));
                end
            end
            matlabshared.hwsdk.internal.localizedError('MATLAB:hwsdk:general:invalidPinTypeString',  char(matlabshared.hwsdk.internal.renderArrayOfPinStringsToRangedString(validPins)));
        end

        function bus = validateI2CBus(~, bus, availableI2CBusIDs)
            assert(isstring(availableI2CBusIDs), 'validateI2CBus: availableI2CBusIDs is expected to be a string vector');
            buses = matlabshared.hwsdk.internal.renderArrayOfStringsToString(availableI2CBusIDs);
            try
                if ~((isstring(bus) && isscalar(bus)) || ischar(bus))
                    matlabshared.hwsdk.internal.localizedError('MATLAB:hwsdk:general:invalidBusTypeString', 'I2C', buses);
                elseif ~ismember(string(bus), availableI2CBusIDs)
                    matlabshared.hwsdk.internal.localizedError('MATLAB:hwsdk:general:invalidBusValue', 'I2C', buses);
                end
            catch e
                throwAsCaller(e);
            end
        end

        function busNumber = getI2CBusNumber(~, hwsdkI2CBusID)
            if contains(hwsdkI2CBusID, "i2c-")
                % i2c-* can be zero indexed.
                busNumber = str2double(string(extract(hwsdkI2CBusID, 5)));
            else
                busNumber = 0;
            end
        end

        function showI2CBus(~, bus)
        % Displays I2C Bus in Device property display
            fprintf('                   Bus: "%s"\n', bus);
        end

        function showSPIPins(~, scl, sdi, sdo)
            fprintf('                SCLPin: "%s"\n', scl);
            fprintf('                SDIPin: "%s"\n', sdi);
            fprintf('                SDOPin: "%s"\n', sdo);
        end

        function validateSerialPort(~, serialPort, board, ~)
            try
                validateattributes(serialPort, {'string'}, ...
                                   {'nonempty', 'scalar'}, '', 'port');
            catch e
                if strcmp(e.identifier, 'MATLAB:invalidType')
                    try
                        validateattributes(serialPort, {'char'}, ...
                                           {'nonempty', 'vector', 'row'}, '', 'port');
                    catch e
                        switch e.identifier
                          case 'MATLAB:expectedRow'
                            throwAsCaller(e);
                          otherwise
                            matlabshared.hwsdk.internal.localizedError('MATLAB:hwsdk:general:unsupportedPort',serialPort,char(board), '/dev/serial0');
                        end
                    end
                else
                    throwAsCaller(e);
                end
            end
        end

        function validatingHandle = getSerialPinTypeValidator(~)
            validatingHandle = @isstring;
        end
    end
end
