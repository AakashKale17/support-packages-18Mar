function validateQuant(isQuantizedModel, disableChecks, isHost)
% Validate the target parameters during predict call

%#codegen
%   Copyright 2023 The MathWorks, Inc.
arguments
    isQuantizedModel (1,1) logical
    disableChecks (1,1) logical
    isHost = true;
end

coder.internal.prefer_const(isQuantizedModel, disableChecks, isHost)
isWin = coder.const(@feval, 'ispc');
coder.internal.errorIf(coder.const(isWin && isHost && isQuantizedModel && ~disableChecks), 'dl_tensorflow_lite:messages:INT8InferenceNotSupportedOnWindows');

end
