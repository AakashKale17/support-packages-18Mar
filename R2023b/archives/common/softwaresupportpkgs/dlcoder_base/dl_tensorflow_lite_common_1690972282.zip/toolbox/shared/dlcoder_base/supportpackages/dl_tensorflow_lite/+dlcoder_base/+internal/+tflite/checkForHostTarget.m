function isHostTarget = checkForHostTarget(ctx)    
% Check if the target platform is host target.

%   Copyright 2022 The MathWorks, Inc.

    isHostTarget = true;
    if ~isempty(ctx)
        if isa(ctx.ConfigData, 'Simulink.ConfigSet')
            if strcmp(ctx.CodeGenTarget, 'sfun')
                isHostTarget = true;
            elseif strcmp(ctx.CodeGenTarget, 'rtw') 
                isHostTarget = ctx.isMatlabHostTarget;
            else
               error(message('dl_tensorflow_lite:messages:TFLiteCoderInternalError'));
            end
        elseif isa(ctx.ConfigData, 'coder.Config')
            if ismethod(ctx ,'isMatlabHostTarget')
                isHostTarget = ctx.isMatlabHostTarget;
            else
                if isprop(ctx.ConfigData, 'Hardware') && ~isempty(ctx.ConfigData.Hardware)
                    isHostTarget = false;
                elseif ~strcmp(ctx.HardwareImplementation.ProdHWDeviceType, 'Generic->MATLAB Host Computer')
                    isHostTarget = false;
                end
            end
        else
            error(message('dl_tensorflow_lite:messages:TFLiteCoderInternalError'));
        end
    else %simulation
        isHostTarget = true;
    end
 
end
