function ise = getIse(ctx)
%GETISE returns the instruction set extension

%   Copyright 2023 The MathWorks, Inc.

    buildWorkflow  = dlcoder_base.internal.getBuildWorkflow(ctx);
    if strcmpi(buildWorkflow, 'simulation') 
        ise = '';
    elseif strcmpi(buildWorkflow, 'simulink') 
        ise = ctx.getConfigProp('InstructionSetExtensions');
        ise = ise{1};
    else
        assert(strcmpi(buildWorkflow, 'matlab'));
        if isCodeGenTarget(ctx, 'mex')
            ise = ctx.getConfigProp('SIMDAcceleration');
        else
            ise = char(ctx.getConfigProp('InstructionSetExtensions'));
        end
    end
end

