function s = appendErrorData(s, exception)
%APPENDERRORDATA appends exception related information to input struct "s"

%   Copyright 2023 The MathWorks, Inc.

if isempty(exception)
    % No errors
    s.error_id = '';
    s.unsupported_layer = '';
else
    % There was an error
    errorId = exception.identifier;
    errorMessage = exception.message;
    s.error_id = errorId;
    s.unsupported_layer = iGetUnsupportedLayerName(errorId, errorMessage);
end
end

function layerName = iGetUnsupportedLayerName(errorId, errorMessage)
% Return unsupported layer name
if strcmpi(errorId, 'dlcoder_spkg:cnncodegen:unsupported_layer')
    messageByWords = split(errorMessage, " ");
    layerName = messageByWords{4};
else
    % We hit this branch for errors different than unsupported layer. 
    % layerName is returned as empty string.
    layerName = '';
end
end