function structOut = convertStructFieldsToJson(structIn)
%CONVERTSTRUCTFIELDSTOJSON converts structIn fields to json format

%   Copyright 2023 The MathWorks, Inc.

arguments
    structIn (1,1) {mustBeA(structIn, 'struct')}
end

fieldNames = fieldnames(structIn);
for i = 1:numel(fieldNames)
    structOut.(fieldNames{i}) = iProcessEventData(structIn.(fieldNames{i}));
end
end

function dataOut = iProcessEventData(dataIn)
if isempty(dataIn)
    % We standardize empty values to empty char to log the same empty string in DDUX
    dataIn = '';
end
dataOut = jsonencode(dataIn);
end