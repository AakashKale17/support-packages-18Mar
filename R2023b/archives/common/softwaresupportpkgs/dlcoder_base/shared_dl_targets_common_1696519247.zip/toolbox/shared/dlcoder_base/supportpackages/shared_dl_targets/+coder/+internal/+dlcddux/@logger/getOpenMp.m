function openMPEnabled = getOpenMp(ctx)
%GETOPENMP returns true if leveraging multithreading is enabled

%   Copyright 2023 The MathWorks, Inc.

    buildWorkflow  = dlcoder_base.internal.getBuildWorkflow(ctx);
    if strcmpi(buildWorkflow, 'simulation') 
        openMPEnabled = '';
    elseif strcmpi(buildWorkflow, 'simulink') 
        openMPEnabled = strcmpi(ctx.getConfigProp('MultiThreadedLoops'), 'on');
    else
        assert(strcmpi(buildWorkflow, 'matlab'));
        openMPEnabled = ctx.getConfigProp('EnableOpenMP');
    end
end