function s = appendNetworkData(s, net)
%APPENDNETWORKDATA appends network information to input struct "s"

%   Copyright 2023 The MathWorks, Inc.

layers = net.Layers;
numLayers = numel(layers);

networkLayers = cell(numLayers,1);
numCustomerAuthoredLayers = 0;

% Loop through the network getting layer information
for i = 1:numLayers
    layer = layers(i);
    if dltargets.internal.checkIfCustomLayer(layer)
        if dltargets.internal.checkIfMwAuthoredLayer('ClassName', class(layer))
            % MathWorks authored custom layer
            networkLayers{i} = char(dltargets.internal.utils.GetSupportedLayersUtils.formatLayerClassNames(class(layer)));
        else
            % Customer authored custom layers
            networkLayers{i} = 'UserLayer';
            numCustomerAuthoredLayers = numCustomerAuthoredLayers + 1;
        end
    else
        % Built-in layers
        networkLayers{i} = char(dltargets.internal.utils.GetSupportedLayersUtils.formatLayerClassNames(class(layer)));
    end
end

% Layers contained in the network
s.network_layers = sort(unique(networkLayers));

% Network size
netInfo = whos('net');
s.network_size = netInfo.bytes;

% Number of custom layers
s.num_custom_layers = numCustomerAuthoredLayers;
end