function s = appendTargetLibraryData(s, dlCfg)
%APPENDTARGETLIBRARYDATA appends target library information to input struct "s"

%   Copyright 2023 The MathWorks, Inc.

s.target_library_config = iGetInfoFromConfig(dlCfg);

end

function s = iGetInfoFromConfig(dlCfg)

switch dlCfg.TargetLibrary
    case 'cudnn'
        % For cudnn we filter out "CalibrationResultsFile" and get the hidden 
        % property "MexAcceleration"
        s.AutoTuning = dlCfg.AutoTuning;
        s.DataType = dlCfg.DataType;
        s.MexAcceleration = dlCfg.MexAcceleration;
    case 'tensorrt'
        % For tensorrt we filter out "DataPath" and "NumCalibrationBatches"
        s.DataType = dlCfg.DataType;
    case 'arm-compute'
        % For arm-compute we filter out "CalibrationResultsFile"
        s.ArmComputeVersion = dlCfg.ArmComputeVersion;
        s.ArmArchitecture = dlCfg.ArmArchitecture;
        s.DataType = dlCfg.DataType;
    case 'arm-compute-mali'
        s.ArmComputeVersion = dlCfg.ArmComputeVersion;
    case 'cmsis-nn'
        % For cmsis-nn we filter out "CalibrationResultsFile"
        s.DataType = dlCfg.DataType;
    case 'none'
        s.LearnablesCompression = dlCfg.LearnablesCompression;
end
% Get target library for all targets
s.TargetLibrary = dlCfg.TargetLibrary;
end