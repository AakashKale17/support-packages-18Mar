function s = appendOtherParamsData(s, ctx)
%APPENDOTHERPARAMSDATA appends additional parameters to input struct "s"

%   Copyright 2023 The MathWorks, Inc.

s.other_parameters.Majority = coder.internal.dlcddux.logger.getMajority(ctx);
s.other_parameters.OsPlatform = computer('arch');

end

