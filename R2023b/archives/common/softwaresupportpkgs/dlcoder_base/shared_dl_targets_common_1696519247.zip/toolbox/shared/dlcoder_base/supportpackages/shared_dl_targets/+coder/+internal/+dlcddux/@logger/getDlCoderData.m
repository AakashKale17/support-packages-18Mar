function s = getDlCoderData(ctx, dlcfg, net, gpuEnabled, exception)
%GETDLCODERDATA returns all the data to be logged in ddux

%   Copyright 2023 The MathWorks, Inc.

arguments
    ctx {mustBeA(ctx, 'coder.BuildConfig')}
    dlcfg (1,1) {mustBeA(dlcfg, 'coder.DeepLearningConfigBase')}
    net (1,1) {mustBeA(net, ["SeriesNetwork" "DAGNetwork" "dlnetwork"])}
    gpuEnabled (1,1) logical
    exception {iMustBeExceptionOrEmpty(exception)}
end

s = struct();

% Get coder config data
s = coder.internal.dlcddux.logger.appendConfigData(s, ctx);

% Get target library data
s = coder.internal.dlcddux.logger.appendTargetLibraryData(s, dlcfg);

% Generate GPU code
s.gpu_enabled = gpuEnabled;

% Get network data
s = coder.internal.dlcddux.logger.appendNetworkData(s, net);

% Get error data
s = coder.internal.dlcddux.logger.appendErrorData(s, exception);

% Append additional parameters
s = coder.internal.dlcddux.logger.appendOtherParamsData(s, ctx);
end

function iMustBeExceptionOrEmpty(e)
assert(isa(e, 'MException') || isempty(e), ...
    'NVP Exception must be empty or ''MException''')
end