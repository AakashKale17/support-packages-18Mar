function clientName = getClientName(ctx)
%GETCLIENTNAME returns the codegen workflow: simulation, simulink, 
% matlab (mex) or matlab (rtw)

%   Copyright 2023 The MathWorks, Inc.

    clientName  = dlcoder_base.internal.getBuildWorkflow(ctx);
    if strcmpi(clientName, 'matlab')
        if coder.internal.coderNetworkUtils.isMexCodeConfig(ctx)
            % Specify mex config
            clientName = [clientName ' (mex)'];
        else
            % Specify rtw (standalone) config
            clientName = [clientName ' (rtw)'];
        end
    end
end