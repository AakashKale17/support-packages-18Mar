function crl = getCrl(ctx)
%GETCRL returns the code replacement library

%   Copyright 2023 The MathWorks, Inc.
    
    buildWorkflow  = dlcoder_base.internal.getBuildWorkflow(ctx);
    if strcmpi(buildWorkflow, 'simulation') 
        crl = '';
    elseif strcmpi(buildWorkflow, 'simulink') 
        crl = ctx.getConfigProp('CodeReplacementLibrary');
    else
        assert(strcmpi(buildWorkflow, 'matlab'));
        if isCodeGenTarget(ctx, 'mex')
            crl = '';
        else
            % "CodeReplacementLibrary" is returned as string by Simulink Config. We convert 
            % to char to standardize the output
            crl = char(ctx.getConfigProp('CodeReplacementLibrary'));
        end
    end

    % Check if custom CRL
    if dltargets.internal.checkIfCustomCrl(crl)
        crl = 'UserCrl';
    end
end