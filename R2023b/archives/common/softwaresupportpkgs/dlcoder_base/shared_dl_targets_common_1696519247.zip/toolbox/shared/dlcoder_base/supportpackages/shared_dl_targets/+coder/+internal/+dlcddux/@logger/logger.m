classdef logger
    % coder.internal.dlcddux.logger - Interface to log Deep Learning Coder ddux events

    %   Copyright 2023 The MathWorks, Inc.

    properties (Constant)
        % DDUX table keys
        Product = "ME"
        Component = "ME_DLC"
        EventId = "ME_DLC_CODEGENDATA"

        % json keys must match the ones defined in "ME_DLC_CODEGENDATA.json"
        SchemaKeys = {...
            'client_name',...
            'crl', ...
            'error_id', ...
            'gpu_enabled', ...
            'hardware_device_type', ...
            'ise', ...
            'network_layers', ...
            'network_size', ...
            'num_custom_layers', ...
            'open_mp' ...
            'other_parameters', ...
            'target_library_config' ...
            'unsupported_layer', ...
            }
    end
    methods (Static)
        % Method to log events. This is a wrapper for matlab.ddux.internal.logData
        function status = logDlCoderData(eventStruct)

            arguments
                eventStruct (1,1) {mustBeA(eventStruct, 'struct')}
            end

            iValidateStruct(eventStruct, coder.internal.dlcddux.logger.SchemaKeys);

            dataId = matlab.ddux.internal.DataIdentification( ...
                coder.internal.dlcddux.logger.Product, ...
                coder.internal.dlcddux.logger.Component, ...
                coder.internal.dlcddux.logger.EventId);
            
            % Standardize struct fields to json format
            dduxStruct = coder.internal.dlcddux.logger.convertStructFieldsToJson(eventStruct);
            
            status = matlab.ddux.internal.logData(dataId, dduxStruct);
        end
    end

    methods(Static)
        %  Methods to get data to log
        dataStruct = getDlCoderData(ctx, dlcfg, net, gpuEnabled, exception);
        clientName = getClientName(ctx);
        crlTable = getCrl(ctx);
        hwDeviceType = getHwDeviceType(ctx);
        ise = getIse(ctx);
        majority = getMajority(ctx);
        openMp = getOpenMp(ctx);

        % Methods to append data to struct "s"
        s = appendConfigData(s, ctx);
        s = appendNetworkData(s, net);
        s = appendTargetLibraryData(s, dlConfig);
        s = appendErrorData(s, exception);
        s = appendOtherParamsData(s, ctx);

        % Other utilities
        sOut = convertStructFieldsToJson(sIn)
    end
end

function iValidateStruct(s, validKeys)
% Validates all fields in s are valid schema keys

if ~all(ismember(fieldnames(s), validKeys))
    % Throw internal error
    throwAsCaller(MException('DLCoderDdux:InvalidInputToLogger', ...
        'Input struct to logger has an invalid field name'))
end
end