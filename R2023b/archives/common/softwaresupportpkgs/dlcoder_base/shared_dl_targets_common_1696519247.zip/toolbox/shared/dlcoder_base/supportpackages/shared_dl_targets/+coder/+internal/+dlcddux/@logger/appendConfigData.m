function s = appendConfigData(s, ctx)
%APPENDCONFIGDATA appends the coder configuration information to input struct "s"

%   Copyright 2023 The MathWorks, Inc.

% Client name
s.client_name = coder.internal.dlcddux.logger.getClientName(ctx);
% CRL table
s.crl = coder.internal.dlcddux.logger.getCrl(ctx);
% Hardware target
s.hardware_device_type = coder.internal.dlcddux.logger.getHwDeviceType(ctx);
% Instruction set extensions
s.ise = coder.internal.dlcddux.logger.getIse(ctx);
% OpenMP
s.open_mp = coder.internal.dlcddux.logger.getOpenMp(ctx);
end