function hwDeviceType = getHwDeviceType(ctx)
%GETHWDEVICETYPE returns the production hardware device type

%   Copyright 2023 The MathWorks, Inc.

    buildWorkflow  = dlcoder_base.internal.getBuildWorkflow(ctx);
    if strcmpi(buildWorkflow, 'simulation') 
        hwDeviceType = 'Generic->MATLAB Host Computer';
    elseif strcmpi(buildWorkflow, 'simulink') 
        hwDeviceType = ctx.getConfigProp('ProdHWDeviceType');
    else
        assert(strcmpi(buildWorkflow, 'matlab'));
        if isCodeGenTarget(ctx, 'mex')
            hwDeviceType = 'Generic->MATLAB Host Computer';
        else
            hwDeviceType = char(ctx.HardwareImplementation.ProdHWDeviceType);
        end
    end

    % Check if custom hardware device type
    if dltargets.internal.checkIfCustomHwDeviceType(hwDeviceType)
        hwDeviceType = 'UserHwDeviceType';
    end
end
