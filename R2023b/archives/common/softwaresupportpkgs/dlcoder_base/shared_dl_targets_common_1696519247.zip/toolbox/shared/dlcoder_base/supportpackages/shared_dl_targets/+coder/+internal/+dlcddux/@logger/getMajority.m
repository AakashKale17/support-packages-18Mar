function majority = getMajority(ctx)
%GETMAJORITY returns array majority

%   Copyright 2023 The MathWorks, Inc.

    buildWorkflow  = dlcoder_base.internal.getBuildWorkflow(ctx);
    if strcmpi(buildWorkflow, 'simulation') 
        majority = 'Column-major';
    elseif strcmpi(buildWorkflow, 'simulink') 
        majority = ctx.getConfigProp('ArrayLayout');
    else
        assert(strcmpi(buildWorkflow, 'matlab'));
        if ctx.getConfigProp('RowMajor')
            majority = 'Row-major';
        else
            majority = 'Column-major';
        end
    end
end