function image = getImage(inputOcvObj)
%

% Copyright 2021-2023 The MathWorks, Inc.

import vision.opencv.*;

[type, isArray] = internal.getclibtype(inputOcvObj);

if isArray
error(message('opencvinterface:opencv:arrayNotSupported'));
end

validateattributes(inputOcvObj, {'clib.opencv.cv.x_InputArray', 'clib.opencv.cv.x_InputOutputArray', 'clib.opencv.cv.x_OutputArray', ...
    'clib.opencv.cv.MatND', 'clib.opencv.cv.UMat'}, {});


switch type
    case {"x_InputArray", ...
            "x_InputOutputArray", ...
            "x_OutputArray" }
        if(inputOcvObj.isMat || inputOcvObj.isVector)
            MatObj = inputOcvObj.getMat;
            obj = internal.getImageFromMatND(MatObj);
            
        elseif(inputOcvObj.isUMat)
            UMatObj = inputOcvObj.getUMat;
            obj = internal.getImageFromUMat(UMatObj);
        else
            error(message("opencvinterface:opencv:invalidObject"));
        end
        
    case "MatND"
        obj = internal.getImageFromMatND(inputOcvObj);
    case "UMat"
        obj = internal.getImageFromUMat(inputOcvObj);
    otherwise
        error(message("opencvinterface:opencv:invalidObject"));
end

image = obj.Ptr;
end