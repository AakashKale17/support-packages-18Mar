function bbox = rectToBbox(cvRect)
%

% Copyright 2021-2023 The MathWorks, Inc.

import clib.opencv.*;
import vision.opencv.*;

validateattributes(cvRect, {'clib.opencv.cv.Rect2d', 'clib.opencv.cv.Rect2f', ...
    'clib.opencv.cv.Rect2i', 'clib.opencv.cv.Rect__long_', 'clib.opencv.cv.Rect__unsignedChar_', ...
    'clib.array.opencv.cv.Rect2i' }, {});

[~, isArray] = internal.getclibtype(cvRect);


if isArray
    dims = cvRect.Dimensions;
    bbox = zeros(dims, 4);
    for k = 1: dims
        bbox(k,1) = cvRect(k).x +1;
        bbox(k,2) = cvRect(k).y +1;
        bbox(k,3) = cvRect(k).width +1;
        bbox(k,4) = cvRect(k).height +1;
    end
    bbox = cast(bbox,'like', cvRect(1).x);
else
    x_idx      = cvRect.x +1;
    y_idx      = cvRect.y +1;
    width_idx  = cvRect.width;
    height_idx = cvRect.height;
    
    bbox = [x_idx, y_idx, width_idx, height_idx];
    bbox = cast(bbox,'like', cvRect.x);
end
    
end