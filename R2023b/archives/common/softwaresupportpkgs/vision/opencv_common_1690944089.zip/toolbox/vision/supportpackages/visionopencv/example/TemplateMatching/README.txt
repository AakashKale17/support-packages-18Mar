To run the Template Matching example, follow these steps:

1. Change your current working folder to example/TemplateMatching where 
source file matchTemplateOCV.cpp is located

2. Create MEX-file from the source file:
>> mexOpenCV matchTemplateOCV.cpp

3. Run the test script:
>> testMatchTemplate.m 
The test script uses the generated MEX-file.