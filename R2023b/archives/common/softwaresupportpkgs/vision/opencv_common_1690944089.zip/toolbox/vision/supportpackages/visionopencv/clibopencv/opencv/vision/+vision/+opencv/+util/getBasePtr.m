function basePtr= getBasePtr(cvptr)
%

% Copyright 2021-2023 The MathWorks, Inc.

import clib.opencv.*;
import vision.opencv.*;

type = internal.getclibtype(cvptr);
validType = strcmp(type(1:8), "Ptr_cv__");

if(~validType)
    error(message('opencvinterface:opencv:invalidcvptr'));
end

basePtr = internal.getbaseptr(type, cvptr);