function [ocvUmat, ocvArray] = createUMat(varargin)
%

% Copyright 2021-2023 The MathWorks, Inc.

narginchk(0, 2);
import vision.opencv.*;
if isempty(varargin)
    [ocvUmat, ocvArray] = internal.ocvOutputArray("UMat");
else
    if(~isstring(varargin{1}) && ~ischar(varargin{1}))
        mlImage = varargin{1};
        if (ndims(mlImage) > 3)
            error(message("opencvinterface:opencv:invalidImage"));
        end
        
        obj = internal.ocvMLArray(mlImage);
        if(nargin ==1)
            arrayType = "Input";
        elseif(nargin > 1)
            arrayType = varargin{2};
        end
        arrayType = validatestring(arrayType,["Input","InputOutput", "Output"], mfilename,'arrayType');
        
        switch arrayType
            case "Input"
                [ocvUmat, ocvArray] = obj.getInputArray_UMat();
            case "InputOutput"
                [ocvUmat, ocvArray] = obj.getInputOutputArray_UMat();
            case "Output"
                [ocvUmat, ocvArray] = obj.getOutputArray_UMat();
            otherwise
                error(message("opencvinterface:opencv:invalidArray"));
        end
    else
        narginchk(1, 1);
        arrayType = varargin{1};
        mattype = "UMat";
        
        arrayType = validatestring(arrayType,["Input","InputOutput", "Output"], mfilename,'arrayType');
        switch arrayType
            case "Input"
                [ocvUmat, ocvArray] = internal.ocvInputArray(mattype);
            case "InputOutput"
                [ocvUmat, ocvArray] = internal.ocvInputOutputArray(mattype);
            case "Output"
                [ocvUmat, ocvArray] = internal.ocvOutputArray(mattype);
            otherwise
                error(message("opencvinterface:opencv:invalidArray"));
        end
    end
end
end
