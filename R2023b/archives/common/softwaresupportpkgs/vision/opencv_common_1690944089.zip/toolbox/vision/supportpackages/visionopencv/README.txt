CONTENTS OF THIS FILE
---------------------
* Introduction
* Requirements
* Installation
* Contents
* Utility functions for OpenCV mex function
* How to compile OpenCV mex function
* Example for creating OpenCV mex function
* Utility functions for prebuilt MATLAB interface to OpenCV
* How to use the prebuilt MATLAB interface to OpenCV

INTRODUCTION
------------
Use the "Computer Vision Toolbox Interface for OpenCV in MATLAB"
* To create mex files that access pre-built OpenCV library version 4.5.2 that ships with Computer Vision Toolbox

* To directly access the OpenCV library version 4.5.2 by using the prebuilt MATLAB interface to OpenCV.

GPU support is not available for prebuilt MATLAB interface to OpenCV.

REQUIREMENTS
------------
This package requires the following:
* Computer Vision Toolbox Version R2022a installation
* A compatible C++ compiler
* GPU processing is supported on CUDA-enabled NVIDIA GPUs to create mex files.

The mex function uses pre-built OpenCV libraries which are shipped with the 
Computer Vision Toolbox. Your compiler must be compatible with the 
pre-built OpenCV libraries. The following is a list of compatible compilers:
    Windows 64 bit: MS Visual Studio 2017 or MS Visual Studio 2015
    Linux 64 bit: gcc-6.3 and above (g++)
    Mac 64 bit: Xcode 9.0.0 and above (Clang++)


INSTALLATION
------------
Use the support package installer which can be invoked using the  
visionSupportPackages function.
After the support package is installed, the location of the package can be 
found by executing the following MATLAB command:
>> fileparts(which('mexOpenCV.m'))

CONTENTS
--------
In addition to the files and folders required by the support package installer, 
the package contains the following folder:

example: Three subfolders containing examples. Each subfolder contains a source 
	 file that calls the OpenCV function and the test script to test the 
	 generated mex file.

clibopencv: This folder contains the files required by prebuilt MATLAB interface to OpenCV library shipped with 
	    Computer Vision Toolbox. 


UTILITY FUNCTIONS FOR OPENCV MEX FUNCTION
-----------------------------------------
The support package uses a set of utility functions to marshall data 
between OpenCV and MATLAB. It supports only CPP-linkage. GPU support is 
only available on glnxa64 and win64 platforms. 

General purpose utility functions are available at:
  (matlabroot)/extern/include/opencvmex.hpp
Utility functions for GPU support are available at:
  (matlabroot)/extern/include/opencvgpumex.hpp

HOW TO COMPILE OPENCV MEX FUNCTION
----------------------------------
Follow these steps:
1. Change your current working folder to the folder where the source file is located. 
2. Call the mexOpenCV function with the source file. 
>> mexOpenCV yourfile.cpp

To get more information, type the following at the MATLAB command prompt:
>> help mexOpenCV

EXAMPLES FOR CREATING OPENCV MEX FUNCTIONS
------------------------------------------
There are three examples included in the package: 
* Template Matching  
* Image registration using ORB detector and descriptor
* Foreground Detection

To run them, follow the steps in the README.txt file located in the corresponding 
sub-folders of the examples folder.


UTILITY FUNCTIONS FOR PREBUILT MATLAB INTERFACE TO OpenCV
---------------------------------------------------------
The support package provides a set of utility functions to marshall data 
between OpenCV and MATLAB.

The following are the utility functions to use prebuilt MATLAB interface to OpenCV
* createMat
* createUMat
* getBasePtr
* getImage
* keyPointsToStruct
* rectToBbox

Access these utility functions by using the syntax
"vision.opencv.util.<utility function name>".
To know the list of utility functions provided with the support package, type "vision.opencv.util." in the MATLAB command window and press the Tab key.

Also there are generalized functions to pass data across MATLAB and C++
https://in.mathworks.com/help/matlab/use-prebuilt-matlab-interface-to-c-library.html


HOW TO USE prebuilt MATLAB interface to OpenCV
----------------------------------------------
Access the prebuilt MATLAB interface to OpenCV functions by using the syntax
"clib.opencv.cv.<opencv function name>".
To obtain the list of OpenCV functions in the pre-built library, type "clib.opencv.cv." in the MATLAB command window and press the Tab key.

Use MATLAB help or doc command to get more information about the signature of the OpenCV function to use in MATLAB.

Example: 
>> help clib.opencv.cv.AGAST
 clib.opencv.cv.AGAST    Representation of C++ function cv::AGAST.

    Inputs
      image          read-only clib.opencv.cv.x_InputArray  
      keypoints      clib.array.opencv.cv.KeyPoint  
      threshold      int32  
      nonmaxSuppression  logical  

    No outputs

>> img = imread("cameraman.tif");
>> [imgMat, imgArray] = vision.opencv.util.createMat(img);
>> keyPoints = clibArray("clib.opencv.cv.KeyPoint",0);
>> clib.opencv.cv.AGAST(imgArray, keyPoints, 10);

Alternatively, add the prebuilt MATLAB interface to OpenCV package and the utility functions to the import list by 
using the syntax "import clib.opencv.*" and "import vision.opencv.*" respectively.
Then, directly call the functions in the pre-built OpenCV library by using "cv.<opencv function name>", 
and access the utility functions using "util.<function name>".

Example: 
import clib.opencv.*;
import vision.opencv.*;
img = imread("cameraman.tif");
[imgMat, imgArray] = util.createMat(img);
keyPoints = clibArray("clib.opencv.cv.KeyPoint",0);
cv.AGAST(imgArray, keyPoints, 10);
