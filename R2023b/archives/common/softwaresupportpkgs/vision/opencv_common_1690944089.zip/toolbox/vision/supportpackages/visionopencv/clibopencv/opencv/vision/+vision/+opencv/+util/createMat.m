function [ocvMat, ocvArray] = createMat(varargin)
%

% Copyright 2021-2023 The MathWorks, Inc.

narginchk(0, 2);
import vision.opencv.*;

if isempty(varargin)
    [ocvMat, ocvArray] = internal.ocvOutputArray("Mat");
else
    if(~isstring(varargin{1}) && ~ischar(varargin{1}))
        mlImage = varargin{1};
        if (ndims(mlImage) > 3)
            error(message("opencvinterface:opencv:invalidImage"));
        end
        obj = internal.ocvMLArray(mlImage);
        
        
        if(nargin ==1)
            arrayType = "Input";
        elseif(nargin > 1)
            arrayType = varargin{2};
        end
        arrayType = validatestring(arrayType,["Input","InputOutput", "Output"], mfilename,'arrayType');

        switch arrayType
            case "Input"
                [ocvMat, ocvArray] = obj.getInputArray_MatND();
            case "InputOutput"
                [ocvMat, ocvArray] = obj.getInputOutputArray_MatND();
            case "Output"
                [ocvMat, ocvArray] = obj.getOutputArray_MatND();
            otherwise
                error(message("opencvinterface:opencv:invalidArray"));
        end
    else
        narginchk(1, 1);
        arrayType = varargin{1};
        arrayType = validatestring(arrayType,["Input","InputOutput", "Output"], mfilename,'arrayType');
        mattype = "Mat";
        
        switch arrayType
            case "Input"
                [ocvMat, ocvArray] = internal.ocvInputArray(mattype);
            case "InputOutput"
                [ocvMat, ocvArray] = internal.ocvInputOutputArray(mattype);
            case "Output"
                [ocvMat, ocvArray] = internal.ocvOutputArray(mattype);
            otherwise
                error(message("opencvinterface:opencv:invalidArray"));
        end
    end
end
end
