function mlStruct = keyPointsToStruct(ocvKeypts)
%

% Copyright 2021-2023 The MathWorks, Inc.

validateattributes(ocvKeypts, {'clib.array.opencv.cv.KeyPoint'}, {});

points = zeros(ocvKeypts.Dimensions,2);
scale = zeros(ocvKeypts.Dimensions,1);
metric = zeros(ocvKeypts.Dimensions,1);
misc = zeros(ocvKeypts.Dimensions,1);
orientation = zeros(ocvKeypts.Dimensions,1);

for i = 1:ocvKeypts.Dimensions
    points(i,1)  = ocvKeypts(i).pt.x+1;
    points(i,2)  = ocvKeypts(i).pt.y+1;
    scale(i)     = ocvKeypts(i).size;
    metric(i)    = ocvKeypts(i).response;
    misc(i)      = ocvKeypts(i).class_id;
    if (ocvKeypts(i).angle < 0)
        orientation(i)  = 0;
    else
        orientation(i)  = single(ocvKeypts(i).angle*(3.14/180.0));
    end
end

mlStruct.Location = points;
mlStruct.Scale = scale;
mlStruct.Metric = metric;
mlStruct.Misc = misc;
mlStruct.Orientation = orientation;
end
