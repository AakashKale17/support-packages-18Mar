function [stacked] = tfPack(TFAxis, varargin)
%{{import_statement}}

%   Copyright 2022 The MathWorks, Inc.

nTensors = nargin - 1; 
inrank = varargin{1}.rank; 

for i = 1:nTensors 
    varargin{i} = convertToForwardTF(varargin{i});    
end

% Account for dropped trailing singleton dimensions
inputShape = ones(1, inrank); 
inputShape(1:ndims(varargin{1}.value)) = size(varargin{1}.value);

% varargin should be in forward TF format now.  
if isempty(TFAxis)
    TFAxis = 0;
end

if TFAxis < 0
    % handle negative axis values
    if TFAxis == (-1 * (inrank+1))
        MLAxis = -1;
    else
        MLAxis = mod(TFAxis, inrank);
    end
else 
    MLAxis = TFAxis; 
end

% inputShape holds the shape in forward TF format
if (inrank == 0)
    % if the input is a scalar
    outputShape = [1 1];
else
    % If the input rank > 0, stack on the dimension specified by axis
    if TFAxis < 0
        outputShape = [inputShape(1:MLAxis + 1) 1 inputShape(MLAxis + 2:end)];
    else
        outputShape = [inputShape(1:MLAxis) 1 inputShape(MLAxis + 1:end)];
    end
end

for i = 1:nTensors 
    varargin{i} = reshape(varargin{i}.value, outputShape);   
end

outrank = inrank + 1;

if TFAxis < 0
    stacked = cat(MLAxis + 2, varargin{:}); 
else
    stacked = cat(MLAxis + 1, varargin{:}); 
end

if outrank > 1 
    % convert to reverse TF format if rank > 2
    stacked = permute(stacked, outrank:-1:1);
    newLabel = repmat('U', [1 outrank]); 
else
    newLabel = 'UU';
end

stacked = dlarray(stacked, newLabel); 
stacked = struct('value', stacked, 'rank', outrank); 
end

function [x] = convertToForwardTF(x)
%{{import_statement}}

if isdlarray(x.value) && ~isempty(x.value.dims) && ~all(x.value.dims == 'U')
    DLTLabels = x.value.dims; 
    [permutationVec] = sortToTFLabel(1:x.rank, DLTLabels);
    x.value = stripdims(x.value);
    if x.rank > 1
        x.value = permute(x.value, permutationVec);
    end
elseif isdlarray(x.value) && (isempty(x.value.dims) || all(x.value.dims == 'U'))
    if x.rank > 1
        x.value = permute(x.value, x.rank:-1:1);
    end
end 
end 
