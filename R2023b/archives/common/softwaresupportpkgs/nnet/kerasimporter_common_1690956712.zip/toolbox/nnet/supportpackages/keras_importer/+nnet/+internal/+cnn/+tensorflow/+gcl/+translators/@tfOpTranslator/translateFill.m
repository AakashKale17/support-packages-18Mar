function result = translateFill(~, MATLABOutputName, MATLABArgIdentifierNames)
    % Copyright 2021 The MathWorks, Inc.
    
    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult; 

    result.Code = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall(...
        "tfFill", ...
        MATLABOutputName, ...
        MATLABArgIdentifierNames);

    result.OpFunctions = "tfFill";
    result.IsCommenting = false;
    result.ForwardRank = false;
    result.NumOutputs = 1;
    result.Success = true; 
end 