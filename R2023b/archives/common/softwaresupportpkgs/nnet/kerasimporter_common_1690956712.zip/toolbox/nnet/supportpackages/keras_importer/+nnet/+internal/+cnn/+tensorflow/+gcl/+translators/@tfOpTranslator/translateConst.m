function result = translateConst(this, node_def, MATLABOutputName, TFConstants)
%

%   Copyright 2020-2021 The MathWorks, Inc.

    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult; 
    
    result.Code = MATLABOutputName + ".value" + " = " + writeConstant(this, node_def, MATLABOutputName, TFConstants); 
    result.NumOutputs = 1; 
    result.ForwardRank = false; 
    
    result.Success = true; 
end
