function z = tfSplit(axis, input, numSplits)
    %{{import_statement}}
    % Copyright 2022 The MathWorks, Inc.

    inputval = input.value; 
    inputrank = input.rank; 

    axis = axis.value;

    if isempty(axis)
    MLAxis = inputrank;
    else
        if axis < 0
           % Handle negative axis values
           axis = inputrank + 1 + axis;
        end
        MLAxis = inputrank - axis; 
    end 
    
    nSpecs = inputrank;
    if isa(inputval, 'dlarray') && ~isempty(inputval.dims) && ~all(inputval.dims=='U') 
        returnOutputLabels = true;
        DLTLabels = inputval.dims;
        [permutationVec, DLTLabels] = sortToTFLabel(1:numel(DLTLabels), DLTLabels);
        inputval = stripdims(inputval);
        inputval = permute(inputval, fliplr(permutationVec));
    else
        returnOutputLabels = false;
        if inputrank > 1
            uLabels = repmat('U', [1 inputrank]);
        else
            uLabels = 'UU';
        end
    end
    
    idxarray = {};
    currSplitIdx = 1;
    splitSize = size(inputval,MLAxis) / numSplits; 
    for i = 1:numSplits
        splitidxs = {};
        for j = 1:nSpecs
            if (j==MLAxis)
                splitidxs{j} = currSplitIdx:(splitSize * i);
                currSplitIdx = currSplitIdx + splitSize;
            else
                splitidxs{j} = 1:size(inputval,j);
            end
        end
        idxarray{i} = splitidxs;
    end

    z = {};
    for k = 1:numel(idxarray)
        zval = inputval(idxarray{k}{:});
        if returnOutputLabels
            zval = permute(zval, inputrank:-1:1); 
            zval = dlarray(zval, DLTLabels);
        else        
            zval = dlarray(single(zval), uLabels); 
        end
        z{k} = struct('value', zval, 'rank', inputrank); 
    end     
end