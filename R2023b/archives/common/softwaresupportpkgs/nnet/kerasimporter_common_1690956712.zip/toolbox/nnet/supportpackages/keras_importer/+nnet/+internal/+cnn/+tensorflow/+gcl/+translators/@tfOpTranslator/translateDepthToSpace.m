function result = translateDepthToSpace(~, node_def, MATLABOutputName, MATLABArgIdentifierNames)
%

%   Copyright 2020-2021 The MathWorks, Inc.

    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult;
    
    block_size = node_def.attr.block_size.i;
    result.Code = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall("depthToSpace", {MATLABOutputName + ".value"}, {MATLABArgIdentifierNames{1} + ".value", block_size});
    
    result.ForwardRank = true; 
    result.Success = true; 
end 
