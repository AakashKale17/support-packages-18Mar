function [y] = tfDepthwiseConv2D(input, filter, strides, padding, explicit_paddings, dilations)
%{{import_statement}}

%   Copyright 2020-2022 The MathWorks, Inc.

    % Input verification
    if input.rank ~= 4
        error('2D depthwise convolution is only supported for input tensors having a rank of 4.');
    end

    if isa(input.value, 'dlarray')
        inputLabel = input.value.dims;
    else
        inputLabel = [];
    end
    
    TFInputLabel = "BSSC"; 
    % If the input tensor is unlabeled. We assume it is in reverse TensorFlow order
    if isempty(inputLabel) || all(inputLabel == 'U')
        % Permute to forward tensorflow format and apply labels
        input.value = permute(stripdims(input.value), input.rank:-1:1); 
        input.value = dlarray(input.value, TFInputLabel); 
    elseif strcmp(inputLabel(1),'B') && all(inputLabel(2:end) == 'U')
        % Input tensor is already in Forward TF format
        % apply BSSC labels
        input.value = dlarray(input.value, TFInputLabel); 
    end
    
    % Logic for the default "NHWC" data format
    % The TF DepthwiseConv2dNative op currently only supports the NHWC tensor format on the CPU.

    % In TF strides and dilations are 1-D Tensors of size 4 (NHWC).
    % Extract the dimensions corresponding to H and W (index 2 and 3)
    strides = strides([2 3]);
    
    if ~isempty(dilations)
        dilations = dilations([2 3]);
    else
        dilations = 1;
    end
    
    % TF DepthwiseConv2D raw op doesn't have a bias
    bias = 0;
    
    % In TF explicit padding is a list of size 8 (2 values per dimension)
    % Extract the padding values corresponding to the spatial dimensions (index 2 and 3)
    if ~isempty(explicit_paddings)    
        explicit_paddings = explicit_paddings(3:6);
        % convert [top bottom left right] to [top, left; bottom, right]
        explicit_paddings = reshape(explicit_paddings,[2,2]);
    end

    % shape and label filter
    [channel_multiplier, in_channels, width, height] = size(filter.value);
    filter.value = filter.value.permute([4 3 1 2]); 
    filter.value = filter.value.reshape(height, width, 1, channel_multiplier, in_channels);
    % dlconv > size(weights) = filtersize (SS dimension), numChannelsPerGroup (C dimension),
    % numFiltersPerGroup (first U dimension), numGroups (second U dimension)
    % for depthwise 2D convolution:
    % numChannelsPerGroup = 1, numFiltersPerGroup = channel_multiplier,
    % numGroups = in_channels
    filter.value = dlarray(filter.value,'SSCUU');
    
    % Applying dlconv on formatted dlarray
    if strcmp(padding,'VALID')
        y = dlconv(input.value, filter.value, bias, 'Stride', strides,'DilationFactor', dilations);
    elseif strcmp(padding,'SAME')
        y = dlconv(input.value, filter.value, bias, 'Stride', strides, 'Padding', 'same', 'DilationFactor', dilations);
    elseif strcmp(padding,'EXPLICIT')
        y = dlconv(input.value, filter.value, bias, 'Stride', strides, 'Padding', explicit_paddings, 'DilationFactor', dilations);
    end

    % assign output rank
    y = struct('value', y, 'rank', 4);

end

