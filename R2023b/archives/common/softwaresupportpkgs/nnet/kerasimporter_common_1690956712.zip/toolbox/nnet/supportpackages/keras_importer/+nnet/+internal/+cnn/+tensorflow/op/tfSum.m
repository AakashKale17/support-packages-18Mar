function z = tfSum(x, axis, keepdims)
    %{{import_statement}}
    
    % Copyright 2022-2023 The MathWorks, Inc.

    xrank = x.rank;
    x = x.value;

    if isstruct(axis)
        axis = axis.value;
    end
    
    % If axis is a dlarray extract the numeric value
    if isa(axis, 'dlarray')
        axis = axis.extractdata;
    end

    if axis < 0
        % Handle negative axis values
        % Change axis for operation in reverse TF format
        MLAxis =  xrank - mod(axis,xrank);
    else   
        % Change axis for operation in reverse TF format
        MLAxis = xrank - axis;
    end

    isXDLTFormat = isa(x, 'dlarray') && ~isempty(x.dims) && ~all(x.dims == 'U') && xrank > 1;	
    if isXDLTFormat
        [xPermutationVec, xtflabel] = sortToTFLabel(1:xrank, x.dims);
        x = stripdims(x);
        x = permute(x, flip(xPermutationVec)); 
    elseif isa(x, 'dlarray') % with all U dimensions, already in reverse TF format
        x = stripdims(x);  
    end 
    
    % Reverse TensorFlow dimension order
    if xrank <= 1
        z = sum(x(:), MLAxis); 
    else 
        z = sum(x, MLAxis); 
    end    
    
    % Handle labels
    if keepdims && isXDLTFormat
        zrank = xrank;
        if zrank > 1
            z = permute(z, zrank:-1:1); 
        end 
        z = dlarray(z, xtflabel);
    elseif keepdims && ~isXDLTFormat
        zrank = xrank;
        if zrank > 1
            z = dlarray(z, repmat('U', [1 zrank]));
        else
            z = dlarray(z, 'UU');
        end 
    elseif ~keepdims
        % cannot re-assign labels in this case
        dimsToDrop = MLAxis;
        dimsToDrop(dimsToDrop > ndims(z)) = [];    
        newSize = size(z);
        newSize(dimsToDrop)= [];
        if numel(newSize) == 1
            z = reshape(z,newSize, []);
        elseif numel(newSize) > 1
            z = reshape(z,newSize);
        end
        zrank = xrank - numel(MLAxis);
        if zrank > 1
            z = dlarray(z, repmat('U', [1 zrank]));
        else
            z = dlarray(z, 'UU');
        end    
    end
        z = struct('value', z, 'rank', zrank);
end 
