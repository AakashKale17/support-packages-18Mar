function z = tfStopGradient(input)
    %{{import_statement}}

%   Copyright 2020-2023 The MathWorks, Inc.

    if isstruct(input)
        zrank = input.rank; 
        input = input.value; 
        if isa(input, 'dlarray') 
            DLTLabels = input.dims; 
            % z continues as a copy of the original input. But the path to the
            % original is maintained via a zero gradient skip connection. 
            z = dlarray(input.extractdata, DLTLabels) + (0 .* input); 
        else
            z = input; 
        end 
        z = struct('value', z, 'rank', zrank);
    else
        z = input;
    end
end 
