function z = tfGather(params, ind, axis, batch_dims) 
    %{{import_statement}}

%   Copyright 2020-2023 The MathWorks, Inc.

    if nargin < 4
        batch_dims = 0;
    end

    if params.rank == 1
        params.value = params.value(:);
    end

    xval = params.value; 
    xrank = params.rank;

    if isa(xval, 'dlarray') && ~isempty(xval.dims) && ~all(xval.dims =='U') && xrank > 1
        xDLTLabel = xval.dims;         
        [permutationVec, TFLabels] = sortToTFLabel(1:xrank, xDLTLabel); 
        xval = xval.stripdims; 
        xval = permute(xval, permutationVec); 
    else 
        % If input is in reverse TF format
        % Convert it to fwd TF format
        if isa(xval, 'dlarray')
            xval = xval.stripdims;
        end
        if xrank > 1
            xval = permute(xval, xrank:-1:1); 
        end
        TFLabels = ''; 
    end

    indval = ind.value;
    indrank = ind.rank;

    if isa(indval, 'dlarray') && ~isempty(indval.dims) && ~all(indval.dims =='U') && indrank > 1
        indDLTLabel = indval.dims;         
        [indPermutationVec, ~] = sortToTFLabel(1:indrank, indDLTLabel); 
        indval = indval.stripdims; 
        indval = permute(indval, indPermutationVec); 
    else 
        % If indices is in reverse TF format
        % Convert it to fwd TF format
        if isa(indval, 'dlarray')
            indval = indval.stripdims;
        end
        if indrank > 1
            indval = permute(indval, indrank:-1:1); 
        end 
    end

    % If indval is a dlarray extract the numeric array
    if isa(indval, 'dlarray')
        indval = indval.extractdata;
    end

    if isstruct(axis)
        axis = axis.value;
    end
    
    % If axis is a dlarray extract the numeric value
    if isa(axis, 'dlarray')
        axis = axis.extractdata;
    end

    % Handle negative axis values
    if axis < 0
       axis = xrank + axis;
    end

    xShape =  getTensorShape(xval, xrank);
    indShape = getTensorShape(indval, indrank);
    
    % Now xval and indval should be in forward TF format
    mlAxis = axis + 1;
    mlInd = indval + 1; 
    
    Indices.type = '()';
    
    if batch_dims > 0 && batch_dims == indrank
        % need to get full subscripts for indexing
        [subsInds] = getFullSubsIndices(xShape, indShape, mlInd);
        z = [];
        [r,~] = size(subsInds);
        for j = 1:r
            Indices.subs = num2cell(subsInds(j,:));
            z(end+1) = subsref(xval, Indices); %#ok<AGROW>
        end
        zShape = [xShape(1:mlAxis-1) indShape(batch_dims + 1:end) xShape(mlAxis +1: end)];
        if numel(zShape) == 1
            % MATLAB reshape requires at-least 2 elements for reshape vector
            zShape = [zShape 1];
        end
        zrank = numel(zShape);
        z = reshape(z,flip(zShape));
        z = permute(z, zrank:-1:1);
    elseif batch_dims > 0 && axis == batch_dims && batch_dims <= indrank
        [subsInds] = getPartialSubsIndices(indShape, indrank, mlInd, batch_dims);
        xShapeAfterIdx = xShape(indrank+1:end);
        z = [];
        [r,~] = size(subsInds);
        for j = 1:r
            c = num2cell(subsInds(j,:));
            c(end+1:end+(xrank-indrank)) = {':'}; 
            numelX = prod(xShapeAfterIdx);
            z(end+1:end+numelX) = xval(c{:}); 
        end        
        zShape = [xShape(1:mlAxis-1) indShape(batch_dims + 1:end) xShape(mlAxis +1: end)];
        if numel(zShape) == 1
            % MATLAB reshape requires at-least 2 elements for reshape vector
            zShape = [zShape 1];
        end
        zrank = numel(zShape);
        z = reshape(z,flip(zShape));
        z = permute(z, zrank:-1:1);
    else
        Indices.subs = repmat({':'}, 1, xrank);
        Indices.subs{mlAxis} = mlInd(:);
        z = subsref(xval, Indices);
        if batch_dims > 0
            zShape = [xShape(1:mlAxis-1) indShape(batch_dims + 1:end) xShape(mlAxis +1: end)];
            zrank = numel(zShape); 
        else
            zrank = xrank - 1 + indrank;
            zShape = [xShape(1:mlAxis-1) indShape xShape(mlAxis +1: end)];
        end
        if numel(zShape) == 1
            % MATLAB reshape requires at-least 2 elements for reshape vector
            zShape = [zShape 1];
        end               
        z = reshape(z,zShape);
    end   
    
    
    if ~isempty(TFLabels) && zrank == xrank
        z = dlarray(z, TFLabels);
    else
        if zrank > 1
            z = permute(z, zrank:-1:1);
            z = dlarray(z, repmat('U', [1 zrank]));
        else
            z = dlarray(z, 'UU');
        end
    end
    z = struct('value', z, 'rank', zrank); 
end

function [subsInds] = getPartialSubsIndices(indShape, indrank, mlInd, batch_dims)
    mlInd = permute(mlInd, indrank:-1:1);
    partialSubsInds = mlInd(:); % flattened subscript indices
    batchDimsArr = {};    
    for i = 1: numel(indShape)
        batchDimsArr(i) = {1:indShape(i)}; %#ok<AGROW>
    end    
    batchSubInds = table2array(combinations(batchDimsArr{:})); 
    subsInds = horzcat(batchSubInds(:,1:batch_dims),partialSubsInds);
end 

function [subsInds] = getFullSubsIndices(xShape, indShape, mlInd)
    partialSubsInds = mlInd(:); % flattened subscript indices
    numSpecsInBatchDims = prod(indShape);
    batchDimsArr = {};    
    for i = 1: numel(indShape)
        batchDimsArr(i) = {1:indShape(i)}; %#ok<AGROW>
    end    
    batchSubInds = table2array(combinations(batchDimsArr{:})); 
    subsInds = horzcat(batchSubInds,partialSubsInds);
    
    extraDimsInXShape = xShape(numel(indShape)+2 : end);
    numSpecsInExtraDimsInXShape = prod(extraDimsInXShape);
    extraNonBatchDimsArr = {};    
    for j = 1: numel(extraDimsInXShape)
        extraNonBatchDimsArr(j) = {1:extraDimsInXShape(j)}; %#ok<AGROW>
    end    
    extraNonBatchDimsArr = table2array(combinations(extraNonBatchDimsArr{:}));
    extraNonBatchDimsArr = repmat(extraNonBatchDimsArr, [numSpecsInBatchDims 1]);
    subsInds = repelem(subsInds, numSpecsInExtraDimsInXShape, 1);    
    subsInds = horzcat(subsInds, extraNonBatchDimsArr);     
end 


function [shape] = getTensorShape(xval, xrank)
    % Assumes that xval is in fwd-TF format
    shape = size(xval);
    nShape = numel(shape);
    if nShape < xrank
        % Add trailing singleton dims
        shape(end+1:end+xrank-nShape) = 1;
    elseif nShape > xrank
        shape = shape(1:xrank);
    end
end 