function z = tfScatterNd(indices, updates, shape)
    %{{import_statement}}
   
%   Copyright 2023 The MathWorks, Inc.

    indices = convertToForwardTF(indices);
    updates = convertToForwardTF(updates);
    shape = convertToForwardTF(shape);

    idxval = indices.value;
    updatesval = updates.value;
    updatesrank = updates.rank;
    shapeval = shape.value;
    
    if isdlarray(shapeval)
        shapeval = shapeval.extractdata;
    end
    
    updatesShape = size(updatesval);
    if (numel(updatesShape)) < updatesrank
        % Add back dropped singletons
        numDroppedDims = xrank - numel(updatesShape);
        updatesShape(end+1:end+numDroppedDims) = 1;
    elseif (numel(updatesShape)) > updatesrank
        % only in case of rank 1
        updatesShape(end) = [];
    end
    
    zrank = numel(shapeval);

    if numel(updatesShape) == numel(shapeval') && all(updatesShape == shapeval')
        % Output same as updates
        zval = updatesval;
    else    
        if zrank <=1
            zval = zeros([shapeval 1]);
        else
            zval = zeros(shapeval');
        end    
        nSpecs = size(idxval,1);
        idxval = idxval + 1;    
        for i = 1:nSpecs
            curIdxVal = num2cell(idxval(i,:));
            if numel(curIdxVal) == zrank
                % Fully specified indices
                zval(curIdxVal{:}) = updatesval(i);
            else
                % Partially specified indices
                numIdx = numel(curIdxVal);
                numShape = numel(shapeval);
                extraDimsNeeded = numShape - numIdx;
                curIdxVal(end+1:end+extraDimsNeeded) = {':'};            
                curUpdatesIdxVal = {i};
                curUpdatesIdxVal(end+1:end+extraDimsNeeded) = {':'};
                zval(curIdxVal{:}) = updatesval(curUpdatesIdxVal{:});
            end
        end
    end
    
    if zrank > 1
        % permute to reverse TF
        zval = permute(zval, zrank:-1:1);
        datalabel = repmat('U', [1 zrank]);
    else
        datalabel = 'UU';
    end
    zval = dlarray(zval, datalabel);
    z = struct('value', zval, 'rank', zrank); 
end

function [x] = convertToForwardTF(x)
    %{{import_statement}}
    if isdlarray(x.value) && ~isempty(x.value.dims) && ~all(x.value.dims == 'U')
        DLTLabels = x.value.dims; 
        [permutationVec] = sortToTFLabel(1:x.rank, DLTLabels);
        x.value = stripdims(x.value);
        if x.rank > 1
            x.value = permute(x.value, permutationVec);
        end
    elseif isdlarray(x.value) && (isempty(x.value.dims) || all(x.value.dims == 'U'))
        if x.rank > 1
            x.value = permute(x.value, x.rank:-1:1);
        end
    end 
end 