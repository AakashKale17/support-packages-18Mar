function [z, updatedMean, updatedVariance] = tfFusedBatchnormV3(...
    x, tfscale, tfoffset, tfmean, tfvariance, isTraining, epsilon, dataFormat)
    %{{import_statement}}
    
%   Copyright 2020-2022 The MathWorks, Inc.
    % FusedBatchNormV3
    
    % Input verification
    if ~ismember(x.rank, [4 5])
        error('FusedBatchNormV3 is only supported for input tensors having a rank of 4 or 5.');
    end
    
    if ~ismember(dataFormat, ["NHWC" "NDHWC"])
        error('FusedBatchNormV3 is only supported for input data formats: "NHWC" and "NDHWC"');
    end

    if isa(x.value, 'dlarray')
        xLabels = x.value.dims;
    else
        xLabels = [];
    end

    switch dataFormat
            case "NHWC"
                TFXLabels = "BSSC";
            case "NDHWC"
                TFXLabels = "BSSSC";            
    end
        
    % If the input tensor is unlabeled. We assume it is in reverse TensorFlow order
    if isempty(xLabels) || all(xLabels == 'U')        
        % Permute to forward tensorflow format and apply labels
        x.value = permute(stripdims(x.value), x.rank:-1:1); 
        x.value = dlarray(x.value, TFXLabels);     
    end

    tfoffset = tfoffset.value; 
    tfscale = tfscale.value; 
    tfmean = tfmean.value; 
    tfvariance = tfvariance.value; 
    
    if isTraining
        [z, updatedMean, updatedVariance] = batchnorm(x.value, tfoffset, tfscale, tfmean, tfvariance, 'Epsilon', epsilon); 
    else
        z = batchnorm(x.value, tfoffset, tfscale, tfmean, tfvariance, 'Epsilon', epsilon); 
        updatedMean = tfmean;
        updatedVariance = tfvariance;
    end
    
    % forward the rank. 
    z = struct('value', z, 'rank', x.rank); 
    if nargout > 1 
        updatedMean = struct('value', updatedMean, 'rank', 1); 
        updatedVariance = struct('value', updatedVariance, 'rank', 1); 
    end
end
