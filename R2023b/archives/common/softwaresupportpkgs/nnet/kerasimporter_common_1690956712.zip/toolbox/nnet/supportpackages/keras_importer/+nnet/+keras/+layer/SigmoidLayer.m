classdef SigmoidLayer < nnet.layer.Layer ...
    & nnet.internal.cnn.layer.Traceable
% SigmoidLayer   Sigmoid layer
%
%   layer = SigmoidLayer(Name) creates a sigmoid unit layer with
%   name Name. This type of layer calculates Y = 1./(1+exp(-X)).

%   Copyright 2017-2020 The MathWorks, Inc.
    methods
        function this = SigmoidLayer(Name)
            this.Name = Name;
            this.Description = getString(message('nnet_cnn_kerasimporter:keras_importer:SigmoidDescription'));
            this.Type = getString(message('nnet_cnn_kerasimporter:keras_importer:SigmoidType'));
        end
        
        function Z = predict(~, X)
            Z = 1./(1+exp(-X));
        end
        
        function dLdX = backward(~, ~, Z, dLdZ, ~)
            dLdX = dLdZ.*Z.*(1-Z);
        end
    end
end
