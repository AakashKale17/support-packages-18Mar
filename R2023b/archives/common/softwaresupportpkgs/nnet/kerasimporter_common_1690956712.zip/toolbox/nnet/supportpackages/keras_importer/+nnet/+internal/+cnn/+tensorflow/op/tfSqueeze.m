function Y = tfSqueeze(X, axis)
    %{{import_statement}}

%   Copyright 2020-2022 The MathWorks, Inc.
    
    xrank = X.rank;
    x = X.value;

    if isa(x, 'dlarray')
        xlabels = x.dims;
        x = stripdims(x);
    else
        xlabels = [];
    end
        
    % Non-formatted dlarray data will be assumed to have reverse TF format. 
    % So no permutation will occur. 
    if ~isempty(xlabels) && ~all(xlabels == 'U') && xrank > 1
        [permutex, ~] = sortToTFLabel(1:xrank, xlabels);
        x = permute(x, fliplr(permutex));
    end 

    if isstruct(axis)
        axis = axis.value;
    end

    % If axis is a dlarray extract the numeric value
    if isa(axis, 'dlarray')
        axis = axis.extractdata;
    end
        
    reshape_vector = [];
    initialRank = xrank; 
    if isempty(axis)
        % No axis specified, remove all 1 dimensions
        for i = initialRank:-1:1
            if size(x, i)~=1            
                reshape_vector(end+1) = size(x, i); %#ok<AGROW>
            else
                xrank = xrank - 1; 
            end
        end
        % We filled reshape vector in the reverse order over 
        % input in reverse TF format, so it is in fwd TF format
        % we flip it to make it consistent with the input, i.e. in reverse tf format
        reshape_vector = fliplr(reshape_vector);
    else
        % Axis specified, only remove dimensions of size 1 at the specified
        % axes values
        if any(axis < 0)
        % Handle negative axis values
            negIdx = axis < 0;
            axis(negIdx) = mod(axis(negIdx), initialRank);
        end        
        MLAxis = initialRank - axis;
        
        for i = initialRank:-1:1
            if ismember(i, MLAxis) && size(x,i) == 1
                xrank = xrank - 1;                
            else
                reshape_vector(end+1) = size(x, i); %#ok<AGROW>
            end
        end
        % We filled reshape vector in the reverse order over 
        % input in reverse TF format, so it is in fwd TF format
        % we flip it to make it consistent with the input, i.e. in reverse tf format
        reshape_vector = fliplr(reshape_vector);
    end
    
    % reshape_vector has dimension sizes in reverse TF format
    % x is in reverse TF format
    if numel(reshape_vector) > 1
        Y = reshape(x,reshape_vector);
    else
        Y = x(:);
    end
    
    if xrank > 1
        Y = dlarray(Y, repmat('U', [1 xrank]));
    else
        Y = dlarray(Y, 'UU');
    end 
    
    % Y will be in reverse-TF format with all U labels 
    Y = struct('value', Y, 'rank', xrank);
end
