function result = translateRelu6(~, MATLABOutputName, MATLABArgIdentifierNames)
%

%   Copyright 2020-2021 The MathWorks, Inc.

    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult;
    
    call = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall("relu", {MATLABOutputName + ".value"}, {MATLABArgIdentifierNames{1} + ".value"}); 
    call = call + newline + MATLABOutputName  + ".value" + " = min(" + MATLABOutputName + ".value, 6);"; 
    result.Code = call; 
    result.ForwardRank = true;
    result.NumOutputs = 1;
    result.Success = true; 
end 
