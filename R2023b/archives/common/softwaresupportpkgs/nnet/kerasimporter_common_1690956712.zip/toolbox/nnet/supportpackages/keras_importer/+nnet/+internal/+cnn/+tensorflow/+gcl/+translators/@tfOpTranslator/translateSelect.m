function result = translateSelect(~, ~, MATLABOutputName, MATLABArgIdentifierNames)
    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult;
    
    result.Code = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall("tfSelect", ...
                    {MATLABOutputName}, MATLABArgIdentifierNames);
    result.ForwardRank = false; 
    result.NumOutputs = 1; 
    result.OpFunctions = "tfSelect";
    result.IsCommenting = false; 
    result.Success = true; 
end