function z = tfTile(x, multiples)
    %{{import_statement}}
   
%   Copyright 2020-2022 The MathWorks, Inc.

    xval = x.value; 
    xrank = x.rank; 
    
    if isstruct(multiples)
        multiplesval = multiples.value;
    else
        multiplesval = multiples;
    end

    % If multiplesval is a dlarray extract the numeric value
    if isa(multiplesval, 'dlarray')
        multiplesval = multiplesval.extractdata;
    end
    
    hasLabel = false;
    if isa(xval, 'dlarray') && ~isempty(xval.dims) && ~all(xval.dims == 'U')
        [permutationVec, tflabels]= sortToTFLabel(1:xrank, xval.dims); 
        hasLabel = true; 
        xval = stripdims(xval);
        if xrank > 1
            xval = permute(xval, permutationVec); 
        end
        % Now xval is in Forward TF format
    else
        % xval is in reverse TF format
        if xrank > 1
            xval = permute(xval, xrank:-1:1); 
        end
        % Now xval is in Forward TF format
    end 

    for i = 1:numel(multiplesval) 
        repvec = ones(1, numel(multiplesval)); 
        repvec(i) = multiplesval(i); 
        xval = repmat(xval, repvec); 
    end 
    
    if hasLabel
        z = dlarray(xval, tflabels); 
    else
        % permute xval back to reverse TF format
        if xrank > 1
            xval = permute(xval, xrank:-1:1); 
            z = dlarray(xval, repmat('U', [1 xrank]));
        else
            z = dlarray(xval, 'UU');
        end 
    end

    % zero gradient skip connection. 
    if isa(multiples, 'dlarray')
        z = z + sum(multiplesval.stripdims, 'all') * 0; 
    end
    z = struct('value', z, 'rank', xrank); 
end