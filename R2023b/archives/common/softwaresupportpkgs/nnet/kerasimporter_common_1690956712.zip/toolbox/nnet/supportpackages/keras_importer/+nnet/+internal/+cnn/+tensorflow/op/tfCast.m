function z = tfCast(x, DstT)
    %{{import_statement}}    

%   Copyright 2020-2021 The MathWorks, Inc.
    xlabels = '';
    if isa(x.value, 'dlarray')
        xlabels = x.value.dims; 
    end 

    switch DstT
        case 'DT_FLOAT'
            z = cast(single(x.value), 'like', x.value); 
        case 'DT_DOUBLE'
            z = double(x.value); 
        case 'DT_INT8'
            z = cast(  int8(floor(iGetValueFromStruct(x))), 'like', x.value); 
        case 'DT_INT16'
            z = cast( int16(floor(iGetValueFromStruct(x))), 'like', x.value); 
        case 'DT_INT32'
            z = cast( int32(floor(iGetValueFromStruct(x))), 'like', x.value); 
        case 'DT_INT64'
            z = cast( int64(floor(iGetValueFromStruct(x))), 'like', x.value); 
        case 'DT_UINT8'
            z = cast( uint8(floor(iGetValueFromStruct(x))), 'like', x.value); 
        case 'DT_UINT16'
            z = cast(uint16(floor(iGetValueFromStruct(x))), 'like', x.value); 
        case 'DT_UINT32'
            z = cast(uint32(floor(iGetValueFromStruct(x))), 'like', x.value); 
        case 'DT_UINT64'
            z = cast(uint64(floor(iGetValueFromStruct(x))), 'like', x.value);
        case 'DT_BOOL'
            z = logical(x.value);
        otherwise
           assert(false)
    end

    if ~isempty(xlabels)
        z = dlarray(z,xlabels);
    end
end 

function y = iGetValueFromStruct(x) 
    if isa(x.value, 'dlarray')
        y = extractdata(x.value); 
    else 
        y = x.value; 
    end 
end 
