function result = translateAssignVariableOp(~)
    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult; 
    result.Code = ""; 
    result.Success = true; 
    result.ForwardRank = false; 
end