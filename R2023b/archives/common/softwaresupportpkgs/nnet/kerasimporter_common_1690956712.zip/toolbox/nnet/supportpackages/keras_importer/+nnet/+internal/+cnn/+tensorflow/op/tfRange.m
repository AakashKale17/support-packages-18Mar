function z = tfRange(start, lim, delta)
    %{{import_statement}}

%   Copyright 2020-2021 The MathWorks, Inc.

    start = start.value; 
    lim = lim.value; 
    delta = delta.value;
    if delta >= 0
        z.value = single(start):single(delta):single(lim-1); 
        z.value = cast(z.value, 'like', start); 
    else 
        z.value = single(start):single(delta):single(lim+1); 
        z.value = cast(z.value, 'like', start); 
    end
    if ~isfloat(z.value)
        z.value = cast(z.value, 'single'); 
    end 
    z.value = dlarray(z.value', "UU");
    z.rank = 1; 
    % zero gradient skip connection. 
    z.value = z.value + (sum(start, 'all') + sum(lim, 'all') + sum(delta, 'all')) * 0; 
    
end 
