function x = tfReshape(x, tfShape)
    %{{import_statement}}

%   Copyright 2020-2022 The MathWorks, Inc.

    newShape = tfShape.value; 
    outrank = numel(newShape); 
    % This algorithm assumes that the newShape will adhere to TensorFlow
    % Dimension labels. We permute the input tensor x to TensorFlow dimension
    % ordering. Then, we follow the same reshape as newShape and
    % then permute back to Deep Learning Toolbox dimension ordering. 
    if isa(newShape, 'dlarray')
        newShape = extractdata(newShape);
    end
    
    newShape = num2cell(newShape(:)'); 
    for i = 1:outrank
        if newShape{i} == -1
            newShape{i} = []; 
        end 
    end 

    if isa(x.value, 'dlarray') && ~isempty(x.value.dims) && ~all(x.value.dims == 'U') && x.rank > 1
        DLTLabels = x.value.dims; 
        [shapePermutationVec, TFLabels] = sortToTFLabel(1:x.rank, DLTLabels); 
        
        % TensorFlow reshapes are row major reshapes. It is the same as a
        % col major reshape (the default reshape in MATLAB) when x is in 
        % reverse TensorFlow dimension order and when the reshape entries 
        % are reversed.
        x.value = permute(x.value.stripdims, flip(shapePermutationVec)); 
        x.value = reshape(x.value, newShape{end:-1:1});
                 
        if numel(DLTLabels) == outrank
            % We take the heuristic that the labels are the same if the number of dimensions did not change. 
            % Re-apply dimension labels back to the tensor, we will need to permute to forward TensorFlow  
            % dimension order first.
            if outrank > 1
                x.value = permute(x.value, outrank:-1:1); 
            end
            datalabel = TFLabels; 
        else 
            % the output tensor has a different number of dimensions. 
            % keep the output tensor in reverse TF format and apply all U labels
            if outrank > 1
                datalabel = char('U' + zeros(1, outrank));
            else
                datalabel = 'UU';
            end
        end
    else 
        % x is not a labeled dlarray so we can assume that x is already in 
        % reverse TensorFlow ordering and reshape accordingly. A row major reshape
        % will require us to flip the reshape values. 
        if outrank == 1
            % for a rank-1 tensor output append a 1 to the new shape
            newShape{end + 1} = 1;
        end
        
        if outrank > 1
            x.value = reshape(x.value, newShape{end:-1:1});
            datalabel = char('U' + zeros(1, outrank));
        else
            x.value = reshape(x.value, newShape{1:end}); 
            datalabel = 'UU';
        end
    end
    x.value = dlarray(x.value, datalabel);
    % zero gradient skip connection. 
    x.value = x.value + (sum(tfShape.value(:), 'all') * 0); 
    x.rank = outrank;
end
