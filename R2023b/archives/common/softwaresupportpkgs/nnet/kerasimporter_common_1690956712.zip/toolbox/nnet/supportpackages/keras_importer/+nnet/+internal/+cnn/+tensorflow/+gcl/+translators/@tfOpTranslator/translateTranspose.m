function result = translateTranspose(~, MATLABOutputName, MATLABArgIdentifierNames)
%

%   Copyright 2022 The MathWorks, Inc.

    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult; 
    result.Code = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall("tfTranspose", {MATLABOutputName}, MATLABArgIdentifierNames);
    
    result.ForwardRank = false;
    result.Success = true;
    result.OpFunctions = "tfTranspose";
end 
