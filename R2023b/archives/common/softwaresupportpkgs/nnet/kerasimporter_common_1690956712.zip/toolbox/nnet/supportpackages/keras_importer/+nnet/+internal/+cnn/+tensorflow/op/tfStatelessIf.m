function result = tfStatelessIf(cond)

%  cond : A Tensor. If the tensor is a scalar of
%         non-boolean type, the scalar is converted 
%         to a boolean according to the following rule: 
%         if the scalar is a numerical value, non-zero means True 
%         and zero means False; if the scalar is a string, non-empty means 
%         True and empty means False. If the tensor is not a scalar, being 
%         empty means False and being non-empty means True.
% 
%  Copyright 2022-2023 The MathWorks, Inc.
   
    condval = cond.value;
    condrank = cond.rank;
   
    if condrank == 0
        % scalar condition
        if isnumeric(condval) || islogical(condval)
            if condval ~= 0
                result = true;
            else
                result = false;
            end
        elseif isstring(condval)
            if isempty(condval)
                result = false;
            elseif (condval == "")
                result = false;
            else
                result = true;
            end
        elseif ischar(condval)
            if isempty(condval)
                result = false;            
            else
                result = true;
            end
        end
        return
    else
        % non-scalar condition
        if isempty(condval)
            result = false;            
        else
            result = true;
        end
    end
end
