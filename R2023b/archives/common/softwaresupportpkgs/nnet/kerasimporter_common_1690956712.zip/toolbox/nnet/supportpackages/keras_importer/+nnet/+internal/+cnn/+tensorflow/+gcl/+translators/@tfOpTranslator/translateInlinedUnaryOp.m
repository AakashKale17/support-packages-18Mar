function result = translateInlinedUnaryOp(~, fcnName, MATLABOutputName, MATLABArgIdentifierNames)
    % Translate a node into code that directly inlines built-in functions. 

%   Copyright 2020-2021 The MathWorks, Inc.
    
    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult; 
    result.Code = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall(fcnName, {MATLABOutputName + ".value"}, {MATLABArgIdentifierNames{1} + ".value"});
    result.ForwardRank = true;
    result.NumOutputs = 1;
    
    result.IsCommenting = true; 
    result.Success = true; 
end 
