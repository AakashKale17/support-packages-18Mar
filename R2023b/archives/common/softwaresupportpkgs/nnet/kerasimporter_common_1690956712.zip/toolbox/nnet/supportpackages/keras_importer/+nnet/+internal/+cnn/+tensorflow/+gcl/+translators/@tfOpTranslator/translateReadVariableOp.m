function result = translateReadVariableOp(this, node_def, MATLABOutputName, MATLABArgIdentifierNames)
%

%   Copyright 2020-2021 The MathWorks, Inc.

    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult; 
    call = MATLABOutputName + ".value" + " = " + MATLABArgIdentifierNames{1} + ";";
    variablendims = numel(node_def.attr.x_output_shapes.list.shape.dim); 
    call = call + newline + writeRankInitializationCode(this, MATLABOutputName, variablendims);
    result.Code = call;
    result.NumOutputs = 1; 
    result.ForwardRank = false; 
    result.Success = true; 
end 
