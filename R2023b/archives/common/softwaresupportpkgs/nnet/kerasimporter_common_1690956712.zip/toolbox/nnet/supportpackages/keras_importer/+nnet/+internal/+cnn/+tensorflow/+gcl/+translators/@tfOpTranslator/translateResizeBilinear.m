function result = translateResizeBilinear(~, node_def, MATLABOutputName, MATLABArgIdentifierNames)
    % Copyright 2021 The MathWorks, Inc.
    
    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult; 
    
    half_pixel_centers = "'asymmetric'"; 
    if isfield(node_def.attr, 'half_pixel_centers')
        if node_def.attr.half_pixel_centers.b
            half_pixel_centers = "'half-pixel'";
        end 
    end 
    
    result.Code = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall("dlresize", {MATLABOutputName + ".value"}, [{"iAddDataFormatLabels(" + MATLABArgIdentifierNames(1) + ")"} ...
        {"'OutputSize'"} {"single(" + MATLABArgIdentifierNames{2} + ".value" + "(:)')"}, {"'GeometricTransformMode'", half_pixel_centers} {"'Method'", "'linear'"}]);
    
    result.IsCommenting = false; 
    result.ForwardRank = true;
    result.NumOutputs = 1; 
    result.Success = true;
end 
