function sz = tfSize(in)
%{{import_statement}}

%   Copyright 2022 The MathWorks, Inc.
    
    % Evaluate size of the input tensor:
    sz = dlarray(numel(in.value), 'UU');
    
    % assign output rank, which is always 0 
    sz = struct('value', sz, 'rank', 0);
end