function z = tfFill(dims, value)
    %{{import_statement}}
    % Copyright 2022 The MathWorks, Inc.

    % Get the values and ensure they are in a row vector. 
    assert(dims.rank <= 1, "tfFill: dims is not 1D.");
    assert(value.rank == 0, "tfFill: value to fill is not a scalar.")

    % convert dims to a row vector
    shape = dims.value(:)'; 
    value = value.value; 
    
    if isa(shape, 'dlarray')
        if ~isempty(shape.dims) && ~all(shape.dims == 'U')
            warning(['tfFill dims has DLT labels: ' shape.dims]);
        end
        shape = extractdata(shape); 
    end
    
    zrank = numel(shape);
    
    if zrank == 1
    % Shape of 1D tensors is kept as is
    % but here we reverse this shape
    % so that the logic below reverses it again
    % to be same as that in TF
        shape = [1 shape];
    end
    
    % generate the ones to have the same shape as reverse tensorflow
    zvalue = ones(shape(end:-1:1), 'like', value) .* value;

    if zrank > 1
       zvalue = dlarray(zvalue, repmat('U', [1 zrank]));
    else
       zvalue = dlarray(zvalue, 'UU');
    end
    
    z = struct('value', zvalue, 'rank', zrank);
end