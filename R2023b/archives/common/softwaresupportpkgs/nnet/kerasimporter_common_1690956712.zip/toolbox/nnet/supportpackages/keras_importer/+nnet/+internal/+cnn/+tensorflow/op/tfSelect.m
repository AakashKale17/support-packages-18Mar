function z = tfSelect(condition, x, y)
%{{import_statement}}

%   Copyright 2022 The MathWorks, Inc.

    xrank = x.rank; 
    xval = x.value; 
    yrank = y.rank;
    yval = y.value; 
    crank = condition.rank;
    cval = condition.value;
    
    % x and y should have the same rank (and shape)
    assert(xrank == yrank, "tfSelect: ranks of x and y are different.");
    assert(crank == xrank, "tfSelect: ranks of condition and x are different. This is not currently supported.");
    zrank = xrank;
        
    if xrank == 0 % assume y and condition are scalars
        if cval
            z.value = xval;
        else
            z.value = yval;
        end
        z.rank = zrank; 
        return; 
    end 
    
    isXDLTFormat = isa(xval, 'dlarray') && ~isempty(xval.dims) && ~all(xval.dims == 'U') && xrank > 1;     
    if isXDLTFormat 
        [xPermutationVec, xtflabel] = sortToTFLabel(1:xrank, xval.dims); 
        xval = stripdims(xval);
        xval = permute(xval, flip(xPermutationVec)); 
    elseif isa(xval, 'dlarray')
        xval = stripdims(xval); 
    end 
    
    isYDLTFormat = isa(yval, 'dlarray') && ~isempty(yval.dims) && ~all(yval.dims == 'U') && yrank > 1;
    if isYDLTFormat
        [yPermutationVec, ~] = sortToTFLabel(1:yrank, yval.dims); 
        yval = stripdims(yval);
        yval = permute(yval, flip(yPermutationVec)); 
    elseif isa(yval, 'dlarray')
        yval = stripdims(yval); 
    end

    isCDLTFormat = isa(cval, 'dlarray') && ~isempty(cval.dims) && ~all(cval.dims == 'U') && crank > 1;
    if isCDLTFormat
        [cPermutationVec, ~] = sortToTFLabel(1:crank, cval.dims); 
        cval = stripdims(cval);
        cval = permute(cval, flip(cPermutationVec)); 
    elseif isa(cval, 'dlarray')
        cval = stripdims(cval); 
    end

    % xval, yval and cval should be in reverse Tf format at this point.
    if isequal(numel(size(cval)),numel(size(xval)))
        % condition has the same shape as x and y
        zval = xval;
        zval(~cval) = yval(~cval);
    else        
        % If condition is rank 1, x may have higher rank, 
        % but its first dimension must match the size of condition. This is not currently supported.       
        warning('tfSelect ranks of condition and x are different. This is not currently supported.');
    end

    if isXDLTFormat % Can check the other inputs for labels as well
        if zrank > 1
            zval = permute(zval, zrank:-1:1); 
        end 
        zval = dlarray(zval, xtflabel);    
    else 
        if zrank > 1
            zval = dlarray(zval, repmat('U', [1 zrank])); 
        else
            zval = dlarray(zval, 'UU'); 
        end
    end
    z = struct('value', zval, 'rank', zrank); 
end 
