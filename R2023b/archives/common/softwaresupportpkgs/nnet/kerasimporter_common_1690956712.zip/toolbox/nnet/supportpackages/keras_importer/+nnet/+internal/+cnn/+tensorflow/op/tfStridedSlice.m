function [z] = tfStridedSlice(x, beginIdx, endIdx, strideIdx, beginMask, endMask, ellipsisMask, newAxisMask, shrinkMask)
%{{import_statement}}

%   Copyright 2020-2023 The MathWorks, Inc.

xval = x.value;
xrank = x.rank; 

if isempty(xval)
    % Nothing to slice
    z = x;
    return;
end

beginIdx = beginIdx.value;
endIdx = endIdx.value;
strideIdx = strideIdx.value;

nSpecs = numel(beginIdx); 
if isempty(beginMask)
    beginMask = 0; 
end
if isempty(endMask)
    endMask = 0;
end
if isempty(ellipsisMask)
    ellipsisMask = 0; 
end
if isempty(newAxisMask)
    newAxisMask = 0; 
end
if isempty(shrinkMask)
    shrinkMask = 0; 
end

beginMask = fliplr(dec2bin(beginMask, nSpecs)); 
endMask = fliplr(dec2bin(endMask, nSpecs));
ellipsisMask = fliplr(dec2bin(ellipsisMask, nSpecs)); 
newAxisMask = fliplr(dec2bin(newAxisMask, nSpecs)); 
shrinkMask = fliplr(dec2bin(shrinkMask, nSpecs)); 

if isa(xval, 'dlarray') && ~isempty(xval.dims) && ~all(xval.dims=='U')
    inputIsLabeled = true;
    datalabel = xval.dims;
    [permutationVec, datalabel] = sortToTFLabel(1:xrank, datalabel);
    xval = stripdims(xval);
    if xrank > 1
        xval = permute(xval, permutationVec);
    end
else
    inputIsLabeled = false;
    if xrank > 1
        xval = permute(xval, xrank:-1:1); 
        datalabel = repmat('U', [1 xrank]);
    else
        datalabel = 'UU';
    end
end

% xval should be in fwd TF order now
xShape = size(xval);
if (numel(xShape)) < xrank
    % Add back dropped singletons
    numDroppedDims = xrank - numel(xShape);
    xShape(end+1:end+numDroppedDims) = 1;
elseif (numel(xShape)) > xrank
    % only in case of rank 1
    xShape(end) = [];
end

newShape = xShape;
for i = 1:nSpecs
    if (newAxisMask(i)=='1')
        % New axis added at the i'th dimension
        newShape(i+1:end+1) = newShape(i:end);
        newShape(i) = 1;
    elseif (ellipsisMask(i)=='1')
        if (numel(newShape) - i) > (nSpecs - i)
            % More than one axis covered by elipsis starting at i
            % Expand the Specs            
            nDimsElipsis = (numel(newShape) - i) - (nSpecs - i);
            nSpecs = nSpecs + nDimsElipsis;
            beginIdx(i+nDimsElipsis+1:end+nDimsElipsis) = beginIdx(i+1:end);
            endIdx(i+nDimsElipsis+1:end+nDimsElipsis) = endIdx(i+1:end);
            strideIdx(i+nDimsElipsis+1:end+nDimsElipsis) = strideIdx(i+1:end);
            beginMask(i+nDimsElipsis+1:end+nDimsElipsis) = beginMask(i+1:end);
            endMask(i+nDimsElipsis+1:end+nDimsElipsis) = endMask(i+1:end);
            ellipsisMask(i+nDimsElipsis+1:end+nDimsElipsis) = ellipsisMask(i+1:end);
            newAxisMask(i+nDimsElipsis+1:end+nDimsElipsis) = newAxisMask(i+1:end);
            shrinkMask(i+nDimsElipsis+1:end+nDimsElipsis) = shrinkMask(i+1:end);          
            
            % Set the masks to default values for the expanded specs
            beginIdx(i+1:i+nDimsElipsis) = 0;
            endIdx(i+1:i+nDimsElipsis) = 0;
            strideIdx(i+1:i+nDimsElipsis) = 1;        
            beginMask(i+1:i+nDimsElipsis) = '1';
            endMask(i+1:i+nDimsElipsis) = '1';
            ellipsisMask(i+1:i+nDimsElipsis) = '0';
            newAxisMask(i+1:i+nDimsElipsis) = '0';
            shrinkMask(i+1:i+nDimsElipsis) = '0';
        end        
    end
end

if xrank > nSpecs && ~any(find(ellipsisMask=='1'))
    % If the indexing dimensions are less than the rank of the input tensor
    % and ellipsisMask is all 0's
    % pad beginIdx, endIdx and strideIdx with default values
    numUnSpecDims = xrank - nSpecs;
    % get fwd TF shape to fill the remaining endIdx
    endIdx(end+1 : end+numUnSpecDims) = xShape(nSpecs+1:end);
    beginIdx(end+1 : end+numUnSpecDims) = 0;
    strideIdx(end+1 : end+numUnSpecDims) = 1;
    
    % pad the masks with 0's
    beginMask(end+1 : end+numUnSpecDims) = '0';
    endMask(end+1 : end+numUnSpecDims) = '0';
    shrinkMask(end+1 : end+numUnSpecDims) = '0';
    ellipsisMask(end+1 : end+numUnSpecDims) = '0';
    newAxisMask(end+1 : end+numUnSpecDims) = '0';
    nSpecs = nSpecs + numUnSpecDims;
end

zrank = numel(newShape);
if numel(newShape) > 1
    xval = reshape(xval,newShape);     
end				  

S = substruct('()', {});
for i = 1:nSpecs
    % Build the substruct for each dimension.
    if (newAxisMask(i)=='1')
        S.subs{i} = 1:size(xval, i);
    elseif (ellipsisMask(i)=='1')
        % Ellipsis used for indexing the i'th dimension
        % select all elements from that dimension
        S.subs{i} = 1:size(xval, i);
    elseif (shrinkMask(i)=='1')
        S.subs{i} = beginIdx(i) + 1;        
    else
        curBeginIdx  = mod(beginIdx(i), size(xval,i)) + 1; 
        curStrideIdx = strideIdx(i);

        if strcmp(beginMask(i), '1')
            if curStrideIdx >= 0      
                curBeginIdx = 1; 
            else
                curBeginIdx = size(xval, i); 
            end
        end 

        if strcmp(endMask(i), '1')
            if curStrideIdx >= 0      
                curEndIdx = size(xval, i);
            else
                curEndIdx = 0; 
            end
        else
            if endIdx(i) >= 0
                if curStrideIdx >= 0      
                    curEndIdx = endIdx(i);
                else
                    curEndIdx = endIdx(i) + 1;
                end                 
            else 
                if curStrideIdx >= 0      
                    curEndIdx = mod(endIdx(i), size(xval, i));
                else
                    curEndIdx = mod(endIdx(i), size(xval, i)) + 1;
                end
            end
        end
    
        if curStrideIdx >= 0        
            idxVec = curBeginIdx:curStrideIdx:curEndIdx; 
        else
            if curEndIdx > curBeginIdx
                idxVec = curEndIdx:curStrideIdx:curBeginIdx; 
            else
                curEndIdx = curEndIdx + 1;
                idxVec = curBeginIdx:curStrideIdx:curEndIdx ;
            end
        end         
        S.subs{i} = idxVec;         
    end
end 

% Return the indexed array x, with the same number of dimensions.
zval = subsref(xval, S); 

if xrank ~= zrank || ~inputIsLabeled
    if zrank > 1
        % permute back to reverse TF
        zval = permute(zval, zrank:-1:1);
        datalabel = repmat('U', [1 zrank]);
    else
        datalabel = 'UU';
    end
end
    
zval = dlarray(zval, datalabel); 
z = struct('value', zval, 'rank', zrank); 

if(any(find(shrinkMask=='1')))
    % tfSqueeze expects 0-based axes (from TF)
    z = tfSqueeze(z, find(shrinkMask=='1') - 1); 
end
end

