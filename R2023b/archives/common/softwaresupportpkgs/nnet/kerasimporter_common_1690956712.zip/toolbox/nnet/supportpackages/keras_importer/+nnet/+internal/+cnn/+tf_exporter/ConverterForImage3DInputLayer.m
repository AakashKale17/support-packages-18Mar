classdef ConverterForImage3DInputLayer < nnet.internal.cnn.tf_exporter.ConverterForImageInputLayers

    %   Copyright 2022 The MathWorks, Inc.

end