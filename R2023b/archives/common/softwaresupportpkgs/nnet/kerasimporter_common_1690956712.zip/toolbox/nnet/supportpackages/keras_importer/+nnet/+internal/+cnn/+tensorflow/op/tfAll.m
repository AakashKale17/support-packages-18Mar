function z = tfAll(x, axis, keep_dims)
%{{import_statement}}

%   Copyright 2022 The MathWorks, Inc.
   
    xval = x.value;
    xrank = x.rank;
    zrank = xrank;

    if xrank == 0
        z = struct('value', xval, 'rank', xrank);
        return
    end

    if any(axis.value < 0)
    % Handle negative axis values
        negIdx = axis.value < 0;
        axis.value(negIdx) = xrank + axis.value(negIdx);
    end
        
   if isa(xval, 'dlarray') && ~isempty(xval.dims) && ~all(xval.dims =='U')
        DLTLabel = xval.dims;
        [permutationVec, TFLabels] = sortToTFLabel(1:ndims(xval), DLTLabel); 
        xval = permute(xval.stripdims, permutationVec);
        MLAxis = axis.value + 1; 
        z = all(xval, MLAxis); 
    else 
        TFLabels = repmat('U', [1 xrank]);
        % reverse TF
        MLAxis = xrank - axis.value; 
        z = all(xval, MLAxis); 
   end

   if ~keep_dims
        outsize = ones(1, xrank); 
        outsize(1:ndims(z)) = size(z); 
        outsize(MLAxis) = [];
        TFLabels(MLAxis) = [];
        
        zrank = xrank - numel(MLAxis); 
        if zrank > 1
            z = reshape(z, outsize);
        else 
            reshape(z, [outsize 1 1]); 
            TFLabels(end + 1) = 'U'; 
        end 
    end
    
    z = dlarray(single(z), TFLabels);
    z = struct('value', z, 'rank', zrank);
end
