function result = translateRsqrt(~, MATLABOutputName, MATLABArgIdentifierNames)
%

%   Copyright 2020-2021 The MathWorks, Inc.

    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult; 
    result.Code = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall("sqrt", {MATLABOutputName + ".value"}, strcat("1./(", MATLABArgIdentifierNames{1} + ".value" , ")"));
    result.ForwardRank = true; 
    result.NumOutputs = 1; 
    result.Success = true; 
end 
