function z = tfAddN(varargin) 
%{{import_statement}}

%   Copyright 2020-2021 The MathWorks, Inc.

    z.value = varargin{1}.value; 
    z.rank = varargin{1}.rank; 

    for i = 2:nargin
        z = tfAdd(z, varargin{i}); 
    end
end
