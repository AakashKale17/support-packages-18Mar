function z = tfTensorListReserve(element_shape, num_elements)
    %{{import_statement}}

%   Copyright 2023 The MathWorks, Inc.

    % The TensorListReserve operator returns a TensorList tensor:
    %   tf.Tensor(<TensorList>, shape=(), dtype=variant)
    % 
    % Hence, tfTensorListReserve returns an array of structs, each holding a 
    % dlarray and its rank.
    % 
    % element_shape: The only valid scalar shape tensor is the fully unknown 
    % shape specified as -1 can only be -1 if it is a scalar else it has to
    % be a rank 1 tensor containing the shape of the tensor elements to be 
    % reserved, hence this will always be in forward TF format
    tensor_shape = element_shape.value; 
    tensor_shape_rank = element_shape.rank;

    % num_elemets: The num_elements to reserve must be a non negative scalar
    num_elements = num_elements.value;

    z = [];

    if tensor_shape_rank == 0 && tensor_shape == -1
        elem_tensor = dlarray.empty;
        element = struct('value', elem_tensor, 'rank', -1);        
    else
        elem_rank = numel(tensor_shape);
        if elem_rank <= 1
            % Forward TF format
            elem_tensor = dlarray(zeros([tensor_shape 1]),'UU');
            element = struct('value', elem_tensor, 'rank', elem_rank);
        else
            % Reverse TF format as rank > 1            
            elem_tensor = dlarray(zeros(flip(tensor_shape)), repmat('U', [1 elem_rank]));
            element = struct('value', elem_tensor, 'rank', elem_rank);
        end         
    end
    
    for i = 1:num_elements
        z = [z element]; %#ok<AGROW>
    end
end
