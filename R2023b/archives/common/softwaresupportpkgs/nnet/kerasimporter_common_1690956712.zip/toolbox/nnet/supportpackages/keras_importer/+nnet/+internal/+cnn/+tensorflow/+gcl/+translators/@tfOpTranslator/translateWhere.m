function result = translateWhere(~, ~, MATLABOutputName, MATLABArgIdentifierNames)
    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult;
    
    result.Code = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall("tfWhere", ...
                    {MATLABOutputName}, MATLABArgIdentifierNames);
    result.ForwardRank = false; 
    result.NumOutputs = 1; 
    result.OpFunctions = "tfWhere";
    result.IsCommenting = false; 
    result.Success = true; 
end