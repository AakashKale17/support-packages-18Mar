function z = tfMin(x, axis, keep_dims)
    %{{import_statement}}

%   Copyright 2023 The MathWorks, Inc.

    xval = x.value; 
    xrank = x.rank;

    if isstruct(axis)
        axis = axis.value;
    end
	
    % If labeled dlarray then permute to reverse TF dimension order
    if isa(xval, 'dlarray') && ~isempty(xval.dims) && ~all(xval.dims == 'U') && xrank > 1
        DLTLabel = xval.dims;
        [permutationVec, TFLabels] = sortToTFLabel(1:xrank, DLTLabel); 
        xval = permute(xval.stripdims, fliplr(permutationVec));
    % Assign empty labels if x is not a dlarray or if all Us or if rank <= 1
    else 
        TFLabels = ''; 
    end 
    
    % If axis is a dlarray extract the numeric value
    if isa(axis, 'dlarray')
        axis = axis.extractdata;
    end

    % Handle negative axis values
    if axis < 0
       axis = xrank + axis;
    end
    
    % Reverse TF dimension order
    MLAxis = (xrank - axis);
    if x.rank <= 1
        z = min(xval(:), [], MLAxis); 
    else 
        z = min(xval, [], MLAxis); 
    end 
    
    % Handle labels
    if keep_dims && ~isempty(TFLabels)
        z = permute(z,fliplr(1:xrank));
        z = dlarray(z, TFLabels);
        zrank = xrank;
        
    elseif ~keep_dims && ~isempty(TFLabels) 
        % z is in reverse TF dimension ordering
        newShape = size(z);
        newShape(MLAxis)= [];
        
        if numel(newShape) == 1
            z = reshape(z,[newShape 1]);
        elseif numel(newShape) > 1
            z = reshape(z,newShape);
        end
        
        TFLabels(axis + 1) = [];
        zrank = xrank-numel(axis);
        if zrank > 1
           z = permute(z, fliplr(1:zrank));
        else
           z = z(:);
        end
        z = dlarray(z, TFLabels);
        
    elseif ~keep_dims && isempty(TFLabels) 
        dimsToDrop = MLAxis;
        dimsToDrop(dimsToDrop > ndims(z)) = [];
        
        newSize = size(z);
        newSize(dimsToDrop)= [];
        if numel(newSize) == 1
            z = reshape(z,newSize, []);
        elseif numel(newSize) > 1
            z = reshape(z,newSize);
        end

        zrank = xrank-numel(axis);
        % Rank 0 and Rank 1 dlarrays need to be relabeled differently
        % if z.size = 1xN, then there is a difference between
        % dlarray(z, 'U') and dlarray(z, 'UU')
        if zrank > 1
            z = dlarray(z, repmat('U', [1 zrank]));
        else
            z = dlarray(z, 'UU');
        end
    else
        % keepdims and isempty(TFLabels)
        zrank = xrank;
        % Rank 0 and Rank 1 dlarrays need to be relabeled differently
        if zrank > 1
            z = dlarray(z, repmat('U', [1 zrank]));
        else
            z = dlarray(z, 'UU');
        end
    end
        z = struct('value', z, 'rank', zrank);
end 
