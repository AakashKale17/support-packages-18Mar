function isKerasImporterInstalled()
% This is an empty bread-crumb function used to determine the location of
% the Deep Learning Toolbox Converter for TensorFlow Models support package.
