function result = translateKerasModelOrLayer(this, node_def, MATLABOutputName, MATLABArgIdentifierNames)
    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult; 
    
    %assert(numel(node_def.attr.DerivedOutputNodes) == 1, 'objects in the subclassed model must have one output.'); 
    
    numOutputs = numel(node_def.attr.DerivedOutputRanks); 
    result.NumOutputs = numOutputs; 
    if numOutputs > 1
        outputNames = makeMultipleOutputArgs(this, MATLABOutputName, numOutputs); 
        outputNamesValue = outputNames + ".value"; 
    else
        outputNames = {MATLABOutputName}; 
        outputNamesValue = outputNames + ".value"; 
    end
    %outputNames = cellstr(outputNames); 
    for i = 1:numel(MATLABArgIdentifierNames)
        MATLABArgIdentifierNames{i} = ['iAddDataFormatLabels(' MATLABArgIdentifierNames{i} ')']; 
    end 
    
    if strcmp(node_def.ParentFcnName,'Functional')
         MATLABArgIdentifierNames{end+1} = "'Outputs'";
         outputLayerNodes = node_def.attr.DerivedOutputNodes;
         outputLayerNames = '{';
         erasePattern = '|StatefulPartitionedCall' + textBoundary("end");
         for i = 1: numel(outputLayerNodes)
            outputLayerNodeParts = strsplit(outputLayerNodes{i},'/');
            if numel(outputLayerNodeParts) > 1
                if (isKey(node_def.attr.LayerToOutName, outputLayerNodeParts{1}))
                    % append the output name for the output layer
                    outputLayerName = outputLayerNodeParts{1};
                    allOutputs = node_def.attr.LayerToOutName(outputLayerName);
                    outputNumberParts = strsplit(outputLayerNodeParts{end},':');
                    [outputNumber, success] = str2num(outputNumberParts{end});
                    if success    
                        outputNumber = outputNumber + 1;  
                    else
                        outputNumber = 1;
                    end
                    outputLayerName = [outputLayerName '/' allOutputs{outputNumber}]; %#ok<AGROW> 
                elseif isKey(node_def.attr.LayerToOutName, nnet.internal.cnn.keras.makeNNTName(strjoin(outputLayerNodeParts(1:end-1),'/')))
                    outputLayerName = nnet.internal.cnn.keras.makeNNTName(strjoin(outputLayerNodeParts(1:end-1),'/'));
                    allOutputs = node_def.attr.LayerToOutName(outputLayerName);
                    outputNumberParts = strsplit(outputLayerNodeParts{end},':');
                    [outputNumber, success] = str2num(outputNumberParts{end});
                    if success    
                        outputNumber = outputNumber + 1;  
                    else
                        outputNumber = 1;
                    end
                    outputLayerName = [outputLayerName '/' allOutputs{outputNumber}]; %#ok<AGROW>
                elseif isKey(node_def.attr.LayerToOutName, erase(nnet.internal.cnn.keras.makeNNTName(outputLayerNodes{i}),erasePattern))
                    outputLayerName = erase(nnet.internal.cnn.keras.makeNNTName(outputLayerNodes{i}),erasePattern);
                    allOutputs = node_def.attr.LayerToOutName(outputLayerName);
                    outputNumberParts = strsplit(outputLayerNodeParts{end},':');
                    [outputNumber, success] = str2num(outputNumberParts{end});
                    if success    
                        outputNumber = outputNumber + 1;  
                    else
                        outputNumber = 1;
                    end
                    outputLayerName = [outputLayerName '/' allOutputs{outputNumber}]; %#ok<AGROW>      
                end
            else
                outputLayerName = outputLayerNodeParts{end};
                if (isKey(node_def.attr.LayerToOutName, outputLayerName))
                    % append the output name for the output layer
                    allOutputs = node_def.attr.LayerToOutName(outputLayerName);
                    outputNumberParts = strsplit(outputLayerNodeParts{end},':');
                    [outputNumber, success] = str2num(outputNumberParts{end});
                    if success    
                        outputNumber = outputNumber + 1;  
                    else
                        outputNumber = 1;
                    end
                    outputLayerName = [outputLayerName '/' allOutputs{outputNumber}]; %#ok<AGROW> 
                end
            end
            outputLayerNames = [outputLayerNames '''' outputLayerName ''', ' ]; %#ok<AGROW> 
         end
         outputLayerNames(end-1) = '}';
         MATLABArgIdentifierNames{end+1} = outputLayerNames;
    end
    predictCode = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall(...
       this.LAYERREF + "." + MATLABOutputName + ".predict", outputNamesValue, MATLABArgIdentifierNames) + newline;
    
    forwardCode = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall(...
       this.LAYERREF + "." + MATLABOutputName + ".forward", outputNamesValue, MATLABArgIdentifierNames) + newline;

    
    result.Code = "if ~" + this.LAYERREF + ".IsTraining" + newline + predictCode + "else" + newline + forwardCode + "end" + newline; 

    % Need to manually set the output ranks. 
    result.ForwardRank = false;
    for i = 1:numOutputs
        outrank = num2str(node_def.attr.DerivedOutputRanks(i)); 
        result.Code = result.Code + outputNames{i} + "." +this.RANKFIELDNAME + " = " + outrank + ";" + newline; 
    end
    
    result.IsCommenting = true; 
    result.Comment = "Calling dlnetwork"; 
    result.Success = true; 
end