function shape = tfShape(in)
    %{{import_statement}}

%   Copyright 2020-2022 The MathWorks, Inc.

    if in.rank == 0
        shape.value = dlarray([]);
        shape.rank = 1;
        return; 
    end 
    
    shape = size(in.value)'; 

    if in.rank < 2
        % handle zero -> 1-D tensors. 
        shape = shape(1:in.rank);
    elseif in.rank > numel(shape)
        % handle dropped trailing singleton dimensions. 
        rankdiff = in.rank - numel(shape); 
        shape(end+1:end+(rankdiff)) = 1; 
    end 

    if isa(in.value, 'dlarray') && ~isempty(in.value.dims) && ~all(in.value.dims == 'U') && in.rank > 1
        % Input is labelled DLT tensor of rank > 1
        shapePermutation = sortToTFLabel(1:in.rank, in.value.dims); 
        shape = shape(shapePermutation); 
    else 
        % Input is in reverse-TF format  
        if in.rank > 1
            shape = flip(shape);
        end        
    end    
    shape = dlarray(shape, "UU"); 
        
    % zero gradient skip connection. 
    shape = shape + (sum(in.value.stripdims, 'all') * 0);         
    
    % assign output rank: 
    shape = struct('value', shape, 'rank', 1);
end
