function tf = isAuto(val)
    % Copyright 2021 The MathWorks, Inc.
    tf = isequal(string(val), "auto");
end