function Network = importNetworkFromTensorFlow(modelFolder, options)
% Copyright 2022 The MathWorks, Inc.

arguments
    modelFolder {mustBeFolder}
    options.PackageName {mustBeTextScalar} = ''
end

%% Call to importTensorFlowNetwork
Network = nnet.internal.cnn.tensorflow.importTensorFlowNetwork(modelFolder, 'TargetNetwork', 'dlnetwork', 'PackageName', options.PackageName, 'OnlySupportDlnetwork', true);
