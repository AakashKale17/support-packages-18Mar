function y = tfBroadCastTo(input, shape)
%{{import_statement}}

%   Copyright 2020-2021 The MathWorks, Inc.

returnDLTOrder = false; 

x = input.value; 
xrank = input.rank;

if isstruct(shape)
    shape = shape.value;
end

if isa(shape, 'dlarray')
    shape = shape.extractdata;
end

shape = flip(shape); 
outputrank = numel(shape); 

if isa(x, 'dlarray') && ~isempty(x.dims) && ~all(x.dims == 'U') && xrank > 1
    [permutationVec,tflabels] = sortToTFLabel(1:xrank, x.dims); 
    x = permute(x.stripdims, flip(permutationVec)); 
    returnDLTOrder = true; 
elseif isa(x, 'dlarray') % with all U dimensions, already in reverse TF format
    x = stripdims(x); 
end 

inShape = size(x); 
expandedShape = ones(1, numel(shape)); 
expandedShape(1:numel(inShape)) = inShape; 
y = x; 
for i = 1:numel(shape) 
    if expandedShape(i) == 1 && shape(i) ~= 1
        rmsize = num2cell(ones(1, numel(shape))); 
        rmsize{i} = shape(i); 
        y = repmat(y, rmsize{:}); 
    end
end

if returnDLTOrder
    y = permute(y, outputrank:-1:1); 
    y = dlarray(y, tflabels); 
else 
    if outputrank > 1
        y = dlarray(y, repmat('U', [1 outputrank]));
    else
        y = dlarray(y, 'UU');
    end 
end

y = struct('value', y, 'rank', outputrank); 
end 
