function Y = tfMirrorPad(X, paddings, mode)
%{{import_statement}}

%   Copyright 2020-2022 The MathWorks, Inc.

    Xrank = X.rank;
    Xval = X.value;

    if ~isa(Xval, 'dlarray')
        % If a numeric array permute the input tensor to match Forward TF Format.   
        Xval = permute(Xval, Xrank:-1:1);
        TFLabels = repmat('U', [1 Xrank]);    
    elseif ~isempty(Xval.dims) && ~all(Xval.dims == 'U') && Xrank > 1 
        % If labeled dlarray, permute the input tensor to match Forward TF Format.         
        DLTLabels = Xval.dims;
        [permutationVec, TFLabels] = sortToTFLabel(1:Xrank, DLTLabels);  
        Xval = permute(Xval.stripdims, permutationVec);   
    elseif Xrank > 1
        % Assume the input dlarray to be in reverse TF order and permute to
        % forward TF
        Xval = permute(Xval.stripdims, Xrank:-1:1);
        TFLabels = repmat('U', [1 Xrank]);
    else
        % dlarray with rank <= 1, is already in forward Tf format
        Xval = Xval.stripdims;
        TFLabels = 'UU';
    end
        
    % paddings is a Nx2 matrix. Where N is the number of dimensions of x. 
    % For a dimension D paddings(D, 1) is the number of values to pad
    % before the contents of x in that dimension. and paddings(D, 2) is the
    % number of values to add after the contents of x in that dimension. 
    paddings = paddings.value'; 
    sizeX = size(Xval); 
    if Xrank > numel(sizeX)
        % add back potentially dropped dims 
        diff = Xrank - numel(sizeX); 
        sizeX(end+1:end+diff) = 1; 
    end 
    sizeY = zeros(1, Xrank); 
    for i = 1:size(paddings, 1)
        sizeY(i) = sizeX(i) + paddings(i, 1) + paddings(i, 2); 
    end 
    
    % Construct output array with padded size. 
    Y = dlarray(zeros(sizeY, 'like', Xval));
    
    % Construct subsref indices for inserting (and cropping) the original
    Ysubs = cell(1, size(paddings, 1)); 
    Xsubs = cell(1, size(paddings, 1)); 
    
    for i=1:numel(sizeX)
        Ysubs{i} = max(1,1+paddings(i,1)) : min(sizeY(i), sizeY(i)-paddings(i, 2));
        Xsubs{i} = max(1,1-paddings(i,1)) : min(sizeX(i), sizeX(i)+paddings(i, 2));
    end
    Sy      = struct('type', '()');
    Sy.subs = Ysubs;
    Sx      = struct('type', '()');
    Sx.subs = Xsubs;
    
    % Insert/crop the original into the result
    Y = subsasgn(Y, Sy, subsref(Xval, Sx));
    
    % Handle 'reflect' and 'symmetric' modes
    mode = upper(mode); 
    if ismember(mode, ["REFLECT" "SYMMETRIC"])
        for dim = 1:Xrank
            if any(paddings(dim, :) > 0)
                % Setup a call to subsasgn
                prepad  = paddings(dim, 1);
                postpad = paddings(dim, 2);
                if prepad > 0
                    [Sy, Sx] = prepadIndices(sizeX, prepad, dim, mode);
                    Y = subsasgn(Y, Sy, subsref(Y, Sx));
                end
                if postpad > 0
                    [Sy, Sx] = postpadIndices(sizeX, sizeY, prepad, postpad, dim, mode);
                    Y = subsasgn(Y, Sy, subsref(Y, Sx));
                end
            end
        end
    else
        % Unrecognized padding mode. 
        error('Unsupported padding mode. Only REFLECT and SYMETRIC modes are supported for MirrorPad.'); 
    end
    
    % re-label and convert back to DLT / Reverse TF ordering. 
    if Xrank > 1 && all(TFLabels == 'U')
        % Convert to reverse-TF format, before applying U labels
        Y = permute(Y, Xrank:-1:1);
    end
    
    Y = dlarray(Y, TFLabels);
    Y = struct('value', Y, 'rank', Xrank);
    
    % Subfunctions in tfMirrorPad:
    function [Sy, Sx] = prepadIndices(sizeX, prepad, dim, mode)
        Sy   	= struct('type', '()');
        Sy.subs	= repmat({':'}, [1 numel(sizeX)]);
        Sx   	= Sy;
        % Write into the first 'prepad' elements of Y.dim.
        Sy.subs{dim} = 1:prepad;
        switch mode
            case 'REFLECT'
                % Create indices 2:prepad+1 of X.dim, in the reverse order, with
                % wraparound. Then add prepad to convert them to Y indices.
                Sx.subs{dim} = wrapIndices(prepad+1 : -1 : 2, sizeX(dim)) + prepad;
            case 'SYMMETRIC'
                % Create indices 1:prepad of X.dim, in the reverse order, with
                % wraparound. Then add prepad to convert them to Y indices.
                Sx.subs{dim} = wrapIndices(prepad : -1 : 1, sizeX(dim)) + prepad;
        end
    end

    function [Sy, Sx] = postpadIndices(sizeX, sizeY, prepad, postpad, dim, mode)
        Sy   	= struct('type', '()');
        Sy.subs	= repmat({':'}, [1 numel(sizeX)]);
        Sx   	= Sy;
        % Write into the last 'postpad' elements of Y.dim.
        Sy.subs{dim} = sizeY(dim)-postpad+1 : sizeY(dim);
        switch mode
            case 'REFLECT'
                % Create indices in the reverse order, with wraparound. Then add
                % prepad to convert them to Y indices.
                Sx.subs{dim} = wrapIndices(sizeX(dim)-1 : -1 : sizeX(dim)-postpad, sizeX(dim)) + prepad;
            case 'SYMMETRIC'
                % Create indices in the reverse order, with wraparound. Then add
                % prepad to convert them to Y indices. Include the end index. 
                Sx.subs{dim} = wrapIndices(sizeX(dim) : -1 : sizeX(dim)-postpad + 1, sizeX(dim)) + prepad;
        end
    end

    function j = wrapIndices(i, maxIdx)
        % i can be positive, negative or zero. Legal output indices are in the
        % range 1:maxIdx.
        j = mod(i-1, maxIdx) + 1;
    end
end 

