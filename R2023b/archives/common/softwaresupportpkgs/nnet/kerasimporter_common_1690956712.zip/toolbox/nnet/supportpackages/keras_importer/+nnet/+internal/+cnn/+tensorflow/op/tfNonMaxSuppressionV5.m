function [selected_indices, selected_scores, valid_outputs] = tfNonMaxSuppressionV5(boxes, scores, max_output_boxes_per_class, ...
    iou_threshold, score_threshold, soft_nms_sigma)
% Implements the TF NonMaxSuppression operator: https://www.tensorflow.org/api_docs/python/tf/raw_ops/NonMaxSuppressionV5

if(soft_nms_sigma.value > 0)
    error('NonMaxSuppression does not support soft_nms_sigma greater than 0.'); 
end

if isempty(boxes.value)
    selected_indices.value = dlarray([]);
    selected_indices.rank = 1;
    selected_scores.value = dlarray([]);
    selected_scores.rank = 1;
    valid_outputs.value = 0;
    valid_outputs.rank = 0;
    return
end

boxes = boxes.value; % TF:a 2-D tensor of shape [num_boxes, 4].
scores = scores.value; % TF:a 1-D tensor/vector of shape [num_boxes].
max_output_boxes_per_class = max_output_boxes_per_class.value;
iou_threshold = iou_threshold.value;
score_threshold = score_threshold.value;

isBoxesDLTFormat = isa(boxes, 'dlarray') && ~isempty(boxes.dims) && ~all(boxes.dims == 'U');
isScoresDLTFormat = isa(scores, 'dlarray') && ~isempty(scores.dims) && ~all(scores.dims == 'U');

if isBoxesDLTFormat
    % convert to reverse TF format
    [bPermutationVec, btflabel] = sortToTFLabel(1:ndims(boxes), boxes.dims); 
    boxes = stripdims(boxes);
    boxes = permute(boxes, flip(bPermutationVec));
end

if isScoresDLTFormat
    % convert to reverse TF format
    [sPermutationVec, stflabel] = sortToTFLabel(1:ndims(scores), scores.dims); 
    scores = stripdims(scores);
    scores = permute(scores, flip(sPermutationVec));
end 


% Extract data from input dlarray objects.
boxes = iExtractData(boxes);  % MATLAB:a 2-D dlarray of shape [4 num_boxes].
boxes = boxes'; % [num_boxes 4]
scores = iExtractData(scores); % MATLAB:a 2-D dlarray of shape [1 num_boxes].

max_output_boxes_per_class = iExtractData(max_output_boxes_per_class);
iou_threshold = iExtractData(iou_threshold);
score_threshold = iExtractData(score_threshold);

[numBoxes, ~] = size(boxes);

% Perform NMS across batches.
% TF box format is [y1 x1 y2 x2] in spatial coordinate and defines
% diagonal pairs. The order of the pairs is not defined. Compute the
% min and max coordinates.
xmin = min(boxes(:,[2 4]),[],2);
xmax = max(boxes(:,[2 4]),[],2);
ymin = min(boxes(:,[1 3]),[],2);
ymax = max(boxes(:,[1 3]),[],2);

% Convert min and max coordinates to [x y w h].
bboxes = [xmin ymin xmax-xmin ymax-ymin];

 % Keep boxes above score threshold.
keep = scores > score_threshold;
boxesAfterScoreThreshold = bboxes(keep,:);
scoresAfterScoreThreshold = scores(keep,:);

% Create the index list of boxes 
idx = (1:numBoxes)';

% Track original indices of boxes that were kept.
idx1 = idx(keep);

% selectStrongestBbox only supports valid box inputs with width and
% height > 0. However, TF NMS allows these types of boxes and it
% does not suppress them in its output. Here, we remove invalid
% boxes, apply selectStrongestBbox, and then add the invalid boxes
% back to mimic TF NMS output.
%
% Select valid boxes and keep track of valid box indices.
valid = all(boxesAfterScoreThreshold(:,[3 4]) > 0, 2);
validInd = find(valid);
validBoxes = boxesAfterScoreThreshold(valid,:);
validScores = scoresAfterScoreThreshold(valid,:);

if ~isempty(validBoxes)
    [~,~,index] = selectStrongestBbox(validBoxes,validScores,...
            'RatioType','Union',...
            'OverlapThreshold',iou_threshold,...
            'NumStrongest',max_output_boxes_per_class);
end

index = validInd(index);

% Reorder indices by score.
[~, ord] = sort(scoresAfterScoreThreshold(index),'descend');
index = index(ord);

% Get index into original input boxes before score threshold.
index = idx1(index);

selected_indices.value = dlarray(index - 1);
selected_indices.rank = 1;
selected_scores.value = dlarray(scores(index));
selected_scores.rank = 1;
valid_outputs.value = dlarray(numel(index));
valid_outputs.rank = 0;

function x = iExtractData(x)
    if isa(x,'dlarray')
        x = extractdata(x);
    end
end

end
