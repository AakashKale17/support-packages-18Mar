function result = translateCast(~, node_def, MATLABOutputName, MATLABArgIdentifierNames)
%

%   Copyright 2020-2021 The MathWorks, Inc.

    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult; 
    
    result.Code = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall("tfCast", {MATLABOutputName + ".value"}, [MATLABArgIdentifierNames {"'" + node_def.attr.DstT.type + "'"}]);
    result.ForwardRank = true;
    result.Success = true;
    result.OpFunctions = "tfCast";
end 
