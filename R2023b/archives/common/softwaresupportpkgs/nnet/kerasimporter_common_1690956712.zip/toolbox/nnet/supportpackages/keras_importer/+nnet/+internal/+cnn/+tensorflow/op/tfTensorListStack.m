function z = tfTensorListStack(tensor_list, element_shape)
    %{{import_statement}}

%   Copyright 2023 The MathWorks, Inc.

    % The TensorListStack operator takes a tensor_list as its first input:
    %   tf.Tensor(<TensorList>, shape=(), dtype=variant)
    % 
    % element_shape: The only valid scalar shape tensor is the fully unknown 
    % shape specified as -1 can only be -1 if it is a scalar else it has to
    % be a rank 1 tensor containing the shape of the tensor elements to be 
    % reserved, hence this will always be in forward TF format
    if isempty(tensor_list)
        z = struct('value', [], 'rank', 0);
        return;
    end
    
    % tensor_list should have atleast one element
    num_elements = numel(tensor_list);
    trank = tensor_list(1).rank;
    element_shape = element_shape.value; 
    
    if trank ~= -1    
        z = tfPack(0, tensor_list(:)); 
    else
        tensor_rank = numel(element_shape) + 1;
        if tensor_rank <= 1
            % Forward TF format
            tensor = dlarray(zeros([num_elements, element_shape]),'UU');            
        else
            % Reverse TF format as rank > 1
            tensor = dlarray(zeros([flip(element_shape), num_elements]), repmat('U', [1 tensor_rank]));            
        end      
        z = struct('value', tensor, 'rank', tensor_rank);
    end   
end






