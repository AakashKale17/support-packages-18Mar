function z = tfRandomStandardNormal(shape, dtype)
    %{{import_statement}}

%   Copyright 2020-2022 The MathWorks, Inc.

    shape = shape.value;
    zrank = numel(shape); 
    
    if isa(shape, 'dlarray')
        shape = shape.extractdata; 
    end 
    % Force it to be row vec. 
    shape = fliplr(shape(:)'); 
    if numel(shape) == 1
        shape = [shape 1]; 
    end 
    switch dtype
        case 'DT_FLOAT'
            z.value = randn(shape, 'single'); 
        case 'DT_DOUBLE'
            z.value = randn(shape, 'double'); 
        otherwise 
            z.value = randn(shape, 'single'); 
    end
    
    if zrank > 1
        z.value = dlarray(z.value, repmat('U', [1 zrank]));
    else
        z.value = dlarray(z.value, 'UU');
    end 
    
    z.rank = zrank;
end
