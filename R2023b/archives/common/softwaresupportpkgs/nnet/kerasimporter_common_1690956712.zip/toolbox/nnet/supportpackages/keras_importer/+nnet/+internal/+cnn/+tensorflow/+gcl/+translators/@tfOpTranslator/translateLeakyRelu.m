function result = translateLeakyRelu(~, node_def, MATLABOutputName, MATLABArgIdentifierNames)
%

%   Copyright 2020-2021 The MathWorks, Inc.

    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult; 

    if isfield(node_def.attr, 'alpha')
        alpha = node_def.attr.alpha.f;
    else 
        alpha = 0.2; 
    end 
    
    % we expect alpha to always be scalar, throw an assertion failure if that
    % is not the case
    assert(isscalar(alpha)); 
    alpha = num2str(alpha); 
    result.Code = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall("leakyrelu", {MATLABOutputName + ".value"}, {MATLABArgIdentifierNames{1} + ".value", alpha}); 
    result.ForwardRank = true;
    result.Success = true;
end 
