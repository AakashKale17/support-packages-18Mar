function z = tfTensorListSetItem(input_handle, index, item)
    %{{import_statement}}

%   Copyright 2023 The MathWorks, Inc.

    % The TensorListSetItem operator sets the index-th position of the input list (input_handle) to contain the given tensor:
    %   tf.Tensor(<TensorList>, shape=(), dtype=variant)
    % 
    % Hence, tfTensorListSetItem returns returns an array of structs, each holding a 
    % dlarray and its rank.    

    idxval = index.value + 1;
    z = input_handle;
    z(idxval).value = item.value;
    z(idxval).rank = item.rank;
end






