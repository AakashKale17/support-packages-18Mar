function result = translateExpandDims(~, node_def, MATLABOutputName, MATLABArgIdentifierNames)
%

%   Copyright 2021 The MathWorks, Inc.

    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult;
    
    result.Code = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall("tfExpandDims", {MATLABOutputName}, MATLABArgIdentifierNames); 
    result.OpFunctions = "tfExpandDims"; 
    result.ForwardRank = false; 
    result.Success = true; 
end 
