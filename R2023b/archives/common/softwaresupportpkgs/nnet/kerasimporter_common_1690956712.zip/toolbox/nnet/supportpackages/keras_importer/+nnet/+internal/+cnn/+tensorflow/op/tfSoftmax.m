function softMax = tfSoftmax(logits)
%{{import_statement}}

%   Copyright 2022 The MathWorks, Inc.
%   Computes softmax activations.
%
%   logits: A Tensor. 
%          Must be one of the following types: half, bfloat16, float32, float64. 
%          2-D with shape [batch_size, num_classes].    
%

% Input verification
if logits.rank <= 1
    error('Softmax is only supported for input tensors having a rank of 2 or more.');
end

if isa(logits.value, 'dlarray')
    xLabels = logits.value.dims;
else
    xLabels = [];
end

midULabels = char('U' + zeros(1, logits.rank - 2));
TFXLabels = ['B' midULabels 'C']; 

% If the logits tensor is unlabeled. We assume it is in reverse TensorFlow order
if isempty(xLabels) || all(xLabels == 'U')
    % Permute to forward tensorflow format and apply labels
    logits.value = permute(stripdims(logits.value), logits.rank:-1:1);
    logits.value = dlarray(logits.value, TFXLabels); 
elseif strcmp(xLabels(1),'B') && all(xLabels(2:end) == 'U')
    % Input tensor is already in Forward TF format
    % apply BU labels
    logits.value = dlarray(logits.value, TFXLabels); 
end
    
y = softmax(logits.value);
% assign output rank:
softMax = struct('value', y, 'rank', logits.rank);
end

