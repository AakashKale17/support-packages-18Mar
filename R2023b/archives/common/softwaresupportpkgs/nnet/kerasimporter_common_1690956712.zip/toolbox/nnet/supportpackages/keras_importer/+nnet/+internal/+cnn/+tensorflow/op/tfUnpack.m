function varargout = tfUnpack(value, num, TFAxis)
%{{import_statement}}
% Copyright 2022 The MathWorks, Inc.

% num and TFAxis are scalar node attributes, they should never be structs
    
    xval = value.value;
    xrank = value.rank;

    assert(xrank >= 1, "tfUnpack: value rank is less than 1.");
    
    isXDLTFormat = isa(xval, 'dlarray') && ~isempty(xval.dims) && ~all(xval.dims == 'U') && xrank > 1; 
    if isXDLTFormat 
        [xPermutationVec, ~] = sortToTFLabel(1:xrank, xval.dims); 
        xval = stripdims(xval);
        xval = permute(xval, flip(xPermutationVec)); 
    elseif isa(xval, 'dlarray')
        xval = stripdims(xval); 
    end 

    % xval should be in reverse TF format now.    
    if TFAxis < 0
        % handle negative axis values
        MLAxis = mod(TFAxis, xrank);
    else 
        MLAxis = TFAxis; 
    end
    MLAxis = xrank - MLAxis;
    
    numOuts = floor(size(xval, MLAxis)  / num); 
    start = 1; 
    varargout = cell(1, numOuts); 
    outshape = ones(1, xrank); 
    outshape(1:ndims(xval)) = size(xval);
    outshape(MLAxis) = []; 

    for i = 1:num
        indices = repmat({':'}, [1 xrank]); 
        indices{MLAxis} = i;
        start = start + num; 
        varargout{i}.value = xval(indices{:}); 
        if numel(outshape) > 1
            varargout{i}.value = reshape(varargout{i}.value, outshape);  
        end
        varargout{i}.rank = xrank - 1; 
        if varargout{i}.rank > 1
            label = repmat('U', [1 varargout{i}.rank]); 
        else
            label = 'UU';
        end
        varargout{i}.value = dlarray(varargout{i}.value, label);
    end
end