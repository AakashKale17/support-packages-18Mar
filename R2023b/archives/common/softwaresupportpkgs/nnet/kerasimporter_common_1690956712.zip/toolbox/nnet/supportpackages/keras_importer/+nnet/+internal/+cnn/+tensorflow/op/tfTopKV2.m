function [topK, indices] = tfTopKV2(x, k)
%{{import_statement}}

%   Copyright 2022 The MathWorks, Inc.

%%%%%
    if isa(x.value, 'dlarray')
        xLabels = x.value.dims;
        nDimsX = x.rank;
        x.value = extractdata(x.value);
    else
        xLabels = [];
        nDimsX = x.rank;
    end

    if isstruct(k)
        k = k.value;
    end

    if isa(k, 'dlarray')
        k = k.extractdata;
    end

    if ~isempty(xLabels) && ~all(xLabels == 'U')
        % Convert formatted dlarray to reverse TF format.
        [permuteX, TFXLabels] = sortToTFLabel(1:nDimsX, xLabels(1:nDimsX));
        if nDimsX > 1
            x.value = permute(x.value, flip(permuteX)); 
        end
    else
        % Unformatted dlarray data will be assumed to have reverse TF format. 
        % So no permutation will occur.
        TFXLabels = [];
    end
    %%%%%

    [topK, indices] = maxk(x.value, k, 1);
    
    % convert indices to 0-based-indexing
    indices = indices - 1;

    if ~isempty(xLabels) && ~all(xLabels == 'U') && nDimsX > 1
        % Re-permute to forward TF format
        % and apply DLT labels
        topK = permute(topK, nDimsX:-1:1);
        indices = permute(indices, nDimsX:-1:1);

        %Assign DLT Labels
        topK = dlarray(topK, TFXLabels);
        indices = dlarray(indices, TFXLabels);
    else
        % Leave in reverse TF format 
        % apply all U labels
        if nDimsX > 1
            topK = dlarray(topK, repmat('U', [1 nDimsX]));
            indices = dlarray(indices, repmat('U', [1 nDimsX]));
        else
            topK = dlarray(topK, 'UU');
            indices = dlarray(indices, 'UU');
        end        
    end

    % assign output rank:
    topK = struct('value', topK, 'rank', nDimsX);
    indices = struct('value', indices, 'rank', nDimsX);
end