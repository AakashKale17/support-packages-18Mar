function z = tfMean(x, axis, keep_dims)
    %{{import_statement}}

%   Copyright 2020-2021 The MathWorks, Inc.

    xval = x.value; 
    xrank = x.rank; 
    zrank = xrank;
    
    if any(axis.value < 0)
    % Handle negative axis values
        negIdx = axis.value < 0;
        axis.value(negIdx) = xrank + axis.value(negIdx);
    end

    isXDLTFormat = isa(xval, 'dlarray') && ~isempty(xval.dims) && ~all(xval.dims == 'U') && xrank > 1; 

    if isXDLTFormat 
        DLTLabel = xval.dims;
        [permutationVec, TFLabels] = sortToTFLabel(1:xrank, DLTLabel);
        xval = permute(xval.stripdims, permutationVec);
        % xval is in forward TF format
        MLAxis = axis.value + 1;        
    else
        if isa(xval, 'dlarray') % with all U dimensions, already in reverse TF format
            xval = stripdims(xval); 
        end
        TFLabels = repmat('U', [1 xrank]);
        % xval is in reverse TF format
        MLAxis = xrank - axis.value; 
    end
    
    % Apply mean, this preserves all dimesions
    z = mean(xval, MLAxis); 
    
    if ~keep_dims
        outsize = ones(1, xrank); 
        outsize(1:ndims(z)) = size(z); 
        outsize(MLAxis) = [];    
        zrank = xrank - numel(MLAxis); 
        
        % Reshape to the reduced dims and set all labels to U
        if zrank > 1   
            z = reshape(z, outsize);
            TFLabels = repmat('U', [1 zrank]);
        else
            z = reshape(z, [outsize 1]); 
            TFLabels = 'UU';
        end       
        
        % Now z should be in reverse-TF format for ranks > 1
        if isXDLTFormat && zrank > 1
        % convert to reverse-TF
            z = permute(z, zrank:-1:1);
        end      
    end
    
    z = dlarray(z, TFLabels);
    z = struct('value', z, 'rank', zrank);
end
