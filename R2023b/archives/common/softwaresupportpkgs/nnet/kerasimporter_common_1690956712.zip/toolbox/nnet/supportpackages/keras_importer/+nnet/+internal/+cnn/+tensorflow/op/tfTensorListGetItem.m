function z = tfTensorListGetItem(input_handle, index, element_shape)
    %{{import_statement}}

%   Copyright 2023 The MathWorks, Inc.

    % The TensorListGetItem operator returns a Tensor at an index in a TensorList tensor:
    %   tf.Tensor(<TensorList>, shape=(), dtype=variant)
    % 
    % Hence, tfTensorListGetItem returns a Tensor
    % 
    % element_shape: The only valid scalar shape tensor is the fully unknown 
    % shape specified as -1 

    idxval = index.value + 1;
    zval = input_handle(idxval).value;
    zrank = input_handle(idxval).rank;
    
    if zrank == -1
        % input_handle is an unitialized TensorList
        element_shape = element_shape.value; 
        zrank = numel(element_shape);
        if zrank <= 1
            % Forward TF format
            zval = dlarray(zeros(element_shape),'UU');            
        else
            % Reverse TF format as rank > 1
            zval = dlarray(zeros([flip(element_shape)]), repmat('U', [1 zrank]));            
        end      
    end
    z = struct('value', zval, 'rank', zrank);    
end

