classdef ConverterForPixelClassificationLayer < nnet.internal.cnn.tf_exporter.ConverterForIdentityOutputLayers

    %   Copyright 2022 The MathWorks, Inc.

end
