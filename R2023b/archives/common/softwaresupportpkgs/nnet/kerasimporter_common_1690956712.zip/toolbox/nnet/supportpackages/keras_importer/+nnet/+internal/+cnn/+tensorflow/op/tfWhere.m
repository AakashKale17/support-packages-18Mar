function z = tfWhere(condition)
%{{import_statement}}

%   Copyright 2020-2023 The MathWorks, Inc.

    xrank = condition.rank; 
    x = condition.value; 
    
        
    isXDLTFormat = isa(x, 'dlarray') && ~isempty(x.dims) && ~all(x.dims == 'U') && xrank > 1;     
    if isXDLTFormat 
        [xPermutationVec, xtflabel] = sortToTFLabel(1:ndims(x), x.dims); 
        x = stripdims(x);
        x = permute(x, flip(xPermutationVec)); 
    elseif isa(x, 'dlarray')
        x = stripdims(x); 
    end 
    
    I = {};
    for i = 1:xrank
        I{i} = 0;
    end
    
    [I{:}] = ind2sub(size(x),find(x.extractdata));
    z = horzcat(I{:});
    
    % Convert indices from 1-based to 0-based TF format.
    z = z - 1;
    zrank = 2;
    z = permute(z, zrank:-1:1);
    z = dlarray(z, 'UU');
    z = struct('value', z, 'rank', zrank);
end 
