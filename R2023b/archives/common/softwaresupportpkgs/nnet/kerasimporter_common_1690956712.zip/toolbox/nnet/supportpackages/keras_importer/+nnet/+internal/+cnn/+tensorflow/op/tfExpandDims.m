function Y = tfExpandDims(X, axis)
    %{{import_statement}}

%   Copyright 2021-2023 The MathWorks, Inc.

    if isa(X.value, 'dlarray')
        xlabels = X.value.dims;
        xrank = X.rank;
        X.value = stripdims(X.value);
    else
        xlabels = [];
        xrank = X.rank;
    end
    
    if isstruct(axis)
        axis = axis.value;
    end

	% Handle negative axis value    
    if axis < 0
		axis = xrank + axis + 1;
    end
        
    % Formatted dlarray data will be converted to reverse-TF format before the operation.
    % Non-formatted dlarray data will be assumed to have reverse-TF format so no format conversion will occur for such inputs. 
    if ~isempty(xlabels) && ~all(xlabels == 'U') && xrank > 1
        [permutex, ~] = sortToTFLabel(1:xrank, xlabels(1:xrank));
        if ~isscalar(X.value) && ~isscalar(permutex)
            X.value = permute(X.value, flip(permutex)); 
        end   
    end 
    
    outputrank = xrank + 1;
    
    % At this point the input should be in reversed TF format
    % The expanded dimension should be added in the forward TF dim order
    % Hence, the reshape vector needs to be in forward TF format first
    % Then we add the expanded singleton dimension to it
    % Then we flip it again to convert to reverse TF format, before using it for reshape
    if xrank > 1
        reshape_vector = ones(1, xrank);    % [1 1 1 1] , size(X.value) : [2 4 3 1] (in reverse tf format)
        reshape_vector(:, 1:ndims(X.value)) = size(X.value); % [2 4 3 1]
        reshape_vector = flip(reshape_vector); % [1 3 4 2] (forward tf format)
        reshape_vector = [reshape_vector(1:axis) 1 reshape_vector(axis+1:end)];  % [1 3 1 4 2]
        reshape_vector = flip(reshape_vector); % [2 4 1 3 1] (reverse tf format)
        
        Y = reshape(X.value,reshape_vector);
    % If rank=1 in TF its already represented as rank=2 in MATLAB
    else
        Y = X.value;
        if axis ~= 0
            Y = permute(Y, outputrank:-1:1);
        end
    end    
    
    % compute data format labels
    if outputrank <= 1 
        Y = dlarray(Y, 'UU');
    elseif outputrank == 2
        Y = dlarray(Y, 'UU');
    else
        Y = dlarray(Y, repmat('U', [1 outputrank]));
    end         
    
    Y = struct('value', Y, 'rank', outputrank);
end