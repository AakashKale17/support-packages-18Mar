classdef SoftsignLayer < nnet.layer.Layer...
                        & nnet.internal.cnn.layer.Traceable & nnet.layer.Acceleratable
% SoftsignLayer   Softsign layer
%
%   layer = SoftsignLayer(Name) creates a softsign activation layer with
%   name Name. This type of layer calculates Y = X ./ (1 + abs(X)).

%   Copyright 2023 The MathWorks, Inc.
    methods
        function this = SoftsignLayer(Name)
            this.Name = Name;
            this.Description = getString(message('nnet_cnn_kerasimporter:keras_importer:SoftsignDescription'));
            this.Type = getString(message('nnet_cnn_kerasimporter:keras_importer:SoftsignType'));
        end
        
        function Z = predict(~, X)
            Z = X ./ (1 + abs(X));
        end        
    end
end
