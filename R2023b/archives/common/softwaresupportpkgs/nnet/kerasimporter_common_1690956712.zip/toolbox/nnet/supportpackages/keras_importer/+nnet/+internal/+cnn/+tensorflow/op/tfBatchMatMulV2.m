function y = tfBatchMatMulV2(A, B)
%{{import_statement}}

%   Copyright 2021 The MathWorks, Inc.

arank = A.rank;
brank = B.rank;
A = A.value; 
B = B.value; 
if isa(A, 'dlarray')
    alabels = A.dims;
    ndimsa = arank;
    A = stripdims(A);
else
    alabels = [];
    ndimsa = arank;
end

if isa(B, 'dlarray')
    blabels = B.dims;
    ndimsb = brank; 
    B = stripdims(B);
else
    blabels = [];
    ndimsb = brank; 
end

% non-formatted dlarray data will be assumed to have reverse TF format. 
% So and no permutation will occur. 
if ~isempty(alabels) && all(alabels ~= 'U')
    [permutea, tfalabels] = sortToTFLabel(1:ndimsa, alabels); 
    permutea = fliplr(permutea);
    A = permute(A, permutea); 
end 

if ~isempty(blabels) && all(blabels ~= 'U')
    [permuteb, tfblabels] = sortToTFLabel(1:ndimsb, blabels); 
    permuteb = fliplr(permuteb);
    B = permute(B, permuteb);
end

% Thm: y' = (A * B)' == B' * A'. 
% the input matrices are in reverse TF format now. (lets call them A',
% and B'). Forward TF format is called A and B respectively. in TF, the last
% two dimensions are multiplied. pagemtimes will multiply the first two
% dimensions, Everything else is a page dimension. By the Thm above, we
% will call pagemtimes(B', A'). This will return a transposed y. We then 
% apply the reversed TF labels to get the correct MATLAB labels. If 
% labels are unknown, we will output the reverse TF dimension tensor.
y = pagemtimes(B, A);

yrank = ndims(y); 
if arank > brank
    if yrank < arank
        yrank = arank;
    end
else
    if yrank < brank
        yrank = brank;
    end
end

% re-apply labels to the reverse TensorFlow dimension tensor 
if ~isempty(alabels) && ~isempty(blabels) && ~any(blabels == 'U') && ~any(alabels == 'U')
    % Apply back the reverse TF labels. 
    tfalabels = fliplr(tfalabels); 
    tfblabels = fliplr(tfblabels); 
    ylabel = fliplr([tfblabels(1) tfalabels(2:end)]); 
    y = permute(y, yrank:-1:1); 
    y = dlarray(y, ylabel);
elseif ~isempty(alabels) && all(alabels ~= 'U') && ~isempty(tfalabels)
    % Try to apply input A's labels 
    y = permute(y, yrank:-1:1); 
    y = dlarray(y, tfalabels); 
elseif ~isempty(blabels) && all(blabels ~= 'U') && ~isempty(tfblabels) 
    % Try to apply input B's labels 
    y = permute(y, yrank:-1:1); 
    y = dlarray(y, tfblabels); 
else
    % Apply U labels and leave y in reverse TF format
    if yrank > 1
       y = dlarray(y, repmat('U', [1 yrank]));
    else
       y = dlarray(y, 'UU');
    end 
end

y = struct('value', y, 'rank', yrank); 
end 
