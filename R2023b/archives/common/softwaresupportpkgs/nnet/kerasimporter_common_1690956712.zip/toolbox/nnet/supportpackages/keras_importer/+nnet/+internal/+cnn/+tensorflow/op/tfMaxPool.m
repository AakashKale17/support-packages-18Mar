function [y] = tfMaxPool(input, ksize, strides, padding, explicit_paddings)
%{{import_statement}}

%   Copyright 2020-2022 The MathWorks, Inc.

    % Input verification
    if input.rank ~= 4
        error('Max pooling is only supported for input tensors having a rank of 4.');
    end

    if isa(input.value, 'dlarray')
        xLabels = input.value.dims;
    else
        xLabels = [];
    end
    
    TFXLabels = "BSSC"; 
    % If the input tensor is unlabeled. We assume it is in reverse TensorFlow order
    if isempty(xLabels) || all(xLabels == 'U')
        % Permute to forward tensorflow format and apply labels
        input.value = permute(stripdims(input.value), input.rank:-1:1); 
        input.value = dlarray(input.value, TFXLabels); 
    elseif strcmp(xLabels(1),'B') && all(xLabels(2:end) == 'U')
        % Input tensor is already in Forward TF format
        % apply BSSC labels
        input.value = dlarray(input.value, TFXLabels); 
    end

    % Logic for the default "NHWC" data format
    
    % In TF ksize and strides are 1-D Tensors of size 4 (NHWC).
    % Extract the dimensions corresponding to H and W (index 2 and 3)
    ksize = ksize([2 3]);
    strides = strides([2 3]);

    % In TF explicit padding is a list of size 8 (2 values per dimension)
    % Extract the padding values corresponding to the spatial dimensions (index 2 and 3)
    if ~isempty(explicit_paddings)    
        explicit_paddings = explicit_paddings(3:6);
        % convert [top bottom left right] to [top, left; bottom, right]
        explicit_paddings = reshape(explicit_paddings,[2,2]);
    end
    
    if strcmp(padding,'VALID')
        y = maxpool(input.value,ksize,'Stride',strides);
    elseif strcmp(padding,'SAME')
        y = maxpool(input.value,ksize,'Stride',strides,'Padding','same');
    elseif strcmp(padding,'EXPLICIT')
        y = maxpool(input.value, ksize, 'Stride',strides, 'Padding', explicit_paddings);
    end

    % assign output rank:
    y = struct('value', y, 'rank', 4);

end

