function Y = tfPad(X, paddings, constant_values)
    %{{import_statement}}

%   Copyright 2020-2022 The MathWorks, Inc.

    Xrank = X.rank;
    Xval = X.value;

    if ~isa(Xval, 'dlarray')
        % If a numeric array permute the input tensor to match Forward TF Format.   
        Xval = permute(Xval, Xrank:-1:1);
        TFLabels = repmat('U', [1 Xrank]);    
    elseif ~isempty(Xval.dims) && ~all(Xval.dims == 'U') && Xrank > 1 
        % If labeled dlarray, permute the input tensor to match Forward TF Format.         
        DLTLabels = Xval.dims;
        [permutationVec, TFLabels] = sortToTFLabel(1:Xrank, DLTLabels);  
        Xval = permute(Xval.stripdims, permutationVec);   
    elseif Xrank > 1
        % Assume the input dlarray to be in reverse TF order and permute to
        % forward TF
        Xval = permute(Xval.stripdims, Xrank:-1:1);
        TFLabels = repmat('U', [1 Xrank]);
    else
        % dlarray with rank <= 1, is already in forward Tf format
        Xval = Xval.stripdims;
        TFLabels = 'UU';
    end       

    % paddings is a Nx2 matrix. Where N is the number of dimensions of x. 
    % For a dimension D paddings(D, 1) is the number of values to pad
    % before the contents of x in that dimension. and paddings(D, 2) is the
    % number of values to add after the contents of x in that dimension. 
    % We always expect paddings to be a numeric array or a dlarray with all U labels
    % It will always be in reverse TF format.
    paddings = paddings.value';
    
    if isstruct(constant_values)
        constant_values = constant_values.value; 
    end
    
    sizeX = size(Xval); 
    if Xrank == 1
        % rank 1 input, its a vector 
        sizeX = size(Xval, 1);
    elseif Xrank > numel(sizeX)
        % add back potentially dropped dims 
        diff = Xrank - numel(sizeX); 
        sizeX(end+1:end+diff) = 1; 
    end 

    sizeY = zeros(1, X.rank); 
    for i = 1:size(paddings, 1)
        sizeY(i) = size(Xval, i) + paddings(i, 1) + paddings(i, 2); 
    end 
    
    if Xrank == 1
        % Padding does not change the rank of the input
        sizeY = [sizeY 1];
    end

    % Construct output array with padded size. 
    Y = dlarray(cast(constant_values, 'like', Xval) * ones(sizeY, 'like', Xval)); 

    % Construct subsref indices for inserting (and cropping) the original
    Ysubs = cell(1, size(paddings, 1)); 
    Xsubs = cell(1, size(paddings, 1)); 

    for i=1:numel(sizeX)
        Ysubs{i} = max(1,1+paddings(i,1)) : min(sizeY(i), sizeY(i)-paddings(i, 2));
        Xsubs{i} = max(1,1-paddings(i,1)) : min(sizeX(i), sizeX(i)+paddings(i, 2));
    end

    Sy      = struct('type', '()');
    Sy.subs = Ysubs;
    Sx      = struct('type', '()');
    Sx.subs = Xsubs;

    % Insert/crop the original into the result
    Y = subsasgn(Y, Sy, subsref(Xval, Sx));
    
    % re-label and convert back to DLT / Reverse TF ordering. 
    if Xrank > 1 && all(TFLabels == 'U')
        % Convert to reverse-TF format, before applying U labels
        Y = permute(Y, Xrank:-1:1);
    end
    
    Y = dlarray(Y, TFLabels);
    Y = struct('value', Y, 'rank', Xrank);
end
