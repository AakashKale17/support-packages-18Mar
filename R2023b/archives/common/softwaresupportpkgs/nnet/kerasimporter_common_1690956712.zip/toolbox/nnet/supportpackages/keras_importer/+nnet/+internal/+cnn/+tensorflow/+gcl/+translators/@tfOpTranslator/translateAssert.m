function result = translateAssert(~, MATLABArgIdentifierNames)
%

%   Copyright 2022 The MathWorks, Inc.

    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult; 
    result.Code = "assert(logical(" + MATLABArgIdentifierNames{1} + ".value));";
    result.ForwardRank = false; 
    result.Success = true; 
end 