function z = tfFloorMod(x, y)
%{{import_statement}}

%   Copyright 2023 The MathWorks, Inc.

    xrank = x.rank; 
    yrank = y.rank; 
    zrank = max(xrank, yrank); 
    x = x.value; 
    y = y.value; 
    
    if ~isfloat(x) && isfloat(y)
        x = cast(x, 'like', y); 
    elseif ~isfloat(y) && isfloat(x) 
        y = cast(y, 'like', x); 
    end 
    
    % in MATLAB, broadcasting starts from the left. In TF, broadcasting 
    % starts from the right. For this reason, we will permute x and y to 
    % match the reverse TF dimension. Using rank, we will know with certainty 
    % the correct permutation to reverse dimensions. We will assume non-dlt
    % formatted arrays are already in reverse TF dimension. 
    isXDLTFormat = isa(x, 'dlarray') && ~isempty(x.dims) && ~all(x.dims == 'U') && xrank > 1; 
    isYDLTFormat = isa(y, 'dlarray') && ~isempty(y.dims) && ~all(y.dims == 'U') && yrank > 1;
    if isXDLTFormat 
        [xPermutationVec, xtflabel] = sortToTFLabel(1:xrank, x.dims); 
        x = stripdims(x);
        x = permute(x, flip(xPermutationVec));
        % mod does not support dlarrays
        x = extractdata(x);
    elseif isa(x, 'dlarray') % with all U dimensions, already in reverse TF format
        x = stripdims(x);
        x = extractdata(x);
    end 
    
    if isYDLTFormat
        [yPermutationVec, ytflabel] = sortToTFLabel(1:yrank, y.dims); 
        y = stripdims(y);
        y = permute(y, flip(yPermutationVec));
        % mod does not support dlarrays
        y = extractdata(y);
    elseif isa(y, 'dlarray') % with all U dimensions, already in reverse TF format
        y = stripdims(y); 
        % mod does not support dlarrays
        y = extractdata(y);
    end

    z = mod(x, y);
    if any(y==0,'all')
    % mod(X,0) is X but FloorMod(X,0) is NaN
    % replace output by NaN wherever divisor is 0
        zRem = rem(x, y);
        z(isnan(zRem)) = NaN;
    end
    
    if isXDLTFormat && isYDLTFormat && numel(xtflabel) == numel(ytflabel) && all(xtflabel == ytflabel)
        if zrank > 1
            z = permute(z, zrank:-1:1); 
        end 
        z = dlarray(z, xtflabel);
    elseif isXDLTFormat && xrank == zrank
        if zrank > 1
            z = permute(z, zrank:-1:1); 
        end 
        z = dlarray(z, xtflabel); 
    elseif isYDLTFormat && yrank == zrank
        if zrank > 1
            z = permute(z, zrank:-1:1); 
        end 
        z = dlarray(z, ytflabel); 
    else 
        if zrank > 1
            z = dlarray(z, repmat('U', [1 zrank]));
        else
            z = dlarray(z, 'UU');
        end 
    end
    z = struct('value', z, 'rank', zrank); 
end 
