classdef TanhLayer < nnet.layer.Layer ...
    & nnet.internal.cnn.layer.Traceable
% TanhLayer   Tanh layer
%
%   layer = TanhLayer(Name) creates a tanh unit layer with
%   name Name. This type of layer calculates Y = tanh(X).

%   Copyright 2017-2020 The MathWorks, Inc.
    methods
        function this = TanhLayer(Name)
            this.Name = Name;
            this.Description = getString(message('nnet_cnn_kerasimporter:keras_importer:TanhDescription'));
            this.Type = getString(message('nnet_cnn_kerasimporter:keras_importer:TanhDescription'));
        end
        
        function Z = predict(~, X)
            Z = tanh(X);
        end
        
        function dLdX = backward( ~, ~, Z, dLdZ, ~ )
            dLdX = dLdZ.*(1+Z).*(1-Z);
        end
    end
end

