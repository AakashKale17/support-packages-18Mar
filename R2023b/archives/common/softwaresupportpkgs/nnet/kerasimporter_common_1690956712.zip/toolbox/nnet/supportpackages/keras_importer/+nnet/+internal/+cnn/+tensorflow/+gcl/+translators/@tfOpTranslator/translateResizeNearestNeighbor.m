function result = translateResizeNearestNeighbor(~, node_def, MATLABOutputName, MATLABArgIdentifierNames)
%

%   Copyright 2020-2021 The MathWorks, Inc.

    result = nnet.internal.cnn.tensorflow.gcl.NodeTranslationResult; 
    
    half_pixel_centers = "'asymmetric'"; 
    if isfield(node_def.attr, 'half_pixel_centers')
        if node_def.attr.half_pixel_centers.b
            half_pixel_centers = "'half-pixel'";
        end 
    end 
    
    result.Code = nnet.internal.cnn.tensorflow.gcl.util.writeFunctionCall("dlresize", {MATLABOutputName + ".value"}, [{MATLABArgIdentifierNames(1) + ".value"} ...
        {"'OutputSize'"} {"single(" + MATLABArgIdentifierNames{2} + ".value" + "(:)')"}, {"'GeometricTransformMode'", half_pixel_centers}]);
    result.ForwardRank = true;
    result.Success = true;
end 
