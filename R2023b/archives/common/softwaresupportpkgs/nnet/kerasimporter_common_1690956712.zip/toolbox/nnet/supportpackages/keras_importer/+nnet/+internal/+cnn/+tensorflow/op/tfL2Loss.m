function z = tfL2Loss(t)
%{{import_statement}}

%   Copyright 2020-2022 The MathWorks, Inc.

    z.value = dlarray(sum(t.value .^ 2, 'all') ./ 2, "U");
    z.rank = 0; 
end
