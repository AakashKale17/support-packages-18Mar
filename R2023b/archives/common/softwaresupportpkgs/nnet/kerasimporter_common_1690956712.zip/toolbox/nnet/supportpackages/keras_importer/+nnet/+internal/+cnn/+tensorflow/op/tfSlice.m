function z = tfSlice(input, begin, sliceSize)
    %{{import_statement}}
    % Copyright 2022 The MathWorks, Inc.

    inputval = input.value; 
    inputrank = input.rank; 
    beginval = begin.value; 
    beginrank = begin.rank;
    sliceSizeval = sliceSize.value; 
    sliceSizerank = sliceSize.rank; 

    % Get the values and ensure the ranks of begin and size are the same
    assert(beginrank == sliceSizerank, "tfSlice: ranks of begin and size are different.");
    assert(numel(beginval) == numel(sliceSizeval), "tfSlice: shape of begin and size are different.");

    if isdlarray(beginval)
        if ~isempty(beginval.dims) && ~all(beginval.dims == 'U')
            warning(['tfSlice begin has DLT labels: ' beginval.dims]);
        end
        beginval = extractdata(beginval); 
    end
    if isdlarray(sliceSizeval)
        if ~isempty(sliceSizeval.dims) && ~all(sliceSizeval.dims == 'U')
            warning(['tfSlice size has DLT labels: ' sliceSizeval.dims]);
        end
        sliceSizeval = extractdata(sliceSizeval); 
    end
    
    nSpecs = numel(beginval);
    if isa(inputval, 'dlarray') && ~isempty(inputval.dims) && ~all(inputval.dims=='U') 
        inputIsLabeled = true;
        datalabel = inputval.dims;
        [permutationVec, datalabel] = sortToTFLabel(1:inputrank, datalabel);
        inputval = stripdims(inputval);
        if inputrank > 1
            inputval = permute(inputval, fliplr(permutationVec));
        end        
    else
        inputIsLabeled = false; 
        if inputrank > 1
            datalabel = repmat('U', [1 inputrank]);
        else
            datalabel = 'UU';
        end
    end

    % Input should be in reverse TF format now
    % Flip the index vectors to match the input
    beginval = flip(beginval);
    sliceSizeval = flip(sliceSizeval);

    S = substruct('()', {});
    for i = 1:nSpecs
        curBeginIdx = single(beginval(i) + 1);
        if sliceSizeval(i) == -1
            curEndIdx = single(size(inputval, i));
        else
            curEndIdx = single(beginval(i)) + single(sliceSizeval(i));
        end
        idxVec = curBeginIdx:curEndIdx; 
        S.subs{i} = idxVec;
    end 
    
    % Index into the Input array, preserve the number of dimensions.
    zval = inputval(S.subs{:});

    if inputIsLabeled
        % Permute to forward TF format and apply labels
        zval = permute(zval, inputrank:-1:1);            
    end 
    zval = dlarray(zval, datalabel); 
    z = struct('value', zval, 'rank', inputrank); 
end