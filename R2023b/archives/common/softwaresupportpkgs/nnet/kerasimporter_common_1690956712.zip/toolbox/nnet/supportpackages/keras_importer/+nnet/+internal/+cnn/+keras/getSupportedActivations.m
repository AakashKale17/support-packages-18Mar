function activations = getSupportedActivations()
activations = {'linear', 'relu', 'relu6', 'sigmoid', 'softmax', 'tanh', 'elu', 'swish'}; 
end 