classdef FlattenCStyleTFLayer < nnet.layer.Layer & nnet.layer.Formattable
% FlattenCStyleTFLayer   FlattenCStyle TensorFlow layer
%
% layer = FlattenCStyleTFLayer(Name) creates a layer with name Name that
% flattens the input image into a vector, assuming C-style (or row-major)
% storage ordering of the input layer. Always returns a 2D output labelled CB.
% 
%   Copyright 2022 The MathWorks, Inc.
    methods
        function this = FlattenCStyleTFLayer(name)
            this.Name = name;
            this.Description = getString(message('nnet_cnn_kerasimporter:keras_importer:FlattenDescription'));  
            this.Type = getString(message('nnet_cnn_kerasimporter:keras_importer:FlattenType'));                      
        end
        
        function Z = predict( ~, X )
            fmt = dims(X);
            if ismember(fmt, ["SSSC", "SSSCB"])
                % X is size [H W C D N].
                % Z is size [1 1 1 HWCD N].
                [sz1, sz2, sz3, sz4, sz5] = size(X);
                Z = reshape(permute(stripdims(X),[4 3 2 1 5]), [sz1*sz2*sz3*sz4 sz5]);
            elseif ismember(fmt, ["SC", "SCB"])
                [sz1, sz2, sz3] = size(X); 
                Z = reshape(permute(stripdims(X), [2 1 3]), [sz1*sz2 sz3] ); 
            elseif ismember(fmt,"CBT")
                %Flatten with Sequence Input Layer
                %Common use case for 1D Layers
                %X: [C B T] ; Z:[CT B]
                [sz1, sz2, sz3] = size(X);
                Z = reshape(permute(stripdims(X),[1 3 2]), [sz1*sz3 sz2]);
            elseif ismember(fmt, ["SSC", "SSCB"])
                % X is size [H W C N].
                % Z is size [1 1 HWC N].
                [sz1, sz2, sz3, sz4] = size(X);
                Z = reshape(permute(stripdims(X),[3 2 1 4]), [sz1*sz2*sz3 sz4]);                
            elseif all(fmt(1:end-1) == 'S') && strcmp(fmt(end),'B')
                % X is coming from a custom layer: S*B
                S = size(X);
                lastSDimIdx = numel(fmt)-1;
                Z = reshape(permute(stripdims(X),[lastSDimIdx:-1:1 numel(fmt)]), [prod(S(1:end-1)) S(end)]);
            else
                Z = X;
                nnet.internal.cnn.keras.util.warningWithoutBacktrace('nnet_cnn_kerasimporter:keras_importer:FlattenCStyleTFUnexpectedInput');
            end
            % Always apply CB labels.
            Z = dlarray(Z, "CB");            
        end
    end
end

