function y = tfBiasAdd(value, bias, dataFormat)
    %{{import_statement}}

    %   Copyright 2020-2022 The MathWorks, Inc.

    if isa(value.value, 'dlarray')
        xLabels = value.value.dims;
    else
        xLabels = [];
    end
        
    % If the input tensor is unlabeled. We assume it is in reverse TensorFlow order
    if isempty(xLabels) || all(xLabels == 'U')        
        if strcmp(dataFormat, "NHWC")
            % In the reverse TF format, first dimension is channels
            channelDim = 1; 
        elseif strcmp(dataFormat, "NCHW")
            % In the reverse TF format, second last dimension is channels
            channelDim = value.rank - 1;
        else 
            error('BiasAdd only supports input data formats: "NHWC" and "NCHW"');
        end
    else
        % Input is labelled and should contain a labelled C dimension
        channelDim = finddim(value.value, "C"); 
    end
    
    biasShape = num2cell(ones(value.rank, 1)); 
    biasShape{channelDim} = []; 
    y = value.value + reshape(bias.value, biasShape{:}); 
    y = struct('value', y, 'rank', value.rank);
end
