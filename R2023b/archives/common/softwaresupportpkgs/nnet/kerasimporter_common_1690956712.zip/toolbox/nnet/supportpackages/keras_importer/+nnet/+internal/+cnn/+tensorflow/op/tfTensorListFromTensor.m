function z = tfTensorListFromTensor(tensor, ~)
    %{{import_statement}}

%   Copyright 2023 The MathWorks, Inc.

    % The TensorListFromTensor operator returns a TensorList tensor:
    %   tf.Tensor(<TensorList>, shape=(), dtype=variant)
    % 
    % Hence, tfTensorListFromTensor returns an array of structs, each holding a 
    % dlarray and its rank.
    % 
    % element_shape: The only valid scalar shape tensor is the fully unknown 
    % shape specified as -1 can only be -1 if it is a scalar else it has to
    % be a rank 1 tensor containing the shape of the tensor elements to be 
    % reserved, hence this will always be in forward TF format
    % tensor_shape = element_shape.value; 
    % tensor_shape_rank = element_shape.rank;

    tval = tensor.value;
    trank = tensor.rank;
    
    isTDLTFormat = isa(tval, 'dlarray') && ~isempty(tval.dims) && ~all(tval.dims == 'U') && trank > 1;     
    if isTDLTFormat 
        [tPermutationVec, ~] = sortToTFLabel(1:trank, tval.dims); 
        tval = stripdims(tval);
        tval = permute(tval, tPermutationVec); 
    elseif isa(tval, 'dlarray') 
        % with all U dimensions, already in reverse TF format permute to forward TF
        tval = stripdims(tval);
        tval = permute(tval, trank:-1:1); 
    else
        tval = permute(tval, trank:-1:1); 
    end 

    % tval should be in forward TF format
    num_elements = size(tval,1);
    elem_rank = trank - 1;
    
    if trank > 1    
        elem_shape = size(tval, 2:trank);
    else        
        elem_shape = 1;
    end

    z = [];
    for i = 1:num_elements        
        if elem_rank <= 1
            % Keep forward TF format for individual element tensors
            elem_tensor = dlarray(tval(i,:),'UU');
            element = struct('value', elem_tensor, 'rank', elem_rank);            
        else
            % Reverse TF format as element tensor rank is greater than 1
            elem_tensor = tval(i,:);
            elem_tensor = reshape(elem_tensor,elem_shape);
            elem_tensor = permute(elem_tensor,elem_rank:-1:1);
            elem_tensor = dlarray(elem_tensor, repmat('U', [1 elem_rank]));
            element = struct('value', elem_tensor, 'rank', elem_rank);            
        end    
        z = [z element]; %#ok<AGROW>
    end
end






