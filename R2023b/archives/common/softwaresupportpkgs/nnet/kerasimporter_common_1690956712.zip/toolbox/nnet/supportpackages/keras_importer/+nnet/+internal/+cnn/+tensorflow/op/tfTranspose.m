function z = tfTranspose(x, perm)
%{{import_statement}}

%   Copyright 2021-2022 The MathWorks, Inc.

    xrank = x.rank;
    
    % transpose can only happen for xrank > 1
    if xrank < 2
        z = x;
        return;
    end
    
    x = x.value;
    if isstruct(perm)
        perm = perm.value;
    end
    % check if perm is a dlarray
    if isa(perm, 'dlarray')
        perm = perm.extractdata;
    end

    % check if input is coming from DLT
    isXDLTFormat = isa(x, 'dlarray') && ~isempty(x.dims) && ~all(x.dims == 'U'); 
    
    % convert DLT to reverse TensorFlow format
    if isXDLTFormat 
        [xPermutationVec, xtflabel] = sortToTFLabel(1:xrank, x.dims); 
        x = stripdims(x);
        x = permute(x, flip(xPermutationVec)); 
    % unlabeled dlarrys are assumed to be in reverse TersorFlow format
    elseif isa(x, 'dlarray')
        x = stripdims(x); 
    end 
    % x should be in reverse TF format now

    % perm will always be rank-1 and numel(perm) should equal xrank
    % convert TensorFlow permutation vector to 1-indexed reverse TensorFlow
    % indexing
    perm = xrank - flip(perm);
    
    % use permute to apply transpose operation
    z = permute(x, perm);
    
    if isXDLTFormat
        % convert back to DLT format
        z = permute(z, xrank:-1:1);
        z = dlarray(z, xtflabel);
    else
        z = dlarray(z, repmat('U', [1 xrank]));
    end
    z = struct('value', z, 'rank', xrank); 
end