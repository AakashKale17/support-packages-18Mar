classdef ConverterForYOLOv2OutputLayer < ConverterForIdentityOutputLayers

    %   Copyright 2022 The MathWorks, Inc.

end