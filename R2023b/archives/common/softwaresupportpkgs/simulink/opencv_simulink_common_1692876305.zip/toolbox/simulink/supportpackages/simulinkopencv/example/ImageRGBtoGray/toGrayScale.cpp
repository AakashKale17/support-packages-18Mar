#include "toGrayScale.hpp"

void toGrayScale(Mat& img){
    if(img.channels()==3){
        cvtColor(img,img,COLOR_BGR2GRAY);
    }        
}