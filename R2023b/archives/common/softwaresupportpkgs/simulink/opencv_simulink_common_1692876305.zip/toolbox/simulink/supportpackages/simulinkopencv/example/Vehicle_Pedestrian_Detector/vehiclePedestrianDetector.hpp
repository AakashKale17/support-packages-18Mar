#include <iostream>
#include <opencv2/opencv.hpp>

using namespace cv;
using namespace std;
using namespace cv::ml;


void drawDetect(Mat &img, Mat &out);
void adjustRect(Rect & r);
void detectPeople(Mat& out);
void detectVehicle(Mat& out);
