#include "vehiclePedestrianDetector.hpp"
void adjustRect(Rect & r)
{
	r.x += cvRound(r.width*0.1);
	r.width = cvRound(r.width*0.8);
	r.y += cvRound(r.height*0.07);
	r.height = cvRound(r.height*0.8);
}
void detectPeople(Mat& out)
{
	HOGDescriptor hog;
	hog.load("pedestrian_detector.yml");
	vector<double> weights;
	vector<Rect> detections;
	hog.detectMultiScale(out, detections, weights);
	for (size_t j = 0; j < detections.size(); j++)
	{
		if (weights[j] >= 0.50)
		{
				Rect r = detections[j];
				adjustRect(r);
				Scalar color = Scalar(0,0,255);
				rectangle(out, r.tl(), r.br(), color, 2);
		}
	}
}

void detectVehicle(Mat& out)
{
	HOGDescriptor hog;
	hog.load("vehicle_detector.yml");
	vector<double> weights;
	vector<Rect> detections;
	hog.detectMultiScale(out, detections, weights);
	for (size_t j = 0; j < detections.size(); j++)
	{
		if (weights[j] >= 0.50)
		{
				Rect r = detections[j];
				adjustRect(r);
				Scalar color = Scalar(0,128,0);
				rectangle(out, r.tl(), r.br(), color, 2);
		}
	}
}
void drawDetect(Mat& img, Mat& out)
{
	out = img ;
	detectPeople(out);
	detectVehicle(out);
}
