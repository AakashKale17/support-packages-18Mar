ImageRGBtoGray Example Instructions
==================================

toGrayScale.hpp Functions
-------------------------
1. toGrayScale(Mat& img) - takes an RGB image by reference and converts it to grayscale.
   Note: The generated subsystem has ToOpenCV block which converts RGB image to a BGR image. 
   Therefore, CV_BGR2GRAY is used in this example.

Usage Instructions
------------------
1. Copy the contents of this folder to a writable directory and set that folder as the current folder.
   Additional files will be generated in the folder.
2. Import the "toGrayScale.cpp" and "toGrayScale.hpp" using OpenCV Importer app.
3. Select the "toGrayScale" function and set "img" I/O Type to "InputOutput".
4. Select the checkbox to use "Simulink.ImageType".
   Also, set the default "Color Format" to "RGB" and "Array Layout" to "Column-major".
4. Once the library is created, to simulate the model, drag the generated subsystem "slwrap_subsystem_toGrayScale"  to "ToGrayScale.slx" model.
5. Double click the subsystem block and make sure the subsystem's mask parameters matches with the properties:
   Rows = 480, Columns = 640, and Channels = 1
        