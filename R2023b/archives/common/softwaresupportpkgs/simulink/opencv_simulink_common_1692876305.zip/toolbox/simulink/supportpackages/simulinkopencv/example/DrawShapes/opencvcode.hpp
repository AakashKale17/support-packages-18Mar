#ifndef OPENCVCODE_HPP
#define OPENCVCODE_HPP
#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;
extern void drawLine(Mat img, Point start, Point end, Scalar color);
extern void drawEllipse(Mat img, double angle, Point center, Size axesSize, Scalar color);
extern void drawFilledCircle(Mat img, Point center, Scalar color, int radius);
extern void drawPolygon(Mat img, vector<Point> rook_points_vector, Scalar color);
extern void drawRectangle(Mat image, Rect mRect, Scalar color);
extern void drawAtom(Mat atom_image,int sideLength); 
extern void drawRook(Mat rook_image,int sideLength); 
#endif