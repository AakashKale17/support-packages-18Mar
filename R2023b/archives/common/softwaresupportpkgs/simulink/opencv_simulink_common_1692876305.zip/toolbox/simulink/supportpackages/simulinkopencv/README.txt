# Copyright 2019-2020 The MathWorks, Inc.
CONTENTS OF THIS FILE
---------------------
* Introduction
* Requirements
* Installation
* Contents
* Utility functions
* How to import Custom OpenCV code
* Example


INTRODUCTION
------------
"Computer Vision Toolbox Interface for OpenCV in Simulink" is used to help users to import their custom Opencv code 
into simulink models. 

REQUIREMENTS
------------
This package requires the following:
* Computer Vision Toolbox Version R2018b installation
* A compatible C++ compiler
* simulink
The OpenCV plugin uses pre-built OpenCV libraries which are shipped with the 
Computer Vision Toolbox. Your compiler must be compatible with the 
pre-built OpenCV libraries. The following is a list of compatible compilers:
    Windows 64 bit: MS Visual Studio 2017 or MS Visual Studio 2015
    Linux 64 bit: gcc-6.3 and above (g++)
    Mac 64 bit: Xcode 9.0.0 and above (Clang++)

INSTALLATION
------------
Use the support package installer which can be invoked using the  
... function.
After the support package is installed, the location of the package can be 
found by executing the following MATLAB command:
>> matlabshared.supportpkg.getSupportPackageRoot()

CONTENTS
--------
In addition to the files and folders required by the support package installer, 
the package contains the following folder:

example: Few subfolders containing examples. Each subfolder contains a simulink model that uses C-caller
blocks that uses the custom opencv code.

UTILITY LIBRARY
-----------------
The support package uses a set of utility blocks to pass data 
between OpenCV and Simulink.

General purpose utility blocks are available at:
  Computer Vision Toolbox Interface for OpenCV in Simulink.

HOW TO IMPORT CUSTOM OPENCV CODE
---------------------------------
Follow these steps:
1. Open the Simulink OpenCV importer wizard from the apps gallery. OpenCV importer wizard app is located under Image Processing 
    Apps Section.
2. Enter the location of the opencv code and other details.
3. On processing forward select the function that you want to import and when you finish using the wizard.
    the blocks will be generated in your simulink library.

EXAMPLES
--------
There are three examples included in the package: 
* SmileDetector
* DrawShapes
* ImageRGBtoGray

To run them, follow the steps in the README.txt file located in the corresponding 
sub-folders of the examples folder.

