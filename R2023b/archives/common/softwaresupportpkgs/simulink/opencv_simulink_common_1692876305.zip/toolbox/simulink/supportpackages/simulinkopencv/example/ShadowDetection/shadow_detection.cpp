#include <opencv2/imgproc.hpp>
#include <opencv2/core.hpp>
#include "shadow_detection.hpp"

void calculate_shadow_ratio(cv::Mat& image_b_blurred, cv::Mat& image_g_blurred, cv::Mat& dst)
{
    cv::Mat image_difference(image_b_blurred.rows, image_b_blurred.cols, CV_64F);
    subtract(image_b_blurred, image_g_blurred, image_difference);

    cv::Mat image_sum(image_b_blurred.rows, image_b_blurred.cols, CV_64F);
    add(image_b_blurred, image_g_blurred, image_sum);

    cv::Mat image_division;
    divide(image_difference, image_sum, image_division);

    cv::parallel_for_(cv::Range(0, image_division.rows), [&](const cv::Range& range) {
        for (int i = range.start; i < range.end; i++)
        {
            for (int j = 0; j < image_division.cols; j++)
            {
                image_division.at<float>(i, j) = ((float)4 / CV_PI) * atan(image_division.at<float>(i, j));
            }
        }
        });

    dst = image_division;
}


void threshold_and_mask(cv::Mat& image, cv::Mat& image_shadow_ratio, cv::Mat& dst, double thresh)
{

    cv::Mat image_thresh(image_shadow_ratio.rows, image_shadow_ratio.cols, CV_8UC1);

    int type = image_shadow_ratio.type();

    cv::parallel_for_(cv::Range(0, image_shadow_ratio.rows), [&](const cv::Range& range) {
        for (int i = range.start; i < range.end; i++)
        {
            for (int j = 0; j < image_shadow_ratio.cols; j++)
            {
                if (i < 5 || j < 5)
                {
                    image_thresh.at<uchar>(i, j) = 0;
                }
                else
                {
                    image_thresh.at<uchar>(i, j) = (image_shadow_ratio.at<float>(i, j) > thresh) ? 255 : 0;
                }
            }
        }
        });

    dst = image_thresh;
}

void run_shadow_detection(cv::Mat& inImage, cv::Mat &outImage, double thresh)
{

    // Extracting the blue and green channels
    cv::Mat image_b;
    cv::Mat image_g;
    cv::extractChannel(inImage, image_b, 0);
    cv::extractChannel(inImage, image_g, 1);

    // Running median blur
    medianBlur(image_b, image_b, 3);
    medianBlur(image_g, image_g, 3);

    // Converting to float Mat
    image_b.convertTo(image_b, CV_32FC1);
    image_g.convertTo(image_g, CV_32FC1);

    // Calculate shadow-ratio
    cv::Mat image_shadow_ratio;
    calculate_shadow_ratio(image_b, image_g, image_shadow_ratio);

    // Do the thresholding
    cv::Mat image_shadow_mask;
    threshold_and_mask(inImage, image_shadow_ratio, image_shadow_mask, thresh);

    // Applying opening-morphology (equivalent to bwareaopen)
    cv::Mat image_morphed;
    cv::Mat kernel = cv::Mat::ones(5, 5, CV_8UC1);
    morphologyEx(image_shadow_mask, image_morphed, cv::MORPH_OPEN, kernel);

    // Image dilation
    cv::Mat image_dilated;
    cv::Mat structuring_element = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5));
    dilate(image_morphed, image_dilated, structuring_element);

    // Creating the border
    cv::Mat image_border = image_dilated - image_shadow_mask;
    image_border = image_border > 0;

    // Overlaying the border on input image
    cv::Mat_<cv::Vec3b> image_final = inImage;
    for (int i = 0; i < inImage.rows; i++)
    {
        for (int j = 0; j < inImage.cols; j++)
        {
            if (image_border.at<uchar>(i, j) > 0)
            {
                image_final(i, j)[2] = image_border.at<uchar>(i, j);
            }
        }
    }

    outImage = image_final;
}
