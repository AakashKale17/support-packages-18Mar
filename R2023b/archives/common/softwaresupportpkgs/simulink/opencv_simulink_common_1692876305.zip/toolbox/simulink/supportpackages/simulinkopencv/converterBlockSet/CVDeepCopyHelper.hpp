/* Copyright 2019 The MathWorks, Inc. */
#ifndef CV_DEEPCOPY_HELPER_HPP
#define CV_DEEPCOPY_HELPER_HPP
typedef void* cv_Mat;
typedef void* cv_InputArray;
typedef void* cv_OutputArray;
typedef void* cv_InputOutputArray;
typedef void* cv_Rect;
typedef void* cv_RotatedRect;
typedef void* cv_KeyPoint;
typedef void* cv_DMatch;
typedef void* cv_Point;
typedef void* cv_Point2f;
typedef void* cv_Point2d;
typedef void* cv_Point3i;
typedef void* cv_Point3f;
typedef void* cv_Point3d;
typedef void* cv_Size;
typedef void* cv_Scalar;
typedef void* cv_Range;
typedef void* cv_TermCriteria;
typedef void* vector_cv_Rect;
typedef void* vector_cv_RotatedRect;
typedef void* vector_cv_KeyPoint;
typedef void* vector_cv_Point;
typedef void* vector_cv_Point2f;
typedef void* vector_cv_Point2d;
typedef void* vector_cv_Point3i;
typedef void* vector_cv_Point3f;
typedef void* vector_cv_Point3d;
typedef void* vector_cv_DMatch;
typedef void* vector_vector_cv_Point;
typedef void* vector_vector_cv_Point2f;
typedef void* vector_vector_cv_Point2d;
typedef void* vector_vector_cv_Point3i;
typedef void* vector_vector_cv_Point3f;
typedef void* vector_vector_cv_Point3d;
typedef void* vector_vector_cv_DMatch;
#ifdef __cplusplus
    extern "C" {
#endif
int cv_MatDeepCopyFcn(cv_Mat* dst,const cv_Mat* src);
int cv_InputArrayDeepCopyFcn(cv_InputArray* dst,const cv_InputArray* src);
int cv_OutputArrayDeepCopyFcn(cv_OutputArray* dst,const cv_OutputArray* src);
int cv_InputOutputArrayDeepCopyFcn(cv_InputOutputArray* dst,const cv_InputOutputArray* src);
int cv_RectDeepCopyFcn(cv_Rect* dst,const cv_Rect* src);
int cv_RotatedRectDeepCopyFcn(cv_RotatedRect* dst,const cv_RotatedRect* src);
int cv_KeyPointDeepCopyFcn(cv_KeyPoint* dst,const cv_KeyPoint* src);
int cv_DMatchDeepCopyFcn(cv_DMatch* dst,const cv_DMatch* src);
int cv_PointDeepCopyFcn(cv_Point* dst,const cv_Point* src);
int cv_Point2fDeepCopyFcn(cv_Point2f* dst,const cv_Point2f* src);
int cv_Point2dDeepCopyFcn(cv_Point2d* dst,const cv_Point2d* src);
int cv_Point3iDeepCopyFcn(cv_Point3i* dst,const cv_Point3i* src);
int cv_Point3fDeepCopyFcn(cv_Point3f* dst,const cv_Point3f* src);
int cv_Point3dDeepCopyFcn(cv_Point3d* dst,const cv_Point3d* src);
int cv_SizeDeepCopyFcn(cv_Size* dst,const cv_Size* src);
int cv_ScalarDeepCopyFcn(cv_Scalar* dst,const cv_Scalar* src);
int cv_RangeDeepCopyFcn(cv_Range* dst,const cv_Range* src);
int cv_TermCriteriaDeepCopyFcn(cv_TermCriteria* dst,const cv_TermCriteria* src);
int vector_cv_RectDeepCopyFcn(vector_cv_Rect* dst,const vector_cv_Rect* src);
int vector_cv_RotatedRectDeepCopyFcn(vector_cv_RotatedRect* dst,const vector_cv_RotatedRect* src);
int vector_cv_KeyPointDeepCopyFcn(vector_cv_KeyPoint* dst,const vector_cv_KeyPoint* src);
int vector_cv_PointDeepCopyFcn(vector_cv_Point* dst,const vector_cv_Point* src);
int vector_cv_Point2fDeepCopyFcn(vector_cv_Point2f* dst,const vector_cv_Point2f* src);
int vector_cv_Point2dDeepCopyFcn(vector_cv_Point2d* dst,const vector_cv_Point2d* src);
int vector_cv_Point3iDeepCopyFcn(vector_cv_Point3i* dst,const vector_cv_Point3i* src);
int vector_cv_Point3fDeepCopyFcn(vector_cv_Point3f* dst,const vector_cv_Point3f* src);
int vector_cv_Point3dDeepCopyFcn(vector_cv_Point3d* dst,const vector_cv_Point3d* src);
int vector_cv_DMatchDeepCopyFcn(vector_cv_DMatch* dst,const vector_cv_DMatch* src);
int vector_vector_cv_PointDeepCopyFcn(vector_vector_cv_Point* dst,const vector_vector_cv_Point* src);
int vector_vector_cv_Point2fDeepCopyFcn(vector_vector_cv_Point2f* dst,const vector_vector_cv_Point2f* src);
int vector_vector_cv_Point2dDeepCopyFcn(vector_vector_cv_Point2d* dst,const vector_vector_cv_Point2d* src);
int vector_vector_cv_Point3iDeepCopyFcn(vector_vector_cv_Point3i* dst,const vector_vector_cv_Point3i* src);
int vector_vector_cv_Point3fDeepCopyFcn(vector_vector_cv_Point3f* dst,const vector_vector_cv_Point3f* src);
int vector_vector_cv_Point3dDeepCopyFcn(vector_vector_cv_Point3d* dst,const vector_vector_cv_Point3d* src);
int vector_vector_cv_DMatchDeepCopyFcn(vector_vector_cv_DMatch* dst,const vector_vector_cv_DMatch* src);
#ifdef __cplusplus
    }
#endif
#endif
