Image Cartoonizer Example Instructions
===================================
cartoonizer.hpp
---------------------
cartoonize

inImage    - Input Image in the cv::Mat format
outImage   - Output Image in the cv::Mat format
maskRadius - Size of the image filter for intensity comparison
threshold  - Threshold intensity difference between pixels which will result in darkening
ramp       - Intensity gradient in the output image

Usage Instructions
---------------------
1. Copy the contents of this folder to a writable directory and set that folder as the current folder.
   Additional files will be generated in the folder.
2. Import the "cartoonizer.cpp" and "cartoonizer.hpp" using OpenCV Importer app.
3. Select the function "cartoonize" in the listed functions.
4. Set "outImage" as "Output" and the rest of the arguments as "Input" in the drop-down of I/O Type.
5. Select the checkbox to use "Simulink.ImageType".
   Also, set the default "Color Format" to "RGB" and "Array Layout" to "Column-major".
6. Once the library is created, to simulate the model, drag the generated subsystem to "Cartoonizer.slx" and connect to the blocks. 
7. Double click the subsystem block and make sure the subsystem's mask parameters matches with input port's properties:
   Rows = 240, Columns = 360, and Channels = 3