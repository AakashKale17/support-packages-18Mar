#include "opencvcode.hpp"

void drawLine(Mat img, Point start, Point end, Scalar color)
{
  int thickness = 2;
  int lineType = 8;
  line(img,
       start,
       end,
       color,
       thickness,
       lineType);
}
void drawEllipse(Mat img, double angle, Point center, Size axesSize, Scalar color)
{
  int thickness = 2;
  int lineType = 8;

  ellipse(img,
          center,
          axesSize,
          angle,
          0,
          360,
          color,
          thickness,
          lineType);
}

void drawFilledCircle(Mat img, Point center, Scalar color, int radius)
{
  int thickness = -1;
  int lineType = 8;

  circle(img,
         center,
         radius,
         color,
         thickness,
         lineType);
}

void drawPolygon(Mat img, vector<Point> rook_points_vector, Scalar color)
{
  int lineType = 8;
  // Create some points 
  Point rook_points[1][20];
  int count = 0;
  for(auto i:rook_points_vector){
    rook_points[0][count++] = i;
  }
  
  const Point *ppt[1] = {rook_points[0]};
  int npt[] = {rook_points_vector.size()};

  fillPoly(img,
           ppt,
           npt,
           1,
           color,
           lineType);
}

void drawRectangle(Mat image, Rect mRect, Scalar color)
{
  
  rectangle(image,
            mRect,
            color,
            -1,
            8);
}

void drawAtom(Mat atom_image,int sideLength){
    drawEllipse( atom_image, 90 , Point(sideLength/2.0, sideLength/2.0), Size( sideLength/4.0, sideLength/16.0 ), Scalar( 255, 0, 0 ));
    drawEllipse( atom_image, 0 , Point(sideLength/2.0, sideLength/2.0), Size( sideLength/4.0, sideLength/16.0 ), Scalar( 255, 0, 0 ));
    drawEllipse( atom_image, 45 , Point(sideLength/2.0, sideLength/2.0), Size( sideLength/4.0, sideLength/16.0 ), Scalar( 255, 0, 0 ));
    drawEllipse( atom_image, -45 , Point(sideLength/2.0, sideLength/2.0), Size( sideLength/4.0, sideLength/16.0 ), Scalar( 255, 0, 0 ));
    drawFilledCircle( atom_image, Point( sideLength/2.0, sideLength/2.0),  Scalar( 0, 255, 255 ), sideLength/32.0);
}

void drawRook(Mat rook_image, int sideLength){
//       /// 2. Draw a rook
// 
//     /// 2.a. Create a convex polygon
    vector<Point> vecPoints;
    vecPoints.push_back(Point( sideLength/4.0, 7*sideLength/8.0 ));
    vecPoints.push_back(Point( 3*sideLength/4.0, 7*sideLength/8.0 ));
    vecPoints.push_back(Point( 3*sideLength/4.0, 13*sideLength/16.0 ));
    vecPoints.push_back(Point( 11*sideLength/16.0, 13*sideLength/16.0 ));
    vecPoints.push_back(Point( 19*sideLength/32.0, 3*sideLength/8.0 ));
    vecPoints.push_back(Point( 3*sideLength/4.0, 3*sideLength/8.0 ));
    vecPoints.push_back(Point( 3*sideLength/4.0, sideLength/8.0 ));
    vecPoints.push_back(Point( 26*sideLength/40.0, sideLength/8.0 ));
    vecPoints.push_back(Point( 26*sideLength/40.0, sideLength/4.0 ));
    vecPoints.push_back(Point( 22*sideLength/40.0, sideLength/4.0 ));
    
    vecPoints.push_back(Point( 22*sideLength/40.0, sideLength/8.0 ));
    vecPoints.push_back(Point( 18*sideLength/40.0, sideLength/8.0 ));
    vecPoints.push_back(Point( 18*sideLength/40.0, sideLength/4.0 ));
    vecPoints.push_back(Point( 14*sideLength/40.0, sideLength/4.0 ));
    vecPoints.push_back(Point( 14*sideLength/40.0, sideLength/8.0 ));
    vecPoints.push_back(Point( sideLength/4.0, sideLength/8.0 ));
    vecPoints.push_back(Point( sideLength/4.0, 3*sideLength/8.0 ));
    vecPoints.push_back(Point( 13*sideLength/32.0, 3*sideLength/8.0 ));
    vecPoints.push_back(Point( 5*sideLength/16.0, 13*sideLength/16.0 ));
    vecPoints.push_back(Point( sideLength/4.0, 13*sideLength/16.0) );
    drawPolygon( rook_image ,vecPoints, Scalar(255,255,0));
//    
//     /// 2.b. Creating rectangles
    drawRectangle( rook_image,
               Rect(Point( 0, 7*sideLength/8.0 ),Point( sideLength, sideLength)),
               Scalar( 0, 255, 255 ));
// 
//     /// 2.c. Create a few lines
    drawLine( rook_image, Point( 0, 15*sideLength/16 ), Point( sideLength, 15*sideLength/16 ), Scalar( 0, 255, 0));
    drawLine( rook_image, Point( sideLength/4, 7*sideLength/8 ), Point( sideLength/4, sideLength ) , Scalar( 0, 255, 0));
    drawLine( rook_image, Point( sideLength/2, 7*sideLength/8 ), Point( sideLength/2, sideLength ) , Scalar( 0, 255, 0));
    drawLine( rook_image, Point( 3*sideLength/4, 7*sideLength/8 ), Point( 3*sideLength/4, sideLength ) , Scalar( 0, 255, 0));
}