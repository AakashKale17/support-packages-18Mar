#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>

#include "cartoonizer.hpp"

/* Simple cartoonizer algorithm
 Input params;
 Mask radius = radius of pixel neighborhood for intensity comparison
 Threshold   = relative intensity difference which will result in darkening
 Ramp        = amount of relative intensity difference before total black
 Blur radius = mask radius / 3.0
 
 Algorithm:
 For each pixel, calculate pixel intensity value to be: avg (blur radius)
 relative diff = pixel intensity / avg (mask radius)
 If relative diff < Threshold
   intensity mult = (Ramp - MIN (Ramp, (Threshold - relative diff))) / Ramp
   pixel intensity *= intensity mult
 -----------------
 Author: Meng Xipeng  mengxipeng@gmail.com
 Modified by Alaa Ali, MathWorks, Inc. (May 2020)
 This function supports grayscale and rgb image 
 */

void cartoonize(cv::Mat& inImage, cv::Mat& outImage, int maskRadius, float threshold, float ramp)
{
	const int R = inImage.rows, C = inImage.cols, nChan = inImage.channels();
	
	outImage = inImage.clone();
	cv::Mat fimage;
	cv::Mat mask = (1.0 / maskRadius) * cv::Mat::ones(1, maskRadius, CV_32F);

	cv::sepFilter2D(inImage, fimage, -1, mask, mask);

	cv::parallel_for_(cv::Range(0, R), [&](cv::Range range) {
		for (int i = range.start; i < range.end; ++i) {
			uint8_t* iptr = inImage.ptr<uint8_t>(i);
			uint8_t* fptr = fimage.ptr<uint8_t>(i);
			uint8_t* optr = outImage.ptr<uint8_t>(i);
			for (int j = 0; j < C; ++j) {
				for (int k = 0; k < nChan; ++k) {
					float rdiff = iptr[nChan * j + k] / fptr[nChan * j + k];
					if (rdiff < threshold) {
						//calculation of intensity multiplication factor
						float intensityMult = (float) (ramp - std::min(ramp, threshold - rdiff)) / (float)ramp;
						optr[nChan * j + k] = (uint8_t)( iptr[nChan * j + k] * intensityMult );
					}
				}
			}
		}
	});
}