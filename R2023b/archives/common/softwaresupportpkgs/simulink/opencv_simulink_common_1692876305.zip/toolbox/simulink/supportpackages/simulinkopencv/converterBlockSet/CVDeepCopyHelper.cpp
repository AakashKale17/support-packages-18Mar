/* Copyright 2019 The MathWorks, Inc. */
#include "CVDeepCopyHelper.hpp"
#include "opencv2/core.hpp"
namespace opencv_sim{
template<typename T>
int copy(T* dst, const T* src){
    if(dst != NULL && src != NULL){
        *dst = *src;
    }
    return 1;
}
}
using namespace std;
using namespace cv;
#ifdef __cplusplus
    extern "C" {
#endif
int cv_MatDeepCopyFcn(cv_Mat* dst,const cv_Mat* src){
    cv::Mat* out = reinterpret_cast<cv::Mat*>(*dst);
    const cv::Mat* in  = reinterpret_cast<const cv::Mat*>(*src);
    return opencv_sim::copy<cv::Mat>(out,in);
}
int cv_InputArrayDeepCopyFcn(cv_InputArray* dst,const cv_InputArray* src){
    cv::_InputArray* out = reinterpret_cast<cv::_InputArray*>(*dst);
    const cv::_InputArray* in  = reinterpret_cast<const cv::_InputArray*>(*src);
    return opencv_sim::copy<cv::_InputArray>(out,in);
}
int cv_OutputArrayDeepCopyFcn(cv_OutputArray* dst,const cv_OutputArray* src){
    cv::_OutputArray* out = reinterpret_cast<cv::_OutputArray*>(*dst);
    const cv::_OutputArray* in  = reinterpret_cast<const cv::_OutputArray*>(*src);
    return opencv_sim::copy<cv::_OutputArray>(out,in);
}
int cv_InputOutputArrayDeepCopyFcn(cv_InputOutputArray* dst,const cv_InputOutputArray* src){
    cv::_InputOutputArray* out = reinterpret_cast<cv::_InputOutputArray*>(*dst);
    const cv::_InputOutputArray* in  = reinterpret_cast<const cv::_InputOutputArray*>(*src);
    return opencv_sim::copy<cv::_InputOutputArray>(out,in);
}
int cv_RectDeepCopyFcn(cv_Rect* dst,const cv_Rect* src){
    cv::Rect* out = reinterpret_cast<cv::Rect*>(*dst);
    const cv::Rect* in  = reinterpret_cast<const cv::Rect*>(*src);
    return opencv_sim::copy<cv::Rect>(out,in);
}
int cv_RotatedRectDeepCopyFcn(cv_RotatedRect* dst,const cv_RotatedRect* src){
    cv::RotatedRect* out = reinterpret_cast<cv::RotatedRect*>(*dst);
    const cv::RotatedRect* in  = reinterpret_cast<const cv::RotatedRect*>(*src);
    return opencv_sim::copy<cv::RotatedRect>(out,in);
}
int cv_KeyPointDeepCopyFcn(cv_KeyPoint* dst,const cv_KeyPoint* src){
    cv::KeyPoint* out = reinterpret_cast<cv::KeyPoint*>(*dst);
    const cv::KeyPoint* in  = reinterpret_cast<const cv::KeyPoint*>(*src);
    return opencv_sim::copy<cv::KeyPoint>(out,in);
}
int cv_DMatchDeepCopyFcn(cv_DMatch* dst,const cv_DMatch* src){
    cv::DMatch* out = reinterpret_cast<cv::DMatch*>(*dst);
    const cv::DMatch* in  = reinterpret_cast<const cv::DMatch*>(*src);
    return opencv_sim::copy<cv::DMatch>(out,in);
}
int cv_PointDeepCopyFcn(cv_Point* dst,const cv_Point* src){
    cv::Point* out = reinterpret_cast<cv::Point*>(*dst);
    const cv::Point* in  = reinterpret_cast<const cv::Point*>(*src);
    return opencv_sim::copy<cv::Point>(out,in);
}
int cv_Point2fDeepCopyFcn(cv_Point2f* dst,const cv_Point2f* src){
    cv::Point2f* out = reinterpret_cast<cv::Point2f*>(*dst);
    const cv::Point2f* in  = reinterpret_cast<const cv::Point2f*>(*src);
    return opencv_sim::copy<cv::Point2f>(out,in);
}
int cv_Point2dDeepCopyFcn(cv_Point2d* dst,const cv_Point2d* src){
    cv::Point2d* out = reinterpret_cast<cv::Point2d*>(*dst);
    const cv::Point2d* in  = reinterpret_cast<const cv::Point2d*>(*src);
    return opencv_sim::copy<cv::Point2d>(out,in);
}
int cv_Point3iDeepCopyFcn(cv_Point3i* dst,const cv_Point3i* src){
    cv::Point3i* out = reinterpret_cast<cv::Point3i*>(*dst);
    const cv::Point3i* in  = reinterpret_cast<const cv::Point3i*>(*src);
    return opencv_sim::copy<cv::Point3i>(out,in);
}
int cv_Point3fDeepCopyFcn(cv_Point3f* dst,const cv_Point3f* src){
    cv::Point3f* out = reinterpret_cast<cv::Point3f*>(*dst);
    const cv::Point3f* in  = reinterpret_cast<const cv::Point3f*>(*src);
    return opencv_sim::copy<cv::Point3f>(out,in);
}
int cv_Point3dDeepCopyFcn(cv_Point3d* dst,const cv_Point3d* src){
    cv::Point3d* out = reinterpret_cast<cv::Point3d*>(*dst);
    const cv::Point3d* in  = reinterpret_cast<const cv::Point3d*>(*src);
    return opencv_sim::copy<cv::Point3d>(out,in);
}
int cv_SizeDeepCopyFcn(cv_Size* dst,const cv_Size* src){
    cv::Size* out = reinterpret_cast<cv::Size*>(*dst);
    const cv::Size* in  = reinterpret_cast<const cv::Size*>(*src);
    return opencv_sim::copy<cv::Size>(out,in);
}
int cv_ScalarDeepCopyFcn(cv_Scalar* dst,const cv_Scalar* src){
    cv::Scalar* out = reinterpret_cast<cv::Scalar*>(*dst);
    const cv::Scalar* in  = reinterpret_cast<const cv::Scalar*>(*src);
    return opencv_sim::copy<cv::Scalar>(out,in);
}
int cv_RangeDeepCopyFcn(cv_Range* dst,const cv_Range* src){
    cv::Range* out = reinterpret_cast<cv::Range*>(*dst);
    const cv::Range* in  = reinterpret_cast<const cv::Range*>(*src);
    return opencv_sim::copy<cv::Range>(out,in);
}
int cv_TermCriteriaDeepCopyFcn(cv_TermCriteria* dst,const cv_TermCriteria* src){
    cv::TermCriteria* out = reinterpret_cast<cv::TermCriteria*>(*dst);
    const cv::TermCriteria* in  = reinterpret_cast<const cv::TermCriteria*>(*src);
    return opencv_sim::copy<cv::TermCriteria>(out,in);
}
int vector_cv_RectDeepCopyFcn(vector_cv_Rect* dst,const vector_cv_Rect* src){
    std::vector<cv::Rect>* out = reinterpret_cast<std::vector<cv::Rect>*>(*dst);
    const std::vector<cv::Rect>* in  = reinterpret_cast<const std::vector<cv::Rect>*>(*src);
    return opencv_sim::copy<std::vector<cv::Rect>>(out,in);
}
int vector_cv_RotatedRectDeepCopyFcn(vector_cv_RotatedRect* dst,const vector_cv_RotatedRect* src){
    std::vector<cv::RotatedRect>* out = reinterpret_cast<std::vector<cv::RotatedRect>*>(*dst);
    const std::vector<cv::RotatedRect>* in  = reinterpret_cast<const std::vector<cv::RotatedRect>*>(*src);
    return opencv_sim::copy<std::vector<cv::RotatedRect>>(out,in);
}
int vector_cv_KeyPointDeepCopyFcn(vector_cv_KeyPoint* dst,const vector_cv_KeyPoint* src){
    std::vector<cv::KeyPoint>* out = reinterpret_cast<std::vector<cv::KeyPoint>*>(*dst);
    const std::vector<cv::KeyPoint>* in  = reinterpret_cast<const std::vector<cv::KeyPoint>*>(*src);
    return opencv_sim::copy<std::vector<cv::KeyPoint>>(out,in);
}
int vector_cv_PointDeepCopyFcn(vector_cv_Point* dst,const vector_cv_Point* src){
    std::vector<cv::Point>* out = reinterpret_cast<std::vector<cv::Point>*>(*dst);
    const std::vector<cv::Point>* in  = reinterpret_cast<const std::vector<cv::Point>*>(*src);
    return opencv_sim::copy<std::vector<cv::Point>>(out,in);
}
int vector_cv_Point2fDeepCopyFcn(vector_cv_Point2f* dst,const vector_cv_Point2f* src){
    std::vector<cv::Point2f>* out = reinterpret_cast<std::vector<cv::Point2f>*>(*dst);
    const std::vector<cv::Point2f>* in  = reinterpret_cast<const std::vector<cv::Point2f>*>(*src);
    return opencv_sim::copy<std::vector<cv::Point2f>>(out,in);
}
int vector_cv_Point2dDeepCopyFcn(vector_cv_Point2d* dst,const vector_cv_Point2d* src){
    std::vector<cv::Point2d>* out = reinterpret_cast<std::vector<cv::Point2d>*>(*dst);
    const std::vector<cv::Point2d>* in  = reinterpret_cast<const std::vector<cv::Point2d>*>(*src);
    return opencv_sim::copy<std::vector<cv::Point2d>>(out,in);
}
int vector_cv_Point3iDeepCopyFcn(vector_cv_Point3i* dst,const vector_cv_Point3i* src){
    std::vector<cv::Point3i>* out = reinterpret_cast<std::vector<cv::Point3i>*>(*dst);
    const std::vector<cv::Point3i>* in  = reinterpret_cast<const std::vector<cv::Point3i>*>(*src);
    return opencv_sim::copy<std::vector<cv::Point3i>>(out,in);
}
int vector_cv_Point3fDeepCopyFcn(vector_cv_Point3f* dst,const vector_cv_Point3f* src){
    std::vector<cv::Point3f>* out = reinterpret_cast<std::vector<cv::Point3f>*>(*dst);
    const std::vector<cv::Point3f>* in  = reinterpret_cast<const std::vector<cv::Point3f>*>(*src);
    return opencv_sim::copy<std::vector<cv::Point3f>>(out,in);
}
int vector_cv_Point3dDeepCopyFcn(vector_cv_Point3d* dst,const vector_cv_Point3d* src){
    std::vector<cv::Point3d>* out = reinterpret_cast<std::vector<cv::Point3d>*>(*dst);
    const std::vector<cv::Point3d>* in  = reinterpret_cast<const std::vector<cv::Point3d>*>(*src);
    return opencv_sim::copy<std::vector<cv::Point3d>>(out,in);
}
int vector_cv_DMatchDeepCopyFcn(vector_cv_DMatch* dst,const vector_cv_DMatch* src){
    std::vector<cv::DMatch>* out = reinterpret_cast<std::vector<cv::DMatch>*>(*dst);
    const std::vector<cv::DMatch>* in  = reinterpret_cast<const std::vector<cv::DMatch>*>(*src);
    return opencv_sim::copy<std::vector<cv::DMatch>>(out,in);
}
int vector_vector_cv_PointDeepCopyFcn(vector_vector_cv_Point* dst,const vector_vector_cv_Point* src){
    std::vector<std::vector<cv::Point> >* out = reinterpret_cast<std::vector<std::vector<cv::Point> >*>(*dst);
    const std::vector<std::vector<cv::Point> >* in  = reinterpret_cast<const std::vector<std::vector<cv::Point> >*>(*src);
    return opencv_sim::copy<std::vector<std::vector<cv::Point> >>(out,in);
}
int vector_vector_cv_Point2fDeepCopyFcn(vector_vector_cv_Point2f* dst,const vector_vector_cv_Point2f* src){
    std::vector<std::vector<cv::Point2f> >* out = reinterpret_cast<std::vector<std::vector<cv::Point2f> >*>(*dst);
    const std::vector<std::vector<cv::Point2f> >* in  = reinterpret_cast<const std::vector<std::vector<cv::Point2f> >*>(*src);
    return opencv_sim::copy<std::vector<std::vector<cv::Point2f> >>(out,in);
}
int vector_vector_cv_Point2dDeepCopyFcn(vector_vector_cv_Point2d* dst,const vector_vector_cv_Point2d* src){
    std::vector<std::vector<cv::Point2d> >* out = reinterpret_cast<std::vector<std::vector<cv::Point2d> >*>(*dst);
    const std::vector<std::vector<cv::Point2d> >* in  = reinterpret_cast<const std::vector<std::vector<cv::Point2d> >*>(*src);
    return opencv_sim::copy<std::vector<std::vector<cv::Point2d> >>(out,in);
}
int vector_vector_cv_Point3iDeepCopyFcn(vector_vector_cv_Point3i* dst,const vector_vector_cv_Point3i* src){
    std::vector<std::vector<cv::Point3i> >* out = reinterpret_cast<std::vector<std::vector<cv::Point3i> >*>(*dst);
    const std::vector<std::vector<cv::Point3i> >* in  = reinterpret_cast<const std::vector<std::vector<cv::Point3i> >*>(*src);
    return opencv_sim::copy<std::vector<std::vector<cv::Point3i> >>(out,in);
}
int vector_vector_cv_Point3fDeepCopyFcn(vector_vector_cv_Point3f* dst,const vector_vector_cv_Point3f* src){
    std::vector<std::vector<cv::Point3f> >* out = reinterpret_cast<std::vector<std::vector<cv::Point3f> >*>(*dst);
    const std::vector<std::vector<cv::Point3f> >* in  = reinterpret_cast<const std::vector<std::vector<cv::Point3f> >*>(*src);
    return opencv_sim::copy<std::vector<std::vector<cv::Point3f> >>(out,in);
}
int vector_vector_cv_Point3dDeepCopyFcn(vector_vector_cv_Point3d* dst,const vector_vector_cv_Point3d* src){
    std::vector<std::vector<cv::Point3d> >* out = reinterpret_cast<std::vector<std::vector<cv::Point3d> >*>(*dst);
    const std::vector<std::vector<cv::Point3d> >* in  = reinterpret_cast<const std::vector<std::vector<cv::Point3d> >*>(*src);
    return opencv_sim::copy<std::vector<std::vector<cv::Point3d> >>(out,in);
}
int vector_vector_cv_DMatchDeepCopyFcn(vector_vector_cv_DMatch* dst,const vector_vector_cv_DMatch* src){
    std::vector<std::vector<cv::DMatch> >        * out = reinterpret_cast<std::vector<std::vector<cv::DMatch> >        *>(*dst);
    const std::vector<std::vector<cv::DMatch> >        * in  = reinterpret_cast<const std::vector<std::vector<cv::DMatch> >        *>(*src);
    return opencv_sim::copy<std::vector<std::vector<cv::DMatch> >        >(out,in);
}
#ifdef __cplusplus
    }
#endif
