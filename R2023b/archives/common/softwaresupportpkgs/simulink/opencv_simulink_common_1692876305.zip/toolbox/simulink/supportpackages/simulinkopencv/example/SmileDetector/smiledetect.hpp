#include "opencv2/objdetect.hpp"
#include "opencv2/imgproc.hpp"
#include <iostream>
using namespace std;
using namespace cv;
void detectAndDraw( Mat& inImage, Mat &outImage, double *intensity, int *x, int *y, int *radius);

