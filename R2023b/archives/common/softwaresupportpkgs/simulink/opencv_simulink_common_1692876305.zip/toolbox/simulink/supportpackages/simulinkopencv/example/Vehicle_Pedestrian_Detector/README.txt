Vehicle and Pedestrian Detector Example Instructions
===================================
Dependencies
---------------------
Pre-trained model : pedestrian_detector.yml and vehicle_detector.yml required
Input video : input.mp4

---------------------
drawDetect

img - Input Image in the cv::Mat format
out - Output Image in the cv::Mat format

Usage Instructions
---------------------
1. Copy the contents of this folder to a writable directory and set that folder as the current folder.
   Additional files will be generated in the folder.
2. Import the "vehiclePedestrianDetector.cpp" and "vehiclePedestrianDetector.hpp" using OpenCV Importer app.
3. Select the function "drawDetect" in the listed functions.
4. Set "img" as "Input" and the "out" as "Output" in the drop-down of I/O Type.
5. Select the checkbox to use "Simulink.ImageType".
   Also, set the default "Color Format" to "RGB" and "Array Layout" to "Column-major".
6. Once the library is created, to simulate the model, drag the generated subsystem to "VehiclePedestrianDetector.slx" and connect to the blocks.
7. Double click the subsystem block and make sure the subsystem's mask parameters matches with input port's properties:
   Rows = 180, Columns = 320, and Channels = 3