#pragma once

#include <opencv2/core.hpp>

void cartoonize(cv::Mat& inImage, cv::Mat& outImage, int maskRadius, float threshold, float ramp);