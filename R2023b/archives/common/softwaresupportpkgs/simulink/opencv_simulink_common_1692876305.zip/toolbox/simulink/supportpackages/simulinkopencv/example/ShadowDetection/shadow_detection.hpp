#pragma once
#include <opencv2/imgproc.hpp>
#include <opencv2/core.hpp>
void run_shadow_detection(cv::Mat& inImage, cv::Mat &outImage, double thresh);