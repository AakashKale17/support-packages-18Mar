Smile Detector Example Instructions
===================================
smiledetect.hpp
---------------------
detectAndDraw 

inImage   - Input Image in the cv::Mat format
outImage  - Output Image in the cv::Mat format
intensity - Intensity of the smile mapped between 0 and 1
x         - x coordinate of the center of the circle containing the face(s)
y         - y coordinate of the center of the circle containing the face(s)
radius    - Radius of the circle containing the face(s)


Usage Instructions
---------------------
1. Copy the contents of this folder to a writable directory.
   And set that folder as the current folder. Additional files will be generated in the folder.
2. Import the "smiledetect.cpp" and "smiledetect.hpp" using OpenCVImporter app.
3. Select the function "detectAndDraw" in the listed functions.
4. Set "inImage" as "Input" and the rest as "Output" in the drop-down of I/O Type.
5. Select the checkbox to use "Simulink.ImageType".
   Also, set the default "Color Format" to "RGB" and "Array Layout" to "Column-major".
6. Once the library is created, to simulate the model, drag the generated subsystem to "smileDetect.slx" and connect to the blocks.
7. Double click the subsystem block and make sure the subsystem's mask parameters matches with input port's properties:
   Rows = 480, Columns = 640, and Channels = 3
8. To generate C++ code and deploy on the Raspberry Pi hardware, you can either use the generated subsystem or the C-caller block.
                Case 1 - With subsystem:
                                a. Copy the generated subsystem to the model "smileDetect_codegen.slx" and make the connections. 
                                b. Hardware Device Vendor : ARM Compatible.
                                c. Toolchain: GNU GCC Raspberry Pi.
                                d. Add Include directories and libraries for location on Raspberry Pi.                        
                                e. Specify the size of incoming image in the input port. 
                                f. Generate Code Only and Package the code

                Case 2 - With C-Caller:
                                a. Copy the generated subsystem to the model "smileDetect_codegen.slx" and make the connections. 
                                b. Hardware Device Vendor – ARM Compatible.
                                c. Toolchain: GNU GCC Raspberry Pi.
                                d. Add Include directories and libraries for location on Raspberry Pi.                          
                                e. Mark input ports with size of incoming image. 
                                f. Generate Code Only and Package the code.

Note: Case 2 is optimal as there is no unnecessary conversion involved to and from OpenCV code.