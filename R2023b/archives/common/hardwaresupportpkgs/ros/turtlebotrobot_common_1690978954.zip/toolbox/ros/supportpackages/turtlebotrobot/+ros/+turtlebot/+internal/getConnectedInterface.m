function [tbotInterface, isDefault] = getConnectedInterface(node)
%getConnectedInterface Returns the appropriate TurtleBot interface for the connected ROS network
%   TBOTINTERFACE = getConnectedInterface(NODE) probes the ROS network
%   connected to the ROS node, NODE, and determines which TurtleBot instance
%   is connected. TBOTINTERFACE is an object of type
%   ros.turtlebot.internal.TurtleBotTopicInterface
%
%   [TBOTINTERFACE, ISDEFAULT] = getConnectedInterface(NODE) also returns
%   information about the selection process. If ISDEFAULT is TRUE, no
%   appropriate interface was determined and the default interface was
%   returned. If there was a unique interface match, ISDEFAULT is FALSE.
%
%   The function will return [] if no appropriate interface can be
%   determined.

%   Copyright 2015-2018 The MathWorks, Inc.

    validateattributes(node, {'ros.Node'}, {'scalar'}, 'isInterfaceConnected', 'node');

    isDefault = false;

    % Check if it is a physical TurtleBot
    if ros.turtlebot.internal.TurtleBotPhysicalInterface.isInterfaceConnected(node)
        tbotInterface = ros.turtlebot.internal.TurtleBotPhysicalInterface;
        return;
    end

    % Check if it is a simulated TurtleBot in Gazebo
    if ros.turtlebot.internal.TurtleBotGazeboInterface.isInterfaceConnected(node)
        tbotInterface = ros.turtlebot.internal.TurtleBotGazeboInterface;
        return;
    end

    % No appropriate interface could be determined. Return the default one
    % (physical TurtleBot).
    isDefault = true;
    tbotInterface = ros.turtlebot.internal.TurtleBotPhysicalInterface;

end
