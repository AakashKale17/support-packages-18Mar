classdef turtlebot < ...
        robotics.core.internal.mixin.Unsaveable & ...
        handle
    %TURTLEBOT Interface with TurtleBot robots
    %   Use this object to communicate with a simulated or physical TurtleBot.
    %   You can read sensor data, send velocity control commands, and
    %   extract transformations.
    %
    %   When constructing the object, you need to specify the address of the ROS
    %   master running on the TurtleBot.
    %
    %   TBOT = TURTLEBOT creates a TurtleBot interface object, TBOT. MATLAB
    %   connects to the TurtleBot ROS master running on the same machine,
    %   unless the TurtleBot location is specified by the ROS_MASTER_URI
    %   environment variable.
    %
    %   TBOT = TURTLEBOT('HOST') connects to the TurtleBot ROS master at IP address
    %   or  hostname HOST. This syntax assumes that the master is running on the
    %   ROS default port number 11311.
    %
    %   TBOT = TURTLEBOT('HOST', PORT) connects to the TurtleBot ROS master at
    %   specified port number PORT.
    %
    %   TBOT = TURTLEBOT('URI') connects to the TurtleBot at the given URI
    %   (Uniform Resource Identifier).
    %
    %   TBOT = TURTLEBOT(___, Name, Value) provides additional options
    %   specified by one or more Name,Value pair arguments:
    %
    %      'NodeHost'     -   specifies the IP address or hostname under
    %                         which the node advertises itself to the
    %                         ROS network, e.g. '192.168.1.1' or
    %                         'comp-home'
    %
    %
    %   TURTLEBOT properties:
    %      Velocity        - Capability for moving the TurtleBot
    %      ColorImage      - Color image capability
    %      GrayImage       - Grayscale image capability
    %      DepthImage      - Depth image capability
    %      PointCloud      - Point cloud capability
    %      LaserScan       - Laser scan capability
    %      Odometry        - Odometry capability
    %      OdometryReset   - Capability allowing reset of odometry
    %      IMU             - Inertial Measurement Unit (IMU) capability
    %      TransformFrames - Available transform frame names on TurtleBot (Read-only)
    %      TopicNames      - Available topic names on TurtleBot (Read-only)
    %
    %   TURTLEBOT methods:
    %      getColorImage - Get color image from the camera
    %      getDepthImage - Get depth image from the camera
    %      getGrayImage  - Get grayscale image from the camera
    %      getIMU        - Get IMU data
    %      getLaserScan  - Get laser scan
    %      getOdometry   - Get odometry reading
    %      getPointCloud - Get point cloud from depth camera
    %      getTransform  - Get transformation between two frames
    %      resetOdometry - Reset odometry
    %      setVelocity   - Set linear and angular velocities
    %
    %
    %   Example:
    %      % Connect to TurtleBot at IP address 192.168.2.112
    %      tbot = turtlebot('192.168.2.112')
    %
    %      % Get current robot pose
    %      pose = getOdometry(tbot)
    %
    %      % Explicitly enable the color image subscriber
    %      % Note that this also happens automatically when you first call
    %      % getColorImage
    %      tbot.ColorImage.Active = true;
    %
    %      % Show color image from camera
    %      colorImg = getColorImage(tbot);
    %      figure;
    %      imshow(colorImg);
    %
    %      % Disable the color image subscriber to save network bandwidth
    %      tbot.ColorImage.Active = false;
    %
    %      % Move robot forward at 0.3 m/s
    %      setVelocity(tbot, 0.3);
    %
    %      % Get updated robot pose
    %      pose = getOdometry(tbot)
    %
    %      % Move in a circle for 10 seconds
    %      setVelocity(tbot, 0.5, 0.8, 'Time', 10);

    %   Copyright 2015-2020 The MathWorks, Inc.

    % Okay to use property access in non-dependent setters, since this
    % object does not support save/load.
    %#ok<*MCSUP>

    %% Properties representing TurtleBot capabilities
    properties
        %Velocity - Enable velocity commands
        Velocity

        %ColorImage - Enable color images
        ColorImage

        %GrayImage - Enable grayscale images
        GrayImage

        %DepthImage - Enable depth images
        DepthImage

        %PointCloud - Enable point clouds
        PointCloud

        %LaserScan - Enable laser scans
        LaserScan

        %Odometry - Enable odometry readings
        Odometry

        %OdometryReset - Enable reset of odometry
        OdometryReset

        %IMU - Enable Inertial Measurement Unit (IMU) readings
        IMU
    end

    properties (Dependent, SetAccess = private)
        %TransformFrames - Available transformation frames on the TurtleBot
        %   The frame names are returned in a cell array of strings.
        TransformFrames

        %TopicNames - All topic names on the TurtleBot
        %   The names are returned in a cell array of strings.
        TopicNames
    end

    %% Internal Properties
    properties (Access = ?matlab.unittest.TestCase)
        %Node - ROS node that connects MATLAB to the TurtleBot's ROS network
        Node

        %InputParser - Helper class to parse inputs to class methods
        InputParser

        %TopicInterface - The topic interface object
        %   It stores the names and message types for the connected
        %   TurtleBot.
        TopicInterface

        %TransformTree - TF transformation tree
        TransformTree

        %ColorImageSubscriber - ROS subscriber for color image
        ColorImageSubscriber

        %GrayImageSubscriber - ROS subscriber for grayscale image
        GrayImageSubscriber

        %DepthImageSubscriber - ROS subscriber for depth image
        DepthImageSubscriber

        %PointCloudSubscriber - ROS subscriber for point cloud
        PointCloudSubscriber

        %OdometrySubscriber - ROS subscriber for odometry
        OdometrySubscriber

        %LaserScanSubscriber - ROS subscriber for laser scan
        LaserScanSubscriber

        %IMUSubscriber - ROS subscriber for IMU
        IMUSubscriber

        %OdometryResetPublisher - ROS publisher for resetting odometry
        OdometryResetPublisher

        %OdometryResetMessage - ROS message for odometry reset
        OdometryResetMessage

        %VelocityPublisher - ROS publisher for velocity
        VelocityPublisher

        %VelocityMessage - ROS message for velocity
        %   This message is assigned when the VelocityPublisher is
        %   initialized.
        VelocityMessage
    end

    properties (Constant, Access = ?matlab.unittest.TestCase)
        %TimeoutDefault - The default timeout for the get* methods (in seconds)
        %   The default timeout is 15 seconds.
        TimeoutDefault = 15

        %VelocityPublishRate - Velocity publishing rate (in Hz) when time is specified in setVelocity
        VelocityPublishRate = 20

        %NodeNamePrefix - The name prefix for this object's ROS node
        %   At construction time, a unique number sequence is added to
        %   the actual node name.
        NodeNamePrefix = '/matlab_turtlebot_'
    end

    %% Constructor
    methods
        function obj = turtlebot(varargin)
        %TURTLEBOT Create a new TurtleBot interface object
        %   Please see the class documentation for more details.
        %
        %   See also turtlebot.

            narginchk(0,4);

            % Register message catalog for support package
            spPkg = ros.turtlebot.internal.SupportPackage;
            matlab.internal.msgcat.setAdditionalResourceLocation(spPkg.InstallDir);

            % Create a unique node name based on the fixed prefix and a
            % time-based 5-digit number
            r = robotics.internal.Random;
            randName = r.timeNumericString(5);
            nodeName = [obj.NodeNamePrefix randName];

            % Construct the MATLAB node for controlling the robot
            try
                obj.Node = ros.Node(nodeName, varargin{:});
            catch ex
                newEx = MException(message('turtlebotrobot:turtlebot:CannotConnect', ex.message));
                newEx.addCause(ex);
                throw(newEx);
            end

            obj.InputParser = ros.turtlebot.internal.InputParser;

            % Construct the tf transformation tree
            obj.TransformTree = ros.TransformationTree(obj.Node);

            % Determine what type of TurtleBot is connected. This gives
            % us information about the default topic names and
            % capabilities.
            [obj.TopicInterface, isDefaultInterface] = ros.turtlebot.internal.getConnectedInterface(obj.Node);
            if isDefaultInterface
                warning(message('turtlebotrobot:turtlebot:CannotDetermineType', obj.Node.MasterURI));
            end

            obj.initializeCapabilityProperties;
        end
    end

    %% Dependent Property Getters
    methods
        function topicNames = get.TopicNames(obj)
        %get.TopicNames Retrieve all published topics from ROS network
            topicNames = ros.internal.NetworkIntrospection.getPublishedTopicNamesTypes(obj.Node.MasterURI);
        end

        function tfFrames = get.TransformFrames(obj)
        %get.TransformFrames Retrieve all available transformation tree frames
            tfFrames = obj.TransformTree.AvailableFrames;
        end
    end

    %% Capability Property Setters
    methods
        function set.Velocity(obj, velStruct)
        %set.Velocity Set the velocity topic name and active/inactive status
            obj.Velocity = obj.processCapabilityProperty(obj.Velocity, 'Velocity', velStruct, @obj.enableVelocity);
        end

        function set.ColorImage(obj, colStruct)
        %set.ColorImage Set color image topic name and active/inactive status
            obj.ColorImage = obj.processCapabilityProperty(obj.ColorImage, 'ColorImage', colStruct, @obj.enableColorImage);
        end

        function set.GrayImage(obj, monoStruct)
        %set.GrayImage Set grayscale image topic name and active/inactive status
            obj.GrayImage = obj.processCapabilityProperty(obj.GrayImage, 'GrayImage', monoStruct, @obj.enableGrayImage);
        end

        function set.DepthImage(obj, depthStruct)
        %set.DepthImage Set depth image topic name and active/inactive status
            obj.DepthImage = obj.processCapabilityProperty(obj.DepthImage, 'DepthImage', depthStruct, @obj.enableDepthImage);
        end

        function set.PointCloud(obj, pcloudStruct)
        %set.PointCloud Set point cloud topic name and active/inactive status
            obj.PointCloud = obj.processCapabilityProperty(obj.PointCloud, 'PointCloud', pcloudStruct, @obj.enablePointCloud);
        end

        function set.Odometry(obj, odomStruct)
        %set.Odometry Set the odometry topic name and active/inactive status
            obj.Odometry = obj.processCapabilityProperty(obj.Odometry, 'Odometry', odomStruct, @obj.enableOdometry);
        end

        function set.OdometryReset(obj, odomResetStruct)
        %set.OdometryReset Set the odometry reset topic name and active/inactive status
            obj.OdometryReset = obj.processCapabilityProperty(obj.OdometryReset, 'OdometryReset', odomResetStruct, @obj.enableOdometryReset);
        end

        function set.LaserScan(obj, laserStruct)
        %set.LaserScan Set the laser scan topic name and active/inactive status
            obj.LaserScan = obj.processCapabilityProperty(obj.LaserScan, 'LaserScan', laserStruct, @obj.enableLaserScan);
        end

        function set.IMU(obj, imuStruct)
        %set.IMU Set the IMU topic name and active/inactive status
            obj.IMU = obj.processCapabilityProperty(obj.IMU, 'IMU', imuStruct, @obj.enableIMU);
        end
    end

    %% Property setters
    methods
        function set.InputParser(obj, parserObj)
        %set.InputParser Set input parser object
            validateattributes(parserObj, {'ros.turtlebot.internal.InputParser'}, {'scalar'});
            obj.InputParser = parserObj;
        end
    end

    %% Methods for receiving sensor data from TurtleBot
    methods
        function [colorImg,colorImgMsg] = getColorImage(obj,varargin)
        %getColorImage Get color image from the TurtleBot camera
        %   COLORIMG = getColorImage(TBOT) waits for the next published
        %   color image from the TurtleBot connected through TBOT and
        %   returns it in COLORIMG.
        %   COLORIMG is a HxWx3 matrix, representing an RGB image with
        %   height H and width W. If no image is received in 5 seconds,
        %   an error is displayed.
        %
        %   [COLORIMG, COLORIMGMSG] = getColorImage(TBOT) also returns
        %   the received ROS image message. If no image is received in
        %   5 seconds, an error is displayed.
        %
        %   ____ = getColorImage(TBOT, TIMEOUT) allows
        %   you to specify a TIMEOUT (in seconds). If no new color image
        %   is received within TIMEOUT seconds, the function displays
        %   an error.
        %   A TIMEOUT of 0 returns the latest received message,
        %   without waiting for a new one. If no message has been
        %   received yet, the function returns empty for
        %   COLORIMG and COLORIMGMSG.
        %
        %
        %   Example:
        %      % Connect to TurtleBot at IP address 192.168.2.112
        %      tbot = turtlebot('192.168.2.112')
        %
        %      % Get color image
        %      colorImg = getColorImage(tbot);
        %
        %      % Display color image
        %      figure;
        %      imshow(colorImg);

            narginchk(1,2);
            [colorImg, colorImgMsg] = obj.getROSMessageData('ColorImage', @obj.readImageData, varargin{:});
        end

        function [depthImg,depthImgMsg] = getDepthImage(obj,varargin)
        %getDepthImage Get depth image from the TurtleBot's 3D camera
        %   DEPTHIMG = getDepthImage(TBOT) waits for the next published
        %   depth image from the TurtleBot connected through TBOT
        %   and returns it in DEPTHIMG.
        %   DEPTHIMG is a HxWx1 matrix, representing an floating-point
        %   depth image with height H and width W. If no image is received
        %   in 5 seconds, an error is displayed.
        %
        %   [DEPTHIMG, DEPTHIMGMSG] = getColorImage(TBOT) also returns
        %   the received ROS image message. If no image is received in
        %   5 seconds, an error is displayed.
        %
        %   ____ = getDepthImage(TBOT, TIMEOUT) allows
        %   you to specify a TIMEOUT (in seconds). If no new depth image
        %   is received within TIMEOUT seconds, the function displays
        %   an error.
        %   A TIMEOUT of 0 returns the latest received message,
        %   without waiting for a new one. If no message has been
        %   received yet, the function returns empty for
        %   DEPTHIMG and DEPTHIMGMSG.

            narginchk(1,2);
            [depthImg, depthImgMsg] = obj.getROSMessageData('DepthImage', @obj.readImageData, varargin{:});
        end

        function [pcloud,pcloudMsg] = getPointCloud(obj,varargin)
        %getPointCloud Get point cloud data from the TurtleBot's 3D camera
        %   PCLOUD = getPointCloud(TBOT) waits for the next published point cloud
        %   from the TurtleBot connected through TBOT and returns it in PCLOUD.
        %   PCLOUD is a structure containing the following fields:
        %   - XYZ - The (x,y,z) coordinates of all N points in the point cloud
        %        XYZ is an Nx3 matrix of 3D point coordinates. Each row
        %        represents one 3D point.
        %   - RGB - The (r,g,b) color values for all N points in the point cloud
        %        RGB is an Nx3 matrix of (r,g,b) tuples with each row
        %        corresponding to the point in the same row in XYZ. Each RGB
        %        value is represented as a double in the range of [0,1]. RGB
        %        is [] if the point cloud does not contain any color information.
        %   If no point cloud is received in 5 seconds, an error is displayed.
        %
        %   [PCLOUD, PCLOUDMSG] = getPointCloud(TBOT) also returns
        %   the received ROS point cloud message. If no point cloud is received in
        %   5 seconds, an error is displayed.
        %
        %   ____ = getPointCloud(TBOT, TIMEOUT) allows
        %   you to specify a TIMEOUT (in seconds). If no new point cloud
        %   is received within TIMEOUT seconds, the function displays an error.
        %   A TIMEOUT of 0 returns the latest received message, without waiting
        %   for a new one. If no message has been received yet, the function
        %   returns empty for PCLOUD and PCLOUDMSG.

            narginchk(1,2);
            [pcloud,pcloudMsg] = obj.getROSMessageData('PointCloud', @obj.readPointCloudData, varargin{:});
        end

        function [grayImg,grayImgMsg] = getGrayImage(obj,varargin)
        %getGrayImage Get grayscale image from the TurtleBot camera
        %   GRAYIMG = getGrayImage(TBOT) waits for the next published
        %   grayscale image from the TurtleBot connected through TBOT
        %   and returns it in GRAYIMG.
        %   GRAYIMG is a HxWx1 matrix, representing a grayscale image
        %   with height H and width W. If no image is received
        %   in 5 seconds, an error is displayed.
        %
        %   [GRAYIMG, GRAYIMGMSG] = getGrayImage(TBOT) also returns
        %   the received ROS image message. If no image is received in
        %   5 seconds, an error is displayed.
        %
        %   ____ = getGrayImage(TBOT, TIMEOUT) allows
        %   you to specify a TIMEOUT (in seconds). If no new grayscale image
        %   is received within TIMEOUT seconds, the function displays an error.
        %   A TIMEOUT of 0 returns the latest received message, without waiting
        %   for a new one. If no message has been received yet, the function
        %   returns empty for GRAYIMG and GRAYIMGMSG.
        %
        %   Note that the grayscale image is only published by the physical
        %   TurtleBot robot.
        %
        %
        %   Example:
        %      % Connect to TurtleBot at IP address 192.168.2.112
        %      tbot = turtlebot('192.168.2.112')
        %
        %      % Get grayscale image
        %      grayImg = getGrayImage(tbot);
        %
        %      % Display grayscale image
        %      figure;
        %      imshow(grayImg);

            narginchk(1,2);
            [grayImg,grayImgMsg] = obj.getROSMessageData('GrayImage', @obj.readImageData, varargin{:});
        end

        function [odom,odomMsg] = getOdometry(obj,varargin)
        %getOdometry Get odometry reading from the TurtleBot
        %   ODOM = getOdometry(TBOT) waits for the next published odometry
        %   reading from the TurtleBot connected through TBOT and returns it in ODOM.
        %   ODOM is a structure containing the following fields:
        %   - Position - A row vector containing the 3D position
        %        estimate of the TurtleBot odometry (x,y,z).
        %   - Orientation - A row vector containing the 3D orientation
        %        estimate of the TurtleBot odometry. The orientation is
        %        return in (yaw, pitch, roll) form, with angles in radians.
        %   If no odometry data is received in 5 seconds, an error is displayed.
        %
        %   [ODOM, ODOMMSG] = getOdometry(TBOT) also returns
        %   the received ROS odometry message. If no odometry data is
        %   received in 5 seconds, an error is displayed.
        %
        %   ____ = getOdometry(TBOT, TIMEOUT) allows
        %   you to specify a TIMEOUT (in seconds). If no new odometry data
        %   is received within TIMEOUT seconds, the function displays an error.
        %   A TIMEOUT of 0 returns the latest received message, without waiting
        %   for a new one. If no message has been received yet, the function
        %   returns empty for ODOM and ODOMMSG.

            narginchk(1,2);
            [odom,odomMsg] = obj.getROSMessageData('Odometry', @obj.readOdometryData, varargin{:});
        end

        function [scan,scanMsg] = getLaserScan(obj,varargin)
        %getLaserScan Get laser scan from the TurtleBot
        %   SCAN = getLaserScan(TBOT) waits for the next published laser scan
        %   from the TurtleBot connected through TBOT and returns it in SCAN.
        %   SCAN is a structure containing the following fields:
        %   - Ranges - A column vector containing the range distance
        %        readings (in meters) returned by the laser scanner.
        %   - Angles - A column vector of the scan angles at which the
        %        'Ranges' were measured. The angles are measured
        %        counter-clockwise around the positive z axis, with the
        %        zero angle forward along the x axis. The
        %        angles are returned in radians.
        %   The 'Ranges' and 'Angles' vectors always have the same
        %   length, with corresponding rows.
        %   If no laser scan is received in 5 seconds, an error is displayed.
        %
        %   [SCAN, SCANMSG] = getLaserScan(TBOT) also returns
        %   the received ROS laser scan message. If no laser scan is
        %   received in 5 seconds, an error is displayed.
        %
        %   ____ = getLaserScan(TBOT, TIMEOUT) allows
        %   you to specify a TIMEOUT (in seconds). If no new laser scan
        %   is received within TIMEOUT seconds, the function displays an error.
        %   A TIMEOUT of 0 returns the latest received message, without waiting
        %   for a new one. If no message has been received yet, the function
        %   returns empty for SCAN and SCANMSG.
        %
        %   Note that the laser scan is extracted from the data of the
        %   TurtleBot's 3D depth camera.

            narginchk(1,2);
            [scan,scanMsg] = obj.getROSMessageData('LaserScan', @obj.readLaserScanData, varargin{:});
        end

        function [imu,imuMsg] = getIMU(obj,varargin)
        %getIMU Get IMU data from the TurtleBot
        %   IMUDATA = getIMU(TBOT) waits for the next published IMU reading
        %   from the TurtleBot connected through TBOT and returns it in IMUDATA.
        %   IMUDATA is a structure containing the following fields:
        %   - Orientation - A row vector containing the 3D orientation
        %        estimate of the TurtleBot based on IMU data. The orientation
        %        is returned in (yaw, pitch, roll) form, with angles in radians.
        %   If no IMU data is received in 5 seconds, an error is displayed.
        %
        %   [IMUDATA, IMUMSG] = getIMU(TBOT) also returns
        %   the received ROS IMU message. If no IMU data is
        %   received in 5 seconds, an error is displayed.
        %
        %   ____ = getIMU(TBOT, TIMEOUT) allows
        %   you to specify a TIMEOUT (in seconds). If no new IMU data
        %   is received within TIMEOUT seconds, the function displays an error.
        %   A TIMEOUT of 0 returns the latest received message, without waiting
        %   for a new one. If no message has been received yet, the function
        %   returns empty for IMUDATA and IMUMSG.
        %
        %   Note that the IMU data is only published by the physical
        %   TurtleBot robot.

            narginchk(1,2);
            [imu,imuMsg] = obj.getROSMessageData('IMU', @obj.readIMUData, varargin{:});
        end

        function [tf,tfMsg] = getTransform(obj, targetFrame, sourceFrame)
        %getTransform Get transformation between two frames on the TurtleBot
        %   TF = getTransform(TBOT, 'TARGETFRAME', 'SOURCEFRAME')
        %   returns the latest known transformation between two
        %   coordinate frames on the TurtleBot connected through TBOT.
        %   TF represents the transformation that takes coordinates
        %   in the SOURCEFRAME into the corresponding coordinates in
        %   the TARGETFRAME. If the transformation does not exist,
        %   an error is displayed.
        %   TF is a structure containing the following fields:
        %   - Translation - A row vector containing the 3D translation
        %        between the source and target frames. The vector is of
        %        the form (x,y,z).
        %   - Rotation - A row vector containing the 3D orientation
        %        between the source and target frames. The rotation is
        %        return in (yaw, pitch, roll) form, with angles in radians.
        %
        %   [TF, TFMSG] = getTransform(TBOT, 'TARGETFRAME', 'SOURCEFRAME')
        %   also returns the associated ROS TransformStamped message,
        %   TFMSG.

        % Check inputs
            validateattributes(targetFrame,{'char'},{'row'},'getTransform','target');
            validateattributes(sourceFrame,{'char'},{'row'},'getTransform','source');

            % Get the transform using the internal TF tree
            tfMsg = obj.TransformTree.getTransform(targetFrame,sourceFrame);
            if isempty(tfMsg)
                error(message('turtlebotrobot:turtlebot:NoTransform', targetFrame, sourceFrame));
            end

            tf = obj.readTransformData(tfMsg);
        end
    end

    %% Methods for sending commands to TurtleBot
    methods
        function setVelocity(obj, varargin)
        %setVelocity Command linear and angular velocity for the TurtleBot
        %   setVelocity(TBOT, LINEARVEL) sends a linear velocity command,
        %   LINEARVEL, to the TurtleBot connected through TB.
        %   LINEARVEL is a scalar specified in meters per second.
        %   It assumes an angular velocity of zero. Only a single velocity
        %   command is sent to the TurtleBot. The robot will move at this
        %   velocity for a fixed period of time (hardware-dependent),
        %   then stop.
        %
        %   setVelocity(TBOT, LINEARVEL, ANGULARVEL) also sends an angular
        %   velocity command, ANGULARVEL, to the TurtleBot. ANGULARVEL
        %   is a scalar number and specified in radians per second.
        %
        %   setVelocity(TBOT, TWISTMSG) sends a Twist ROS message to the
        %   TurtleBot. TWISTMSG is a ROS message object of type
        %   'geometry_msgs/Twist' and contains linear and angular
        %   velocity commands.
        %
        %   setVelocity(___, Name, Value) provides additional options
        %   specified by one or more Name,Value pair arguments:
        %
        %      'Time' -  The velocity command is sent repeatedly to the
        %                TurtleBot during this time period (in seconds).
        %                The publish frequency is 20 Hz. The Value
        %                needs to be a positive scalar number and
        %                MATLAB is blocked until this time elapses. The
        %                TurtleBot will move at the commanded velocity
        %                for at least the specified time period. At the end
        %                of the elapsed time, a velocity of 0 is sent to the
        %                robot.
        %
        %
        %   Example:
        %      % Connect to TurtleBot at IP address 192.168.2.112
        %      tbot = turtlebot('192.168.2.112')
        %
        %      % Move robot forward at 0.5 m/s
        %      setVelocity(tbot, 0.5);
        %
        %      % Move in a circle for 10 seconds
        %      setVelocity(tbot, 0.5, 0.8, 'Time', 10);

        % If necessary, enable velocity publisher
            if isempty(obj.VelocityPublisher)
                obj.Velocity.Active = 1;
            end

            % Default values
            defaultInputs = struct('LinearVel', 0, 'AngularVel', 0, 'Time', 0, ...
                                   'ROSMessage', []);

            % Parse inputs to method
            parsedInputs = obj.InputParser.parseSetVelocityInputs(defaultInputs, varargin{:});

            % Populate twist message that is sent to TurtleBot
            if ~isempty(parsedInputs.ROSMessage)
                obj.VelocityMessage = parsedInputs.ROSMessage;
            else
                obj.VelocityMessage.Linear.X = parsedInputs.LinearVel;
                obj.VelocityMessage.Angular.Z = parsedInputs.AngularVel;
            end

            % If no time is specified, only send once and return
            if parsedInputs.Time == 0
                send(obj.VelocityPublisher, obj.VelocityMessage);
                return;
            end

            % A time was specified by the user. Send message repeatedly at
            % about 20 Hz.
            rate = rateControl(obj.VelocityPublishRate);
            rate.reset;
            while rate.TotalElapsedTime < parsedInputs.Time
                send(obj.VelocityPublisher,obj.VelocityMessage);
                waitfor(rate);
            end

            % Stop robot by setting linear and angular velocities to 0
            obj.VelocityMessage.Linear.X = 0;
            obj.VelocityMessage.Angular.Z = 0;
            send(obj.VelocityPublisher, obj.VelocityMessage);
        end

        function resetOdometry(obj)
        %resetOdometry Reset the odometry for the TurtleBot
        %   resetOdometry(TBOT) resets the odometry readings that the TurtleBot
        %   connected through TBOT publishes on the /odom topic.
        %   The position is reset to (0,0,0) and the orientation quaternion
        %   is reset to (1,0,0,0).

        % Start up the publisher if necessary
            if isempty(obj.OdometryResetPublisher)
                obj.OdometryReset.Active = 1;
            end

            % Time for OdometryResetPublisher activition
            pause(2);
            % Send message
            send(obj.OdometryResetPublisher, obj.OdometryResetMessage);
        end

        function delete(obj)
        %DELETE Shut down the connection to the TurtleBot
        %   DELETE(TBOT) shuts down the connection to the TurtleBot.
        %   To reconnect to the robot, construct a new TURTLEBOT object.

            if ~isempty(obj.TransformTree)
                obj.TransformTree.delete;
            end

            % Delete the ROS node
            % This will also invalidate all publishers, subscribers, and
            % the transformation tree.
            if ~isempty(obj.Node)
                obj.Node.delete;
            end
        end

    end

    methods (Static, Access = ?matlab.unittest.TestCase)
        function img = readImageData(msg)
        %readImageData Convert an image message from ROS form to MATLAB form

        % Just use existing conversion function
            img = readImage(msg);
        end

        function ptcloud = readPointCloudData(msg)
        %readPointCloudData Convert a point cloud message from ROS form to MATLAB form

        % Use existing conversion functions to build a struct
            ptcloud = struct('RGB', double(turtlebot.safeConversion(msg, @readRGB)), ...
                             'XYZ', double(turtlebot.safeConversion(msg, @readXYZ)));
        end

        function scan = readLaserScanData(msg)
        %readLaserScanData Convert a laser scan message from ROS form to MATLAB form

        % Use existing conversion function to build a struct
            scan = struct('Ranges', double(msg.Ranges), ...
                          'Angles', double(turtlebot.safeConversion(msg, @readScanAngles)));
        end

        function odom = readOdometryData(msg)
        %readOdometryData Convert an odometry message from ROS form to MATLAB form

        % Get position and orientation from ROS message
            pose = msg.Pose.Pose;
            posObject = pose.Position;
            orientObject = pose.Orientation;

            % Convert ROS message objects to vectors
            pos = [posObject.X, posObject.Y, posObject.Z];

            % quat should be [w x y z], eul is [z y x]
            orientation = quat2eul([orientObject.W, orientObject.X, ...
                                orientObject.Y, orientObject.Z], 'ZYX');

            odom = struct('Position', pos, 'Orientation', orientation);
        end

        function imu = readIMUData(msg)
        %readIMUData Convert an IMU message from ROS form to MATLAB form

        % Get orientation out of ROS message
            orientObject = msg.Orientation;
            % quat should be [w x y z], eul is [z y x]
            orientation = quat2eul([orientObject.W, orientObject.X, ...
                                orientObject.Y, orientObject.Z]);

            imu = struct('Orientation', orientation);
        end

        function tfData = readTransformData(msg)
        %readTransformData Convert a transform message from ROS form to MATLAB form

        % Get translation and rotation out of ROS message
            tform = msg.Transform;
            translateObject = tform.Translation;
            rotateObject = tform.Rotation;

            % Convert ROS message objects to vectors
            translate = [translateObject.X, translateObject.Y, translateObject.Z];
            % quat should be [w x y z], eul is [z y x]
            rotate = quat2eul([rotateObject.W, rotateObject.X, ...
                               rotateObject.Y, rotateObject.Z], 'ZYX');

            tfData = struct('Translation', translate, 'Rotation', rotate);
        end

        function mlData = safeConversion(msg, readFcn)
            try
                mlData = readFcn(msg);
            catch
            end
        end
    end

    methods (Access = ?matlab.unittest.TestCase)
        function parsedStruct = processCapabilityProperty(obj, currentPropStruct, propName, inputPropStruct, enableFcn)
        %processCapabilityProperty Check that capability property input is valid
        %   PARSEDSTRUCT = processCapabilityProperty(OBJ, CURRENTPROPSTRUCT, PROPNAME, INPUTPROPSTRUCT, ENABLEFCN)
        %   parses the user-specified INPUTPROPSTRUCT and verifies that
        %   it is a valid value for PROPNAME. CURRENTPROPSTRUCT contains
        %   the current structure assigned to the property. ENABLEFCN will be
        %   executed if the 'Active' field changes value and the new
        %   property value is returned in PARSEDSTRUCT.
        %
        %   Note that it is the caller's responsibility to assign
        %   PARSEDSTRUCT to the associated object property PROPNAME.

        % Parse input
            parsedStruct = obj.InputParser.parseCapabilityProperty(propName, inputPropStruct);

            % Initialize property, if not already done. No more validation needed.
            if isempty(currentPropStruct)
                enableFcn(parsedStruct);
                return;
            end

            % Only allow topic name changes if the capability is not active
            if ~strcmp(parsedStruct.TopicName, currentPropStruct.TopicName)
                if currentPropStruct.Active
                    error(message('turtlebotrobot:turtlebot:TopicIsLocked', propName));
                end
            end

            % Enable/disable capability if required
            if parsedStruct.Active ~= currentPropStruct.Active
                enableFcn(parsedStruct);
            end
        end

        function initializeCapabilityProperties(obj)
        %initializeCapabilityProperties Create all capability properties

            obj.Velocity = obj.createCapabilityProperty('Velocity', false);
            obj.Odometry = obj.createCapabilityProperty('Odometry', false);
            obj.OdometryReset = obj.createCapabilityProperty('OdometryReset', false);
            obj.LaserScan = obj.createCapabilityProperty('LaserScan', false);
            obj.ColorImage = obj.createCapabilityProperty('ColorImage', false);
            obj.GrayImage = obj.createCapabilityProperty('GrayImage', false);
            obj.DepthImage = obj.createCapabilityProperty('DepthImage', false);
            obj.PointCloud = obj.createCapabilityProperty('PointCloud', false);
            obj.IMU = obj.createCapabilityProperty('IMU', false);
        end

        function capProp = createCapabilityProperty(obj, capPropName, isActive)
        %createCapabilityProperty Create a capability property
        %   Currently each property is a struct with two fields:
        %   - TopicName defines the name of the capability topic
        %   - Active specifics if the capability is currently active

            capProp = struct;
            capProp.TopicName = obj.TopicInterface.([capPropName 'Topic']);
            capProp.Active = isActive;
        end

        function [msgData, rosMsg] = getROSMessageData(obj, propName, conversionFcn, timeout)
        %getROSMessageData Get a ROS message from the topic associated with PROPNAME
        %    [MSGDATA, ROSMSG] = getROSMessageData(OBJ, PROPNAME, CONVERSIONFCN)
        %    Get a ROS message, ROSMSG, from the ROS topic associated with
        %    PROPNAME. Then execute CONVERSIONFCN to extract the MATLAB
        %    message data and return it in MSGDATA.
        %
        %    [MSGDATA, ROSMSG] = getROSMessageData(OBJ, PROPNAME, CONVERSIONFCN, TIMEOUT)
        %    allows you to specify a TIMEOUT (in seconds). If no new
        %    ROS message is received within TIMEOUT seconds, the
        %    function displays an error.
        %    A timeout of 0 returns the LatestMessage received on the topic.
        %    If no message has been received yet, MSGDATA is []
        %    and ROSMSG is an empty ROS message.

            msgData = [];

            % If the timeout is not given, set it to default
            if ~exist('timeout','var')
                timeout = obj.TimeoutDefault;
            end

            validateattributes(timeout, {'numeric'}, {'scalar','nonnan','finite','real','nonnegative'}, ['get' propName], 'timeout');
            timeout = double(timeout);

            % If the subscriber does not exist, create it
            subString = [propName 'Subscriber'];
            if isempty(obj.(subString))
                obj.(propName).Active = 1;
            end

            % Get the ROS message
            if timeout == 0
                rosMsg = obj.(subString).LatestMessage;
            else
                rosMsg = receive(obj.(subString), timeout);
            end

            % Return if no message was received
            if isempty(rosMsg)
                return;
            end

            % Convert ROS message into more usable MATLAB data structure
            msgData = conversionFcn(rosMsg);
        end

        function [pub,msg] = enablePub(obj, propName, activatePub, topicName)
        %enablePub Create a publisher for the specified topic

        % Get expected message type
            msgType = obj.TopicInterface.([propName 'MessageType']);

            if activatePub
                obj.verifyTopicNameValid(topicName, propName);
                obj.verifyTopicMessageType(topicName, msgType);

                % Create publisher
                pub = ros.Publisher(obj.Node, topicName, msgType);
                msg = rosmessage(msgType);
            else
                pub = [];
                msg = [];
            end
        end

        function [sub] = enableSub(obj, propName, activateSub, topicName)
        %enableSub Create a subscriber for the specified topic

        % Get expected message type
            msgType = obj.TopicInterface.([propName 'MessageType']);

            if activateSub
                obj.verifyTopicNameValid(topicName, propName);
                obj.verifyTopicMessageType(topicName, msgType);

                % Create subscriber
                sub = ros.Subscriber(obj.Node, topicName, msgType);
            else
                sub = [];
            end
        end

        function verifyTopicMessageType(obj, topicName, expectedMsgType)
        %verifyTopicMessageType Verify that existing ROS topic has expected message type

            try
                actualMsgType = ros.internal.NetworkIntrospection.getPublishedTopicType(topicName, false, obj.Node.MasterURI);
            catch
                % Topic does not exist yet. No more verification needed.
                return;
            end

            % Ensure that message type of existing topic matches our expectation
            if ~strcmp(actualMsgType, expectedMsgType)
                error(message('turtlebotrobot:turtlebot:MessageTypeMismatch', ...
                              topicName, expectedMsgType, actualMsgType));
            end
        end

        function verifyTopicNameValid(obj, topicName, propName)
        %verifyTopicNameValid Verify that TOPICNAME is valid
            if isempty(topicName)
                error(message('turtlebotrobot:turtlebot:CapabilityNotAvailable', ...
                              propName, obj.TopicInterface.InterfaceName));
            end
        end

        function enableVelocity(obj, capStruct)
        %enableVelocity Enable sending velocities to mobile base
            [pub,msg] = enablePub(obj, 'Velocity', capStruct.Active, capStruct.TopicName);
            obj.VelocityPublisher = pub;
            obj.VelocityMessage = msg;
        end

        function enableColorImage(obj, capStruct)
        %enableColorImage Enable color image
            obj.ColorImageSubscriber = enableSub(obj, 'ColorImage', capStruct.Active, capStruct.TopicName);
        end

        function enableGrayImage(obj, capStruct)
        %enableGrayImage Enable grayscale image
            obj.GrayImageSubscriber = enableSub(obj, 'GrayImage', capStruct.Active, capStruct.TopicName);
        end

        function enableDepthImage(obj, capStruct)
        %enableDepthImage Enable depth image
            obj.DepthImageSubscriber = enableSub(obj, 'DepthImage', capStruct.Active, capStruct.TopicName);
        end

        function enablePointCloud(obj, capStruct)
        %enablePointCloud Enable point cloud
            obj.PointCloudSubscriber = enableSub(obj, 'PointCloud', capStruct.Active, capStruct.TopicName);
        end

        function enableOdometry(obj, capStruct)
        %enableOdometry Enable odometry
            obj.OdometrySubscriber = enableSub(obj, 'Odometry', capStruct.Active, capStruct.TopicName);
        end

        function enableOdometryReset(obj, capStruct)
        %enableOdometryReset Enable resetting odometry on mobile base
            [pub,msg] = enablePub(obj, 'OdometryReset', capStruct.Active, capStruct.TopicName);
            obj.OdometryResetPublisher = pub;
            obj.OdometryResetMessage = msg;
        end

        function enableLaserScan(obj, capStruct)
        %enableLaserScan Enable laser scan
            obj.LaserScanSubscriber = enableSub(obj, 'LaserScan', capStruct.Active, capStruct.TopicName);
        end

        function enableIMU(obj, capStruct)
        %enableIMU Enable IMU
            obj.IMUSubscriber = enableSub(obj, 'IMU', capStruct.Active, capStruct.TopicName);
        end
    end
end
