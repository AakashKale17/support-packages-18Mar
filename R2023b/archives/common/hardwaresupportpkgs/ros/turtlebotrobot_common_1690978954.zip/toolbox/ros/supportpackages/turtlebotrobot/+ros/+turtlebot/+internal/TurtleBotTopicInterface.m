classdef (Abstract) TurtleBotTopicInterface
%TurtleBotTopicInterface Abstract interface to a physical or simulated TurtleBot
%   This interface defines the topic names that are associated with
%   different TurtleBot capabilities. If the topic name is an empty
%   string, that capability is not available for this type of TurtleBot
%   instance.
%
%   Concrete subclasses might include a class for a physical TurtleBot
%   and a class for a TurtleBot in Gazebo.
%
%   Note that the naming scheme of the properties is important and has
%   the following constraints:
%   - <CAPABILITY>Topic is a property that stores the topic name for a
%     given CAPABILITY.
%   - <CAPABILITY>MessageType stores the expected ROS message type.
%   The "turtlebot" class has an associated <CAPABILITY> property.
%
%   See also turtlebot, ros.turtlebot.internal.TurtleBotGazeboInterface,
%   ros.turtlebot.internal.TurtleBotPhysicalInterface.

%   Copyright 2015-2018 The MathWorks, Inc.

%% The message types of the capability topics
%   These types are constant are constant across all concrete
%   interfaces.
    properties (Abstract, SetAccess = protected)
        %VelocityMessageType - Message type for moving the robot
        VelocityMessageType

        %ColorImageMessageType - Message type for color images from the Kinect
        ColorImageMessageType

        %GrayImageMessageType - Message type for grayscale images from the Kinect
        GrayImageMessageType

        %DepthImageMessageType - Message type for depth images from the Kinect
        DepthImageMessageType

        %PointCloudMessageType - Message type for depth images from the Kinect
        PointCloudMessageType

        %LaserScanMessageType - Message type for laser scans
        LaserScanMessageType

        %OdometryMessageType - Message type for odometry data
        OdometryMessageType

        %OdometryResetMessageType - Message type for resetting the TurtleBot odometry
        OdometryResetMessageType

        %IMUMessageType - Message type for Inertial Measurement Unit (IMU) data
        IMUMessageType
    end

    properties (Abstract, Constant)
        %InterfaceName - Name of TurtleBot interface
        InterfaceName
    end

    %% The actual topic names for TurtleBot capabilities
    %   These properties should be defined by deriving classes.
    properties (Abstract, SetAccess = protected)
        %VelocityTopic - Topic for moving the robot
        VelocityTopic

        %ColorImageTopic - Topic for color images from the Kinect
        ColorImageTopic

        %GrayImageTopic - Topic for grayscale images from the Kinect
        GrayImageTopic

        %DepthImageTopic - Topic for depth images from the Kinect
        DepthImageTopic

        %PointCloudTopic - Topic for depth images from the Kinect
        PointCloudTopic

        %LaserScanTopic - Topic for laser scans
        LaserScanTopic

        %OdometryTopic - Topic for odometry data
        OdometryTopic

        %OdometryResetTopic - Topic for resetting the TurtleBot odometry
        OdometryResetTopic

        %IMUTopic - Topic for Inertial Measurement Unit (IMU) data
        IMUTopic
    end

    %% Abstract Methods. Need to be implemented by concrete subclasses.
    methods (Abstract, Static)
        %isInterfaceConnected Determine if ROS node is connected to a TurtleBot instance of this type
        isConnected = isInterfaceConnected(node)
    end
end
