classdef TurtleBotPackageInfo < matlab.addons.internal.SupportPackageInfoBase
%TurtleBotPackageInfo Enable TurtleBot support package for MATLAB Compiler
%   The file structure is based on the instructions on:
%   http://inside.mathworks.com/wiki/MATLAB_Compiler_Support_for_Hardware_Support_Packages

%   Copyright 2015-2018 The MathWorks, Inc.

    methods
        function obj = TurtleBotPackageInfo
        %TurtleBotPackageInfo Construct package info object

            obj.baseProduct = 'ROS Toolbox';
            obj.displayName = 'TurtleBot Robots';
            obj.name = 'TurtleBot Robots';

            sproot = matlabshared.supportpkg.getSupportPackageRoot;
            tbotBaseDir = fullfile(sproot, 'toolbox', 'ros', 'supportpackages', 'turtlebotrobot');

            % Files that should always be included in deployed package.
            % Include all support package source files and resources.
            obj.mandatoryIncludeList = {...
                fullfile(tbotBaseDir, 'turtlebot.m'), ...
                fullfile(tbotBaseDir, '+ros'), ...
                fullfile(sproot, 'resources', 'turtlebotrobot'), ...
                   };
        end
    end
end
