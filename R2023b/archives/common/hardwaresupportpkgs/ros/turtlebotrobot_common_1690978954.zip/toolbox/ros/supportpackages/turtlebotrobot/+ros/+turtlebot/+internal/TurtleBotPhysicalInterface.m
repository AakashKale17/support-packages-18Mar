classdef TurtleBotPhysicalInterface < ros.turtlebot.internal.TurtleBotTopicInterface
%TurtleBotPhysicalInterface Defines the interface to a physical TurtleBot
%   In particular, this is an interface to a TurtleBot 2.0 running ROS
%   Hydro or ROS Indigo.

%   Copyright 2015-2018 The MathWorks, Inc.

    properties (Constant)
        %InterfaceName - Name of TurtleBot interface
        InterfaceName = 'Physical TurtleBot'
    end

    %% The message types of the capability topics
    properties (SetAccess = protected)
        %VelocityMessageType - Message type for moving the robot
        VelocityMessageType = 'geometry_msgs/Twist'

        %ColorImageMessageType - Message type for color images from the Kinect
        ColorImageMessageType = 'sensor_msgs/CompressedImage'

        %GrayImageMessageType - Message type for grayscale images from the Kinect
        GrayImageMessageType = 'sensor_msgs/CompressedImage'

        %DepthImageMessageType - Message type for depth images from the Kinect
        DepthImageMessageType = 'sensor_msgs/Image'

        %PointCloudMessageType - Message type for depth images from the Kinect
        PointCloudMessageType = 'sensor_msgs/PointCloud2'

        %LaserScanMessageType - Message type for laser scans
        LaserScanMessageType = 'sensor_msgs/LaserScan'

        %OdometryMessageType - Message type for odometry data
        OdometryMessageType = 'nav_msgs/Odometry'

        %OdometryResetMessageType - Message type for resetting the TurtleBot odometry
        OdometryResetMessageType = 'std_msgs/Empty'

        %IMUMessageType - Message type for Inertial Measurement Unit (IMU) data
        IMUMessageType = 'sensor_msgs/Imu'
    end

    %% The actual topic names for TurtleBot capabilities
    properties (SetAccess = protected)
        %VelocityTopic - Topic for moving the robot
        VelocityTopic = '/mobile_base/commands/velocity'

        %ColorImageTopic - Topic for color images from the Kinect
        ColorImageTopic = '/camera/rgb/image_color/compressed'

        %GrayImageTopic - Topic for grayscale images from the Kinect
        GrayImageTopic = '/camera/rgb/image_mono/compressed'

        %DepthImageTopic - Topic for depth images from the Kinect
        DepthImageTopic = '/camera/depth_registered/image_raw'

        %PointCloudTopic - Topic for depth images from the Kinect
        PointCloudTopic = '/camera/depth_registered/points'

        %LaserScanTopic - Topic for laser scans
        LaserScanTopic = '/scan'

        %OdometryTopic - Topic for odometry data
        OdometryTopic = '/odom'

        %OdometryResetTopic - Topic for resetting the TurtleBot odometry
        OdometryResetTopic = '/mobile_base/commands/reset_odometry'

        %IMUTopic - Topic for Inertial Measurement Unit (IMU) data
        IMUTopic = '/mobile_base/sensors/imu_data'
    end

    %% Abstract Methods. Need to be implemented by concrete subclasses.
    methods (Static)
        function isConnected = isInterfaceConnected(node)
        %isInterfaceConnected Determine if ROS node is connected to a physical TurtleBot
        %   This method does not check for any of the TurtleBot
        %   capability topics, since the user might define different
        %   topic names.

            validateattributes(node, {'ros.Node'}, {'scalar'}, 'isInterfaceConnected', 'node');

            % Only the physical robot has a diagnostics topic
            isConnected = ros.internal.NetworkIntrospection.isTopicPublished('/diagnostics', node.MasterURI);
        end
    end
end
