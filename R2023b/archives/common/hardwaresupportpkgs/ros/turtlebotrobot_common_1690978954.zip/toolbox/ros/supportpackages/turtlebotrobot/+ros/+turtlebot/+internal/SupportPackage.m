classdef SupportPackage
%This class is for internal use only. It may be removed in the future.

%SupportPackage Stores information about the TurtleBot Support Package

%   Copyright 2015-2018 The MathWorks, Inc.

    properties (Constant)
        %Name - Name of support package
        Name = 'turtlebotrobot'
    end

    properties
        %InstallDir - Installation directory for support package
        InstallDir = ''
    end

    methods
        function obj = SupportPackage
        %SupportPackage Constructor

        % Get filepath
            filepath = fileparts(mfilename('fullpath'));

            % Get installDir
            tmp  = regexp(fullfile(filepath), '(.+)toolbox.+$', 'tokens', 'once');
            installDir = tmp{1};

            obj.InstallDir = ros.internal.Parsing.validateFolderPath( ...
                installDir);
        end
    end
end
