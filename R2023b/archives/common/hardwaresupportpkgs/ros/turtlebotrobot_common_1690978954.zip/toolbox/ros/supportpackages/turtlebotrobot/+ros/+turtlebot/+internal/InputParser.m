classdef InputParser < handle
%InputParser Parser for 'turtlebot' class methods
%   The parsing code is separated in this class to facilitate automated
%   unit testing.

%   Copyright 2015-2018 The MathWorks, Inc.

    methods (Static)
        function parsedStruct = parseCapabilityProperty(propName, inputPropStruct)
        %parseCapabilityProperty Parse and validate user input for capability properties
        %   PARSEDSTRUCT = parseCapabilityProperty(PROPNAME, INPUTPROPSTRUCT)
        %   parses the user-specified INPUTPROPSTRUCT and verifies that
        %   it is a valid value for PROPNAME.
        %   The valid property structure is returned in PARSEDSTRUCT.

            parsedStruct = inputPropStruct;

            % Input has be a non-empty structure
            validateattributes(parsedStruct, {'struct'}, {'nonempty','scalar'}, propName);

            % The user is not allowed to change the field names or to add / remove fields.
            names = fieldnames(parsedStruct);
            if numel(names) ~= 2
                error(message('turtlebotrobot:turtlebot:PropInvalidNumFields', propName, num2str(numel(names))));
            end
            for i = 1:length(names)
                if ~ismember(names{i}, {'TopicName', 'Active'})
                    error(message('turtlebotrobot:turtlebot:PropInvalidFieldName', propName, names{i}));
                end
            end

            % Validate the individual fields
            % Allow 'TopicName' to be an empty or a row string.
            validateattributes(parsedStruct.TopicName, {'char'}, {}, [propName '.TopicName']);
            if ~isempty(parsedStruct.TopicName)
                validateattributes(parsedStruct.TopicName, {'char'}, {'row'}, [propName '.TopicName']);
            end

            % Make sure that topic name is a valid ROS graph name (also
            % canonicalizes it)
            parsedStruct.TopicName = ros.internal.Namespace.canonicalizeName(parsedStruct.TopicName);

            % Allow 'Active' to be any numeric that can be cast to logical
            validateattributes(parsedStruct.Active, {'numeric','logical'}, ...
                               {'nonempty','scalar','nonnan','real'}, [propName '.Active']);
            parsedStruct.Active = logical(parsedStruct.Active);

        end
    end

    methods
        function parsedInputs = parseSetVelocityInputs(obj, defaultInputs, varargin)
        %parseSetVelocityInputs Parse the arguments to the setVelocity method
        %   DEFAULTINPUTS is a structure containing the defaults for
        %   the linear velocity ('LinearVel'), for the angular velocity
        %   ('AngularVel'), for the Time name-value pair ('Time'), and
        %   for the Twist ROS message ('ROSMessage').

            narginchk(3,6);

            parsedInputs = defaultInputs;

            switch length(varargin)
              case 1
                if isnumeric(varargin{1})
                    % Syntax setVelocity(TB, LINEARVEL)
                    obj.validateLinearVelocity(varargin{1});
                    parsedInputs.LinearVel = double(varargin{1});
                    parsedInputs.AngularVel = 0;
                else
                    % Syntax setVelocity(TB, TWISTMSG)
                    obj.validateTwistMsg(varargin{1});
                    % Make a deep copy of input message
                    parsedInputs.ROSMessage = copy(varargin{1});
                end
              case 2
                % Syntax setVelocity(TB, LINEARVEL, ANGULARVEL)
                obj.validateLinearVelocity(varargin{1});
                obj.validateAngularVelocity(varargin{2});
                parsedInputs.LinearVel = double(varargin{1});
                parsedInputs.AngularVel = double(varargin{2});
              case 3
                if isnumeric(varargin{1})
                    % Syntax setVelocity(TB, LINEARVEL, 'Time', TIME)
                    obj.validateLinearVelocity(varargin{1});
                    parsedInputs.LinearVel = double(varargin{1});
                    parsedInputs.AngularVel = 0;
                else
                    % Syntax setVelocity(TB, TWISTMSG, 'Time', TIME)
                    obj.validateTwistMsg(varargin{1});
                    % Make a deep copy of input message
                    parsedInputs.ROSMessage = copy(varargin{1});
                end
                obj.validateTimeNameValue(varargin{2}, varargin{3});
                parsedInputs.Time = double(varargin{3});
              case 4
                % Syntax setVelocity(TB, LINEARVEL, ANGULARVEL, 'Time', TIME)
                obj.validateLinearVelocity(varargin{1});
                obj.validateAngularVelocity(varargin{2});
                obj.validateTimeNameValue(varargin{3}, varargin{4});
                parsedInputs.LinearVel = double(varargin{1});
                parsedInputs.AngularVel = double(varargin{2});
                parsedInputs.Time = double(varargin{4});
              otherwise
                assert(false, message('turtlebotrobot:turtlebot:WrongNumArguments', 1, 4, length(varargin)));
            end
        end
    end

    methods (Static)
        function validateLinearVelocity(linVel)
        %validateLinearVelocity Validate linear velocity input to setVelocity method
            validateattributes(linVel, {'numeric'}, {'scalar','nonnan','finite','real'}, 'setVelocity', 'linearVel');
        end

        function validateAngularVelocity(angVel)
        %validateAngularVelocity Validate angular velocity input to setVelocity method
            validateattributes(angVel, {'numeric'}, {'scalar','nonnan','finite','real'}, 'setVelocity', 'angularVel');
        end

        function validateTwistMsg(twistMsg)
        %validateTwistMsg Validate twist message input to setVelocity method
            validateattributes(twistMsg, {'ros.msggen.geometry_msgs.Twist'}, {'nonempty','scalar'}, 'setVelocity', 'twistMsg');
        end

        function validateTimeNameValue(timeName, timeValue)
        %validateTimeNameValue Validate 'Time' name-value pair of setVelocity method
            validatestring(timeName, {'Time'}, 'setVelocity', 'Time');
            validateattributes(timeValue, {'numeric'}, {'scalar','nonnan','finite','real','positive'}, 'setVelocity', 'Time');
        end
    end
end
