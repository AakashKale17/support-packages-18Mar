classdef TurtleBotGazeboInterface < ros.turtlebot.internal.TurtleBotTopicInterface
%TurtleBotGazeboInterface Defines the interface to a simulated TurtleBot
%   The TurtleBot simulation runs in Gazebo on ROS Hydro or ROS Indigo.

%   Copyright 2015-2018 The MathWorks, Inc.

    properties (Constant)
        %InterfaceName - Name of TurtleBot interface
        InterfaceName = 'Gazebo TurtleBot'
    end

    %% The message types of the capability topics
    properties (SetAccess = protected)
        %VelocityMessageType - Message type for moving the robot
        VelocityMessageType = 'geometry_msgs/Twist'

        %ColorImageMessageType - Message type for color images from the Kinect
        ColorImageMessageType = 'sensor_msgs/Image'

        %GrayImageMessageType - Message type for grayscale images from the Kinect
        GrayImageMessageType = 'sensor_msgs/Image'

        %DepthImageMessageType - Message type for depth images from the Kinect
        DepthImageMessageType = 'sensor_msgs/Image'

        %PointCloudMessageType - Message type for depth images from the Kinect
        PointCloudMessageType = 'sensor_msgs/PointCloud2'

        %LaserScanMessageType - Message type for laser scans
        LaserScanMessageType = 'sensor_msgs/LaserScan'

        %OdometryMessageType - Message type for odometry data
        OdometryMessageType = 'nav_msgs/Odometry'

        %OdometryResetMessageType - Message type for resetting the TurtleBot odometry
        OdometryResetMessageType = 'std_msgs/Empty'

        %IMUMessageType - Message type for Inertial Measurement Unit (IMU) data
        IMUMessageType = 'sensor_msgs/Imu'
    end

    %% The actual topic names for TurtleBot capabilities
    properties (SetAccess = protected)
        %VelocityTopic - Topic for moving the robot
        VelocityTopic = '/mobile_base/commands/velocity'

        %ColorImageTopic - Topic for color images from the Kinect
        %   Gazebo offers no compressed image topics.
        ColorImageTopic = '/camera/rgb/image_raw'

        %GrayImageTopic - Topic for grayscale images from the Kinect
        %    No grayscale camera images are published in Gazebo.
        GrayImageTopic = ''

        %DepthImageTopic - Topic for depth images from the Kinect
        %   Gazebo offers no compressed image topics. The depth image is
        %   always aligned with the color image.
        DepthImageTopic = '/camera/depth/image_raw'

        %PointCloudTopic - Topic for depth images from the Kinect
        %   The depth image is always aligned with the color image.
        PointCloudTopic = '/camera/depth/points'

        %LaserScanTopic - Topic for laser scans
        LaserScanTopic = '/scan'

        %OdometryTopic - Topic for odometry data
        OdometryTopic = '/odom'

        %OdometryResetTopic - Topic for resetting the TurtleBot odometry
        OdometryResetTopic = '/mobile_base/commands/reset_odometry'

        %IMUTopic - Topic for Inertial Measurement Unit (IMU) data
        %   The IMU is not simulated in Gazebo.
        IMUTopic = ''
    end

    %% Abstract Methods. Need to be implemented by concrete subclasses.
    methods (Static)
        function isConnected = isInterfaceConnected(node)
        %isInterfaceConnected Determine if ROS node is connected to a Gazebo TurtleBot
        %   This method does not check for any of the TurtleBot
        %   capability topics, since the user might define different
        %   topic names.

            validateattributes(node, {'ros.Node'}, {'scalar'}, 'isInterfaceConnected', 'node');

            isConnected = false;

            % Check if some Gazebo-specific topics exist
            hasLinkStates = ros.internal.NetworkIntrospection.isTopicPublished('/gazebo/link_states', node.MasterURI);
            hasModelStates = ros.internal.NetworkIntrospection.isTopicPublished('/gazebo/model_states', node.MasterURI);

            if hasLinkStates && hasModelStates
                isConnected = true;
            end
        end
    end
end
