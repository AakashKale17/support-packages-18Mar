#include "MW_thingspeak_talkback.h"

#define MAX_POSITION_LEN 5
#define MAX_HEADER_LEN 100

int initOnce;

struct arg_list{
    char *curlCommand;
    TBReadData_t *TBReadDataPtr;
};

static void *httpPostThread(void *args)
{
    char *curlCommand;
    TBReadData_t *TBReadDataPtr;
    CURLcode resp;
    struct arg_list *argPtr = (struct arg_list *)args;
    
    // Detach thread from parent
    pthread_detach(pthread_self());

    curlCommand = (char *)argPtr->curlCommand;
    TBReadDataPtr = (TBReadData_t *) argPtr->TBReadDataPtr;
    
    if( TBReadDataPtr != NULL){
        if (TBReadDataPtr->curl_handle != NULL){
            resp = curl_easy_perform(TBReadDataPtr->curl_handle);
            if(TBReadDataPtr->printDiagnosticMessages){
                printf("TALKBACK_DIAG_MSG: curl_easy_perform status - %s\r\n", curl_easy_strerror(resp));
                fflush(stdout);
            }
            if(resp != CURLE_OK){
                    perror("curl_easy_perform failed");
                    return 0;
            }
            
        }else{
            if(TBReadDataPtr->printDiagnosticMessages){
                printf("TALKBACK_DIAG_MSG: Invalid curl handle");
                fflush(stdout);
            }
            return 0;
        }
    }else{
        perror("Invalid structure handle");
        return 0;
    }
   
    //Free up mallocs
    if (curlCommand) {
        free(curlCommand);
    }
    
    curl_easy_cleanup(TBReadDataPtr->curl_handle);
    free(TBReadDataPtr);
    
    if(argPtr){
        free(argPtr);
    }
}

size_t WriteMemoryCallbackTB(void *contents, size_t size, size_t nmemb, void *userp)
{
    TBReadData_t *TBReadDataPtr = (TBReadData_t *)userp;
    TBReadChunk_t *mem = (TBReadChunk_t *)&TBReadDataPtr->dataRead;

    size_t realsize = size * nmemb;

    if(mem->dataReceived != NULL){
        free(mem->dataReceived);
    }
    
    mem->dataReceived = (char *)malloc(realsize + 1);
    if(mem->dataReceived == NULL) {
        perror("Not enough memory (realloc returned NULL)\n");
        return 0;
    }
    
    memcpy(mem->dataReceived, contents, realsize);
    //mem->dataReceived[mem->size] = 0;
    mem->size = realsize;
    
    return realsize;
}

/* Required by TalkBack Write
 * The command id while adding a command is printed to the console if there 
 * is no callback to write this data into. Currently the data returned from
 * TalkBack Write curl operations response are not shown to the users. 
 * Implementation needs to be changed based upon future requirements.
 */ 
size_t dummyCallbackTB(void *contents, size_t size, size_t nmemb, void *userp){
    size_t realsize = size * nmemb;
    return realsize;
}

void MW_talkback_init(
    const char *talkBackApi,
    const char *talkBackID,
    const char *APIKey,
    const boolean_T printDiagnosticMessages)
{
    if(initOnce == 0){
        curl_global_init(CURL_GLOBAL_ALL);
        initOnce = 1;
    }
}

static char *createCurlReqPointer(
    const char *APIKey,
    const uint8_T *commandString)
{
    int strLen;
    char *curlCommand;
    
    strLen = strlen(APIKey) + strlen((char *)commandString);
    strLen += (MAX_HEADER_LEN + MAX_POSITION_LEN) * sizeof(APIKey[0]);
    
    curlCommand = (char *)malloc(strLen);
    if (curlCommand == NULL) {
        perror("Cannot allocate memory for TalkBack Write block.");
        return NULL;
    }

    curlCommand[0] = '\0';
    
    return curlCommand;
}

// Send data to ThingSpeak using curl
void MW_talkBack_addCommand(
    TBReadData_t *TBReadDataPtr,
    const char *APIKey,
    const char *position,
    const uint8_T *commandString)
{
    int strSize;
    char *curlCommand;
    pthread_t thread;
    struct arg_list *args;
    
    args = (struct arg_list *)malloc(sizeof(struct arg_list));
    if (args == NULL) {
        perror("Cannot allocate memory for TalkBack Write block.");
        return;
    }
	
    curlCommand = createCurlReqPointer(APIKey, commandString);
    if (curlCommand == NULL) {
        perror("Cannot allocate memory for TalkBack Write block.");
        return;
    }

    if (strcmp(position,"0")){
        sprintf(curlCommand,
                    "api_key=%s&command_string=%s&position=%s",
                    APIKey,
                    commandString,
                    position);
        if (TBReadDataPtr->printDiagnosticMessages){
            printf("TALKBACK_DIAG_MSG: POST with: command_string=%s position=%s", (char *)commandString, position);
            fflush(stdout);
        }
    }else{
        sprintf(curlCommand,
                    "api_key=%s&command_string=%s",
                    APIKey,
                    commandString);
        if (TBReadDataPtr->printDiagnosticMessages){
            printf("TALKBACK_DIAG_MSG: POST with: command_string=%s", (char *)commandString);
            fflush(stdout);
        }
    }
    
    curl_easy_setopt(TBReadDataPtr->curl_handle, CURLOPT_POSTFIELDS, curlCommand);
    
    args->curlCommand = curlCommand;
    args->TBReadDataPtr = TBReadDataPtr;
    
    // Create a thread to handle HTTP post. We do not wait until
    // curl_easy_perform call is executed.
    if (pthread_create(&thread, NULL, httpPostThread, (void *)args) != 0) {
        perror("Cannot create HTTP post thread.");
    }
}

void MW_talkBack_int2string(int channelNum, char *channelNumStr){
    sprintf(channelNumStr,"%d",channelNum);
}

TBReadData_t *MW_talkBack_writeHandle(const char* talkBackApi, const char* talkBackID, const char* APIKey, int cmdType, boolean_T printDiagnosticMessages)
{
    CURLcode resp;
    TBReadData_t *TBReadDataPtr;
    TBReadDataPtr = (TBReadData_t *)malloc(sizeof(TBReadData_t));
    char url[MAX_HEADER_LEN];
    
    // Mallocs in this file are freed in httpPostThread
    if(TBReadDataPtr == NULL){
        perror("Cannot allocate memory for TalkBack Execute block.");
        return NULL;
    }
    
    TBReadDataPtr->printDiagnosticMessages = printDiagnosticMessages;
    TBReadDataPtr->dataRead.size = 0;
    TBReadDataPtr->dataRead.dataReceived = NULL;
    
    if(cmdType == ADD_COMMAND){
        sprintf(url, "%s%s/commands", talkBackApi, talkBackID);
    }else if(cmdType = DELETE_COMMAND){
        sprintf(url, "%s%s/commands.json?api_key=%s", talkBackApi, talkBackID, APIKey);
    }
    
    TBReadDataPtr->curl_handle = curl_easy_init();
    if(TBReadDataPtr->curl_handle == NULL){
        perror("curl_easy_init failed");
    }else{
        curl_easy_setopt(TBReadDataPtr->curl_handle, CURLOPT_URL, url);
        curl_easy_setopt(TBReadDataPtr->curl_handle, CURLOPT_WRITEFUNCTION, dummyCallbackTB);
        curl_easy_setopt(TBReadDataPtr->curl_handle, CURLOPT_WRITEDATA, (void *)TBReadDataPtr);
        curl_easy_setopt(TBReadDataPtr->curl_handle, CURLOPT_USERAGENT, "libcurl-agent/1.0");
    }
       
    return TBReadDataPtr;
}

TBReadData_t *MW_talkBack_readInit(const char *TBReadUrl, boolean_T printDiagnosticMessages)
{
    TBReadData_t *TBReadDataPtr;
    TBReadDataPtr = (TBReadData_t *)malloc(sizeof(TBReadData_t));
    
    if(TBReadDataPtr == NULL){
        perror("Cannot allocate memory for TalkBack Execute block.");
        return NULL;
    }
    
    TBReadDataPtr->printDiagnosticMessages = printDiagnosticMessages;
    TBReadDataPtr->dataRead.size = 0;
    TBReadDataPtr->dataRead.dataReceived = NULL;
    
    TBReadDataPtr->curl_handle = curl_easy_init();
    curl_easy_setopt(TBReadDataPtr->curl_handle, CURLOPT_URL, TBReadUrl);
    curl_easy_setopt(TBReadDataPtr->curl_handle, CURLOPT_WRITEFUNCTION, WriteMemoryCallbackTB);
    curl_easy_setopt(TBReadDataPtr->curl_handle, CURLOPT_WRITEDATA, (void *)TBReadDataPtr);
    curl_easy_setopt(TBReadDataPtr->curl_handle, CURLOPT_USERAGENT, "libcurl-agent/1.0");

    if(printDiagnosticMessages){
        printf("TALKBACK_DIAG_MSG: TalkBack read url - %s\r\n", TBReadUrl);
        fflush(stdout);
    }    
    return TBReadDataPtr;

}

int MW_talkBack_readCommand(TBReadData_t *TBReadDataPtr, uint8_T *command, int cmdLen)
{
    CURLcode resp;

    json_object *parsed_json;
    json_object *commandString;
    
    int commandStringLen = 0;
    int keyExists;
    int status=0;
    
    if(TBReadDataPtr->curl_handle){
        /*Perform the request*/
        resp = curl_easy_perform(TBReadDataPtr->curl_handle);
        if(TBReadDataPtr->printDiagnosticMessages){
            printf("TALKBACK_DIAG_MSG: curl_easy_perform status - %s\n",curl_easy_strerror(resp));
            fflush(stdout);
        }
        if(resp != CURLE_OK){
            perror("curl_easy_perform failed");
            return 0;
        }
    }else{
        perror("curl_easy_perform failed invalid curl handle");
        return 0;
    }

    /* JSON Parsing */
    memset((void *)command, '\0', cmdLen);
    if(TBReadDataPtr->dataRead.dataReceived != NULL){
        if(TBReadDataPtr->printDiagnosticMessages){
            printf("TALKBACK_DIAG_MSG: Data Received - %s\r\n", TBReadDataPtr->dataRead.dataReceived);
            fflush(stdout);
        }
        parsed_json = json_tokener_parse(TBReadDataPtr->dataRead.dataReceived);
        keyExists = json_object_object_get_ex(parsed_json, "command_string", &commandString);
        if(keyExists == false){
            if(TBReadDataPtr->printDiagnosticMessages){
                printf("TALKBACK_DIAG_MSG: No Commands to display\r\n");
                fflush(stdout);
            }
            status = 0;
        }else{
            commandStringLen = json_object_get_string_len(commandString);
            if (commandStringLen > 0){
                if(commandStringLen <= cmdLen){
                    memcpy((void *)command, (void *)json_object_get_string(commandString), commandStringLen);
                    if(TBReadDataPtr->printDiagnosticMessages){
                        printf("TALKBACK_DIAG_MSG: Command String - %s\n",(char *)command);
                        fflush(stdout);
                    }
                    if(commandStringLen < cmdLen){     
                        status = 3;
                    }else{
                        status = 1;
                    }    
                }else{
                    memcpy((void *)command, (void *)json_object_get_string(commandString), cmdLen);
                    if(TBReadDataPtr->printDiagnosticMessages){
                        printf("TALKBACK_DIAG_MSG: Truncated Command String - %s\n",(char *)command);
                        fflush(stdout);
                    }
                    status = 2;
                } 
            }
        }
    }
        
    return status;
}

void MW_talkBack_deleteAll(TBReadData_t *TBReadDataPtr){
    
    struct arg_list *args;
    pthread_t thread;
    
    args = (struct arg_list *)malloc(sizeof(struct arg_list));
    args->curlCommand = NULL;
    args->TBReadDataPtr = TBReadDataPtr;
    
    if(TBReadDataPtr->curl_handle != NULL){
        curl_easy_setopt(TBReadDataPtr->curl_handle, CURLOPT_CUSTOMREQUEST, "DELETE");
    }else{
        if(TBReadDataPtr->printDiagnosticMessages){
            printf("TALKBACK_DIAG_MSG: Invalid curl handle");
            fflush(stdout);
        }
        return;
    }
    
    if (pthread_create(&thread, NULL, httpPostThread, (void *)args) != 0) {
        perror("Cannot create HTTP post thread.");
    } 
      
}

void MW_talkBack_terminate(TBReadData_t *TBReadDataPtr){
        
        if (TBReadDataPtr->dataRead.dataReceived != NULL){
            free(TBReadDataPtr->dataRead.dataReceived);
            TBReadDataPtr->dataRead.dataReceived = NULL;
        }
        
        if (TBReadDataPtr->curl_handle != NULL){
            curl_easy_cleanup(TBReadDataPtr->curl_handle);
        }
        
        curl_global_cleanup();
        
        if(TBReadDataPtr != NULL){
            free(TBReadDataPtr);
            TBReadDataPtr = NULL;
        }
            
    }