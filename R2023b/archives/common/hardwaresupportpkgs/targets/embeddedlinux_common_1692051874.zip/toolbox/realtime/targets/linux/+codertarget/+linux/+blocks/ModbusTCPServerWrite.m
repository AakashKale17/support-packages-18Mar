classdef ModbusTCPServerWrite < matlab.System & coder.ExternalDependency
    
    % MODBUSTCPSERVERWRITE - Provides Serve side functionality for MODBUS
    % protocol
    
    %#codegen
    
    % Copyright 2020-2023 The MathWorks, Inc.
    
    properties(Nontunable)
        %Modbus function
        Function = 'Write Coil';
        %Coil address
        CoilAddress = 0;
        %Discrete Input address
        DiscreteInputAddress = 0;
        %Holding Register address
        HoldingRegisterAddress = 0;
        %Input Register address
        InputRegisterAddress = 0;
    end
    
    properties(Hidden, Constant)
        FunctionSet = matlab.system.StringSet({...
            'Write Coil',...
            'Write Discrete Input',...
            'Write Holding register',...
            'Write Input register'});
    end
    
    properties(Hidden)
        FunctionEnum;
    end
    
    methods
        function obj = ModbusTCPServerWrite(varargin)
            coder.allowpcode('plain');
            setProperties(obj,nargin,varargin{:});
        end
        function set.CoilAddress(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',0,'<=',255},'','Coil Address');
            obj.CoilAddress = val;
        end
        
        function set.DiscreteInputAddress(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',0,'<=',255},'','Discrete Input Address');
            obj.DiscreteInputAddress = val;
        end
        
        function set.InputRegisterAddress(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',0,'<=',255},'','Input Register Address');
            obj.InputRegisterAddress = val;
        end
        
        function set.HoldingRegisterAddress(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',0,'<=',255},'','Holding Register Address');
            obj.HoldingRegisterAddress = val;
        end
        
        
        function val = get.FunctionEnum(obj)
            switch (obj.Function)
                case 'Write Coil'
                    val = 1;
                case 'Write Discrete Input'
                    val = 2;
                case 'Write Holding register'
                    val = 3;
                case 'Write Input register'
                    val = 4;
            end
        end
        
        function val = getTargetName(obj) %#ok<MANU>
            val = 'LINUX';
        end
    end
    
    methods(Access = protected)
        function setupImpl(obj, varargin) %#ok<INUSD>
            if coder.target('Rtw')
                coder.cinclude('MW_Modbus_TCP_Server.h');
                coder.ceval('MW_Modbus_Server_InitializeServer');
            end
        end
        
        
        
        function varargout = stepImpl(obj, data)
            Mstatus = int8(0);
            if coder.target('Rtw')
                switch (obj.FunctionEnum)
                    case 1
                        coder.ceval('MW_Modbus_Server_WriteCoil', uint16(obj.CoilAddress), coder.ref(data), coder.ref(Mstatus));
                    case 2
                        coder.ceval('MW_Modbus_Server_WriteInput', uint16(obj.DiscreteInputAddress), coder.ref(data), coder.ref(Mstatus));
                    case 3
                        coder.ceval('MW_Modbus_Server_WriteHoldingReg', uint16(obj.HoldingRegisterAddress), coder.ref(data), coder.ref(Mstatus));
                    case 4
                        coder.ceval('MW_Modbus_Server_WriteInputReg', uint16(obj.InputRegisterAddress), coder.ref(data), coder.ref(Mstatus));
                end
            end
            varargout{1} = Mstatus;
        end
        
        function releaseImpl(obj)
            if coder.target('Rtw')
                coder.ceval('MW_Modbus_Server_TerminateServer')
            end
        end
        
        
        function N = getNumInputsImpl(~)
            % Specify number of System inputs
            N = 1;
        end
        
        function N = getNumOutputsImpl(~)
            % Specify number of System outputs
            N = 0;
        end
        
        
        function flag = isInactivePropertyImpl(obj,prop)
            % Return false if property is visible based on object
            % configuration, for the command line and System block dialog
            switch prop
                case'Function'
                    flag = false;
                case'CoilAddress'
                    if (obj.FunctionEnum == 1)
                        flag = false;
                    else
                        flag = true;
                    end
                case'DiscreteInputAddress'
                    if (obj.FunctionEnum == 2)
                        flag = false;
                    else
                        flag = true;
                    end
                case'HoldingRegisterAddress'
                    if (obj.FunctionEnum == 3)
                        flag = false;
                    else
                        flag = true;
                    end
                case'InputRegisterAddress'
                    if (obj.FunctionEnum == 4)
                        flag = false;
                    else
                        flag = true;
                    end
            end
        end
        
        function validateInputsImpl(obj,data)
            switch obj.FunctionEnum
                case {1,2}
                    for k = 1:length(data)
                        validateattributes(data,{'logical'}, ...
                            {'nonnan', 'finite'}, '', 'input');
                    end
                case {3,4}
                    for k = 1:length(data)
                        validateattributes(data,{'uint16'}, ...
                            {'nonnan', 'finite'}, '', 'input');
                    end
            end
        end
        
        
        
        function maskDisplayCmds = getMaskDisplayImpl(obj)
            function_label = obj.Function;
            maskDisplayCmds = { ...
                'color(''white'');',...
                'plot([100,100,100,100]*1,[100,100,100,100]*1);',...
                'plot([100,100,100,100]*0,[100,100,100,100]*0);',...
                'color(''blue'');', ...
                ['text(99, 92, ''' getTargetName(obj) ''', ''horizontalAlignment'', ''right'');'],...
                'color(''black'');', ...
                'text(50,60,''\fontsize{12}\bfMODBUS TCP/IP'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');', ...
                'text(50,40,''\fontsize{10}\bfServer Write'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',...
                ['text(50,15,''\fontsize{8}', function_label  '' ''',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');']...
                };
        end
    end
    
    methods(Static, Access = protected)
        %% Simulink customization functions
        function header = getHeaderImpl(~)
            % Define header for the System block dialog box.
            header = matlab.system.display.Header(mfilename('class'), ...
                'Title', 'Modbus TCP/IP Server Write', 'Text', getString(message('linux:blockmask:ModbusTCPSlaveWrite')), ...
                'ShowSourceLink', false);
        end
        
        function simMode = getSimulateUsingImpl
            % Return only allowed simulation mode in System block dialog
            simMode = 'Interpreted execution';
        end
        
        function flag = showSimulateUsingImpl
            % Return false if simulation mode hidden in System block dialog
            flag = false;
        end
        
        
        function [groups, PropertyList] = getPropertyGroupsImpl
            FunctionProp = matlab.system.display.internal.Property('Function', 'Description', 'Function');
            coilAddressProp = matlab.system.display.internal.Property('CoilAddress', 'Description', 'Coil Address');
            inputAddressProp = matlab.system.display.internal.Property('DiscreteInputAddress', 'Description', 'Discrete Input Address');
            HoldingRegisterAddressProp = matlab.system.display.internal.Property('HoldingRegisterAddress', 'Description', 'Holding Register Address');
            InputRegisterAddressProp = matlab.system.display.internal.Property('InputRegisterAddress', 'Description', 'Input Register Address');
            
            
            % Property list
            PropertyList ={
                FunctionProp,...
                coilAddressProp, ...
                inputAddressProp, ...
                HoldingRegisterAddressProp,...
                InputRegisterAddressProp ...
                };
            
            % Create mask display
            Group = matlab.system.display.Section(...
                'PropertyList',PropertyList);
            
            groups = Group;
            
            % Return property list if required
            if nargout > 1
                PropertyList = PropertyListOut;
            end
        end
        
    end
    
    methods (Static)
        function name = getDescriptiveName()
            name = 'Modbus TCP Server Write';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                spkgRootDir = realtime.internal.getLinuxRoot;
                % Include Paths
                addIncludePaths(buildInfo, fullfile(spkgRootDir, 'include'));
                % Source Files
                systemTargetFile = get_param(buildInfo.ModelName,'SystemTargetFile');
                if isequal(systemTargetFile,'ert.tlc')
                    addSourcePaths(buildInfo, fullfile(spkgRootDir, 'src'));
                    addSourceFiles(buildInfo, 'MW_Modbus_TCP_Server.c', fullfile(spkgRootDir, 'src'), 'BlockModules');
                    mb_linkflags = '`pkg-config --libs --cflags libmodbus`';
                    addLinkFlags(buildInfo,mb_linkflags,'SkipForSil');
                    codertarget.linux.remotebuild.addTargetSpecificLibs(buildInfo,'-lmodbus');
                end
            end
        end
    end
end
