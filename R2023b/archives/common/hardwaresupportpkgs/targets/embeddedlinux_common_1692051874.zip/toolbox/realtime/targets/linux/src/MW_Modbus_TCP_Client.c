/*
 * @filename: MW_Modbus_TCP_Client.c 
 * 
 * @description: MODBUS TCP Client/Master for Linux targets
 *               Based on libmodbus library 
 * 
 * @copyright: Copyright 2020 The MathWorks, Inc. 
 */

#include "MW_Modbus_TCP_Client.h"

volatile mb_client_connection_t g_unique_client_connection_list[MW_NUM_MODBUS_UNIQUE_CLIENT_CONN];

static int get_index_by_ip(char *ip_addr)
{
    int i = 0;

    for (i = 0; i < MW_NUM_MODBUS_UNIQUE_CLIENT_CONN; i++)
    {   
        if (strcmp(ip_addr, g_unique_client_connection_list[i].ip_address) == 0)
        {
            return (i);
        }
    }
    return (-1);
}

static int create_client(int client_index)
{
    g_unique_client_connection_list[client_index].ctx = modbus_new_tcp(g_unique_client_connection_list[client_index].ip_address,
                                                                       g_unique_client_connection_list[client_index].port);
    if (g_unique_client_connection_list[client_index].ctx == NULL)
    {
        perror("MODBUS Client creation failed");
        return 0;
    }
    return 1; /* 0 - failure, 1 - success */
}

static int connect_client(int client_index)
{
    int rc;
    if (g_unique_client_connection_list[client_index].is_connected != 1)
    {
        rc = modbus_connect(g_unique_client_connection_list[client_index].ctx);
        if (rc == -1)
        {
            perror("MODBUS Client connection failed");
            return 0; /* 0 - failure, 1 - success */
        }
        g_unique_client_connection_list[client_index].is_connected = 1;
    }
    return 1; /* 0 - failure, 1 - success */
}

void MW_Modbus_Client_InitializeClient(char *server_ip)
{
    static int num_clients_connected = 0;
    int i = 0;
    int ret = 0;
    char dummyIP [15] = "00.00.00.00"; 
    if (num_clients_connected == 0)
    {
        /* mb_client_connection_t data structure gets initialized during the first call to this function */
        for (i = 0; i < MW_NUM_MODBUS_UNIQUE_CLIENT_CONN; i++)
        {
            memcpy(g_unique_client_connection_list[i].ip_address, dummyIP, sizeof(dummyIP));
            g_unique_client_connection_list[i].port = MW_MODBUS_MODBUS_SERVERREMOTEPORT;
            g_unique_client_connection_list[i].is_connected = 0;
        }
        strcpy(g_unique_client_connection_list[0].ip_address, server_ip);
        ret = create_client(0);
        ret = connect_client(0);
        num_clients_connected++; /* This keeps track of number of client created */
    }
    else
    {
        /* Reaches here when we have >1 Client block */
        ret = get_index_by_ip(server_ip);
        if (ret != -1)
        {
            /* Client is already created. Happens due to multiple Client SL blocks on same server addr*/
            ret = connect_client(ret);
        }
        else
        {
            /* Create the client */
            strcpy(g_unique_client_connection_list[i].ip_address, server_ip);
            ret = create_client(num_clients_connected);
            ret = connect_client(num_clients_connected);
            num_clients_connected++; /* This keeps track of number of client created */
        }
    }
}

void MW_Modbus_Client_TerminateClient(char *server_ip)
{
    int client_index = 0;
    int rc = 0;

    client_index = get_index_by_ip(server_ip);
    if (client_index == -1)
    {
        return;
    }
    modbus_close(g_unique_client_connection_list[client_index].ctx);
    modbus_free(g_unique_client_connection_list[client_index].ctx);
}

void MW_Modbus_Client_ReadCoil(char *server_ip, uint16_t addr, uint8_t *data, int8_t *status)
{
    int client_index = 0;
    int rc = 0;

    client_index = get_index_by_ip(server_ip);
    if (client_index == -1)
    {
        *status = 0;
        return;
    }
    if (connect_client(client_index) != 1)
    {
        *status = 0;
        return;
    }
    /* Ref: int modbus_read_bits(modbus_t *ctx, int addr, int nb, uint8_t *dest); */
    rc = modbus_read_bits(g_unique_client_connection_list[client_index].ctx, (int)addr, 1, data);
    if (rc == -1)
    {
        *status = 0;
        perror("MW_Modbus_Client_ReadCoil failed");
        return;
    }
    *status = 1;
}

void MW_Modbus_Client_ReadInput(char *server_ip, uint16_t addr, uint8_t *data, int8_t *status)
{
    int client_index = 0;
    int rc = 0;

    client_index = get_index_by_ip(server_ip);
    if (client_index == -1)
    {
        *status = 0;
        return;
    }
    if (connect_client(client_index) != 1)
    {
        *status = 0;
        return;
    }
    /* Ref: int modbus_read_input_bits(modbus_t *ctx, int addr, int nb, uint8_t *dest); */
    rc = modbus_read_input_bits(g_unique_client_connection_list[client_index].ctx, (int)addr, 1, data);
    if (rc == -1)
    {
        *status = 0;
        perror("MW_Modbus_Client_ReadInput failed");
        return;
    }
    *status = 1;
}

void MW_Modbus_Client_ReadInputRegister(char *server_ip, uint16_t addr, uint16_t *data, int8_t *status)
{
    int client_index = 0;
    int rc = 0;

    client_index = get_index_by_ip(server_ip);
    if (client_index == -1)
    {
        *status = 0;
        return;
    }
    if (connect_client(client_index) != 1)
    {
        *status = 0;
        return;
    }
    /* Ref: int modbus_read_input_registers(modbus_t *ctx, int addr, int nb, uint16_t *dest); */
    rc = modbus_read_input_registers(g_unique_client_connection_list[client_index].ctx, (int)addr, 1, data);
    if (rc == -1)
    {
        *status = 0;
        perror("MW_Modbus_Client_ReadInputRegister failed");
        return;
    }
    *status = 1;
}

void MW_Modbus_Client_ReadHoldingRegister(char *server_ip, uint16_t addr, uint16_t *data, int8_t *status)
{
    int client_index = 0;
    int rc = 0;

    client_index = get_index_by_ip(server_ip);
    if (client_index == -1)
    {
        *status = 0;
        return;
    }
    if (connect_client(client_index) != 1)
    {
        *status = 0;
        return;
    }
    /* Ref: int modbus_read_registers(modbus_t *ctx, int addr, int nb, uint16_t *dest); */
    rc = modbus_read_registers(g_unique_client_connection_list[client_index].ctx, (int)addr, 1, data);
    if (rc == -1)
    {
        *status = 0;
        perror("MW_Modbus_Client_ReadHoldingRegister failed");
        return;
    }
    *status = 1;
}

void MW_Modbus_Client_ReadMultipleCoils(char *server_ip, uint16_t addr, uint8_t nb, uint8_t *data, int8_t *status)
{
    int client_index = 0;
    int rc = 0;

    client_index = get_index_by_ip(server_ip);
    if (client_index == -1)
    {
        *status = 0;
        return;
    }
    if (connect_client(client_index) != 1)
    {
        *status = 0;
        return;
    }
    /* Ref: int modbus_read_bits(modbus_t *ctx, int addr, int nb, uint8_t *dest); */
    rc = modbus_read_bits(g_unique_client_connection_list[client_index].ctx, (int)addr, (int)nb, data);
    if (rc == -1)
    {
        *status = 0;
        perror("MW_Modbus_Client_ReadMultipleCoils failed");
        return;
    }
    *status = 1;
}

void MW_Modbus_Client_ReadMultipleInputs(char *server_ip, uint16_t addr, uint8_t nb, uint8_t *data, int8_t *status)
{
    int client_index = 0;
    int rc = 0;

    client_index = get_index_by_ip(server_ip);
    if (client_index == -1)
    {
        *status = 0;
        return;
    }
    if (connect_client(client_index) != 1)
    {
        *status = 0;
        return;
    }
    /* Ref: int modbus_read_input_bits(modbus_t *ctx, int addr, int nb, uint8_t *dest); */
    rc = modbus_read_input_bits(g_unique_client_connection_list[client_index].ctx, (int)addr, (int)nb, data);
    if (rc == -1)
    {
        *status = 0;
        perror("MW_Modbus_Client_ReadMultipleInputs failed");
        return;
    }
    *status = 1;
}

void MW_Modbus_Client_ReadMultipleInputRegister(char *server_ip, uint16_t addr, uint8_t nb, uint16_t *data, int8_t *status)
{
    int client_index = 0;
    int rc = 0;

    client_index = get_index_by_ip(server_ip);
    if (client_index == -1)
    {
        *status = 0;
        return;
    }
    if (connect_client(client_index) != 1)
    {
        *status = 0;
        return;
    }
    /* Ref: int modbus_read_input_registers(modbus_t *ctx, int addr, int nb, uint16_t *dest); */
    rc = modbus_read_input_registers(g_unique_client_connection_list[client_index].ctx, (int)addr, (int)nb, data);
    if (rc == -1)
    {
        *status = 0;
        perror("MW_Modbus_Client_ReadMultipleInputRegister failed");
        return;
    }
    *status = 1;
}

void MW_Modbus_Client_ReadMultipleHoldingRegister(char *server_ip, uint16_t addr, uint8_t nb, uint16_t *data, int8_t *status)
{
    int client_index = 0;
    int rc = 0;
    client_index = get_index_by_ip(server_ip);
    if (client_index == -1)
    {
        *status = 0;
        return;
    }
    if (connect_client(client_index) != 1)
    {
        *status = 0;
        return;
    }
    /* Ref: int modbus_read_registers(modbus_t *ctx, int addr, int nb, uint16_t *dest); */
    rc = modbus_read_registers(g_unique_client_connection_list[client_index].ctx, (int)addr, (int)nb, data);
    if (rc == -1)
    {
        *status = 0;
        perror("MW_Modbus_Client_ReadMultipleHoldingRegister failed");
        return;
    }
    *status = 1;
}

void MW_Modbus_Client_WriteCoil(char *server_ip, uint16_t addr, uint8_t *data, int8_t *status)
{
    int client_index = 0;
    int rc = 0;

    client_index = get_index_by_ip(server_ip);
    if (client_index == -1)
    {
        *status = 0;
        return;
    }
    if (connect_client(client_index) != 1)
    {
        *status = 0;
        return;
    }
    /* Ref: int modbus_write_bit(modbus_t *ctx, int addr, int status); */
    rc = modbus_write_bit(g_unique_client_connection_list[client_index].ctx, (int)addr, *data);
    if (rc == -1)
    {
        *status = 0;
        perror("MW_Modbus_Client_WriteCoil failed");
        return;
    }
    *status = 1;
}

void MW_Modbus_Client_WriteHoldingRegister(char *server_ip, uint16_t addr, uint16_t *data, int8_t *status)
{
    int client_index = 0;
    int rc = 0;

    client_index = get_index_by_ip(server_ip);
    if (client_index == -1)
    {
        *status = 0;
        return;
    }
    if (connect_client(client_index) != 1)
    {
        *status = 0;
        return;
    }
    /* Ref: int modbus_write_register(modbus_t *ctx, int addr, const uint16_t value); */
    rc = modbus_write_register(g_unique_client_connection_list[client_index].ctx, (int)addr, *data);
    if (rc == -1)
    {
        *status = 0;
        perror("MW_Modbus_Client_WriteHoldingRegister failed");
        return;
    }
    *status = 1;
}

void MW_Modbus_Client_WriteMultipleCoils(char *server_ip, uint16_t addr, uint8_t nb, uint8_t *data, int8_t *status)
{
    int client_index = 0;
    int rc = 0;

    client_index = get_index_by_ip(server_ip);
    if (client_index == -1)
    {
        *status = 0;
        return;
    }
    if (connect_client(client_index) != 1)
    {
        *status = 0;
        return;
    }
    /* Ref: int modbus_write_bits(modbus_t *ctx, int addr, int nb, const uint8_t *src); */
    rc = modbus_write_bits(g_unique_client_connection_list[client_index].ctx, (int)addr, (int)nb, data);
    if (rc == -1)
    {
        *status = 0;
        perror("MW_Modbus_Client_WriteMultipleCoils failed");
        return;
    }
    *status = 1;
}

void MW_Modbus_Client_WriteMultipleHoldingRegister(char *server_ip, uint16_t addr, uint8_t nb, uint16_t *data, int8_t *status)
{
    int client_index = 0;
    int rc = 0;

    client_index = get_index_by_ip(server_ip);
    if (client_index == -1)
    {
        *status = 0;
        return;
    }
    if (connect_client(client_index) != 1)
    {
        *status = 0;
        return;
    }
    /* Ref: int modbus_write_registers(modbus_t *ctx, int addr, int nb, const uint16_t *src); */
    rc = modbus_write_registers(g_unique_client_connection_list[client_index].ctx, (int)addr, (int)nb, data);
    if (rc == -1)
    {
        *status = 0;
        perror("MW_Modbus_Client_WriteMultipleHoldingRegister failed");
        return;
    }
    *status = 1;
}