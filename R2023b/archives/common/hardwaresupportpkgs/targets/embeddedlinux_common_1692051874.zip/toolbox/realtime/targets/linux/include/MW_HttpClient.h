/* Copyright 2023 The MathWorks, Inc. */
#ifndef _MW_HTTP_CLIENT_H_
#define _MW_HTTP_CLIENT_H_

#include "rtwtypes.h"

#if ( defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER) )
//no includes required 
#else

#include <stdio.h>          // Required by IO like printf
#include <stdlib.h>         // Required by malloc  
#include <string.h>         // Required by strlen 
#include <pthread.h>        // Required by pthreads
#include <curl/curl.h>      // Required by libcurl
#include <json-c/json.h>    // Required by json parsing 
#include <math.h>           // Required by round function for ms calculation

#endif //MATLAB_MEX_FILE

#ifdef __cplusplus
extern "C" {
#endif  
    
#if ( defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER) )
#define HTTPReadData_t void
#define MW_HttpClient_init()                                                        (0)
#define MW_HttpClient_terminate(a)                                                  (0)
#define MW_HttpClient_getHandle(a)                                                  (0)
#define MW_HttpClient_step(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o,p, q, r)     (0)
#define MW_getCurrentTimeInMillisHttp()                                             (0)
    
#else
    
typedef struct {
    char *dataReceived;
    size_t size;
} HTTPReadChunk_t;    

typedef struct {
    CURL *curl_handle;
    boolean_T printDiagnosticMessages;
	HTTPReadChunk_t dataRead;
} HTTPReadData_t;
       
void MW_HttpClient_init(void);
void MW_HttpClient_terminate(HTTPReadData_t *HTTPReadDataPtr);
HTTPReadData_t *MW_HttpClient_getHandle(boolean_T printDiagnosticMessages);
uint8_t MW_HttpClient_step(HTTPReadData_t *HTTPReadDataPtr, char* httpMethod, const char *URL, uint8_t doInput, uint8_t doOutput, char* payload, char* contentType, \
                                         char* accept, uint32_t responseStringMaxLength, char* response, uint32_t *responseSize, uint8_t numCustomHeaders, \
                                         char* header1Key, char* header1Value, \
                                         char* header2Key, char* header2Value, \
                                         char* header3Key, char* header3Value);
uint32_T MW_getCurrentTimeInMillisHttp(void);
    
#endif //MATLAB_MEX_FILE
    
#ifdef __cplusplus
}
#endif

#endif // _MW_HTTP_CLIENT_H_