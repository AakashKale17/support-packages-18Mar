classdef TCPReceive < sharedlinux.TCPReceive
                        
    % Receive data via tcp
    % Generic LINUX block
    
    %#codegen
    %#ok<*EMCA>    
    
    % Copyright 2012-2020 The MathWorks, Inc.

    properties (Nontunable)
        BlockPlatform = 'LINUX';
    end
    
    methods
        % Constructor
        function obj = TCPReceive(varargin)
            %This would allow the code generation to proceed with the
            %p-files in the installed location of the support package.
            coder.allowpcode('plain');
            
            % Support name-value pair arguments when constructing the object.
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods (Access=protected)       
        function maskDisplayCmds = getMaskDisplayImpl(obj)
            maskDisplayCmdsShared = getMaskDisplayImpl@sharedlinux.TCPReceive(obj);
            maskDisplayCmdsTarget = { ...
                ['color(''blue'');', newline],...
                ['text(145, 90, ''' obj.BlockPlatform ''', ''horizontalAlignment'', ''right'');', newline],...
                };
            maskDisplayCmds = [ maskDisplayCmdsShared, maskDisplayCmdsTarget];
        end
    end
    
    methods(Static, Access = protected)
        %% Simulink customization functions
        function groups = getPropertyGroupsImpl(~)
            groups = getPropertyGroupsImpl@sharedlinux.TCPReceive();
            blockPlatformProp = matlab.system.display.internal.Property('BlockPlatform', 'Description', 'Block Platform','IsGraphical', false, 'StringSetValues',{'LI'});
            groups(2).Sections.PropertyList{end+1} = blockPlatformProp;
        end
    end
    
    methods (Static)
        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                updateBuildInfo@sharedlinux.TCPReceive(buildInfo, context);
            end
        end
    end

end
