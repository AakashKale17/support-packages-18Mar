/**
 * @file IO_wrapper_i2c_pwm_pca9685.h
 *
 * Contains declarations of the functions used by the Pan tilt hat (pca9685 pwm) IO Wrapper
 *
 * @Copyright 2021 The MathWorks, Inc.
 *
 */

#ifndef IO_WRAPPER_I2C_PWM_PCA9685_H
#define IO_WRAPPER_I2C_PWM_PCA9685_H

#include "IO_include.h"
#include "IO_peripheralInclude.h"

#include "MW_i2c_pwm_pca9685.h" // Pan tilt hat driver file
#include "sharedServer.h"
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif
/*IO wrapper for PCA9685 PWM Pan tilt hat setup*/
void MW_I2C_PWM_PCA9685_Setup_IO_wrapper(uint8_T* payloadBufferRx, uint8_T* payloadBufferTx, uint16_T* peripheralDataSizeResponse);
/*IO wrapper for PCA9685 PWM Pan tilt hat step*/
void MW_I2C_PWM_PCA9685_Read_IO_wrapper(uint8_T* payloadBufferRx, uint8_T* payloadBufferTx, uint16_T* peripheralDataSizeResponse);
/*IO wrapper for PCA9685 PWM Pan tilt hat release*/
void MW_I2C_PWM_PCA9685_Release_IO_wrapper(uint8_T* payloadBufferRx, uint8_T* payloadBufferTx, uint16_T* peripheralDataSizeResponse);

#ifdef __cplusplus
}
#endif

#endif