/*
 * @filename: MW_Modbus_TCP_Server.c 
 *
 * @description: MODBUS TCP Server/Slave for Linux targets
 *               Based on libmodbus library 
 *
 * @copyright: Copyright 2020-2021 The MathWorks, Inc. 
 */

#include "MW_Modbus_TCP_Server.h"

pthread_t thread;
modbus_mapping_t *mb_memory_section;
modbus_t *ctx;
int server_running;

static void *mb_server_handler(void *args)
{
    static int socket_status = -1;
    int sock = -1;
    uint8_t *query;
    query = malloc(MODBUS_MAX_ADU_LENGTH);
    int rc = -1;

start_connection:
    ctx = modbus_new_tcp(NULL, MW_MODBUS_MODBUS_SERVERLOCALPORT);
    do
    {
        sock = modbus_tcp_listen(ctx, 1);
        printf("Waiting for a connection to accept ... \n");
        /* modbus_tcp_accept is a blocking call */
        socket_status = modbus_tcp_accept(ctx, &sock);

    } while ((socket_status == -1) || (sock == -1));
    printf("Accepted a connection\n");

    while (server_running)
    {
        do
        {
            rc = modbus_receive(ctx, query);
            /* 
             ConnectionResetError: [Errno 104]
             The Below check for 104 error was introduced to handle scenarios when the Master(client)
             closes the connection abruptly(RST packet sent and we support only connection to server at a time). 
             Server needs to close that socket, create a new socket and bind to that, else the sokcet would go into a bad state
             */
            if ((rc == -1) && (errno == 104))
            {
                close(sock);
                modbus_close(ctx);
                sleep(2); /* buffer time for the socket to become available */
                socket_status = -1;
                sock = -1;
                goto start_connection;
            }
        } while (rc <= 0); /* Filtered queries return 0 */
        rc = modbus_reply(ctx, query, rc, mb_memory_section);
    }
    free(query);
    modbus_close(ctx);
    modbus_free(ctx);
}

void MW_Modbus_Server_InitializeServer()
{

    static int memory_initialized = 0;
    int start_bits = 0;
    int nb_bits = 0;
    int start_input_bits = 0;
    int nb_input_bits = 0;
    int start_registers = 0;
    int nb_registers = 0;
    int start_input_registers = 0;
    int nb_input_registers = 0;

    if (memory_initialized == 0)
    {
        /*  Clean up the MACROS of Config Set  */
        
        if (0 != MW_MODBUS_MODBUS_CONFIGCOIL)
        {
            start_bits = MW_MODBUS_MODBUS_COILADDR;
            nb_bits = MW_MODBUS_MODBUS_COILNUM;
        }

        if (0 != MW_MODBUS_MODBUS_CONFIGINPUT)
        {
            start_input_bits = MW_MODBUS_MODBUS_INPUTADDR;
            nb_input_bits = MW_MODBUS_MODBUS_INPUTNUM;
        }
        
        if (0 != MW_MODBUS_MODBUS_CONFIGHOLDINGREG)
        {
            start_registers = MW_MODBUS_MODBUS_HOLDINGREGADDR;
            nb_registers = MW_MODBUS_MODBUS_HOLDINGREGNUM;
        }

        if (0 != MW_MODBUS_MODBUS_CONFIGINPUTREG)
        {
            start_input_registers = MW_MODBUS_MODBUS_INPUTREGADDR;
            nb_input_registers = MW_MODBUS_MODBUS_INPUTREGNUM;
        }
        
        mb_memory_section = modbus_mapping_new_start_address(start_bits, nb_bits, 
                                                             start_input_bits, nb_input_bits, 
                                                             start_registers, nb_registers, 
                                                             start_input_registers, nb_input_registers);
        memory_initialized = 1;                                                                  
    }

    if (server_running == 0)
    {
        /*  Start the thread for the server to respond to client's requests */
        pthread_create(&thread, NULL, mb_server_handler, NULL);
        server_running = 1;
    }
}

void MW_Modbus_Server_ReadCoil(uint16_t addr, uint8_t *data, int8_t *status)
{
    *data = mb_memory_section->tab_bits[addr];
    *status = 1;
}
void MW_Modbus_Server_ReadInput(uint16_t addr, uint8_t *data, int8_t *status)
{
    *data = mb_memory_section->tab_input_bits[addr];
    *status = 1;
}
void MW_Modbus_Server_ReadInputRegister(uint16_t addr, uint16_t *data, int8_t *status) 
{
    *data = mb_memory_section->tab_input_registers[addr];
    *status =  1;
}
void MW_Modbus_Server_ReadHoldingRegister(uint16_t addr, uint16_t *data, int8_t *status)
{
    *data = mb_memory_section->tab_registers[addr];
    *status = 1;
}
void MW_Modbus_Server_WriteCoil(uint16_t addr, uint8_t *data, int8_t *status)
{
    mb_memory_section->tab_bits[addr] = *data;
    *status = 1;
}
void MW_Modbus_Server_WriteInput(uint16_t addr, uint8_t *data, int8_t *status)
{
    mb_memory_section->tab_input_bits[addr] = *data;
    *status = 1;
}
void MW_Modbus_Server_WriteHoldingReg(uint16_t addr, uint16_t *data, int8_t *status)
{
    mb_memory_section->tab_registers[addr] = *data;
    *status = 1;
}
void MW_Modbus_Server_WriteInputReg(uint16_t addr, uint16_t *data, int8_t *status)
{
    mb_memory_section->tab_input_registers[addr] = *data;
    *status = 1;
}

void MW_Modbus_Server_TerminateServer()
{
    server_running = 0; /*  This will break the while loop in server thread */
    modbus_mapping_free(mb_memory_section);
}