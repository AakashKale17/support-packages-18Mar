classdef SPIRegisterWrite < matlabshared.svd.SPIMasterBlock ...
        & coder.ExternalDependency
    %SPIRegisterWrite Set the logical value of a digital output pin.
    %
    % Copyright 2020 The MathWorks, Inc.

    %#codegen
    
    properties (Nontunable)
        %SPIModule SPI module
        SPIModule = 0;
    end

    properties
        Pin            
    end
 
    methods
        function obj = SPIRegisterWrite(varargin)
            obj.Logo = 'LINUX';
        end
    end
 
    methods (Static)
        function name = getDescriptiveName(~)
            name = 'SPI Register Write';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context)
        end
    end
end
%[EOF]
