/* Copyright 2022 The MathWorks, Inc. */
/* MW_NNG.c*/

#include "MW_NNG.h"

#define URL_SIZE      50

#if !( defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER) )
// Code generation

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <sys/time.h>
#include <math.h>
#include <signal.h>

#include <nng/nng.h>
#include <nng/protocol/pubsub0/pub.h>
#include <nng/protocol/pubsub0/sub.h>

static void threadWait(NNGReceiveData_t* NNGReadDataPtr){
    
    struct timespec timeToWait;
    struct timeval now;
	double intPart, fractPart;
	
	fractPart = modf(NNGReadDataPtr->sampleTime,&intPart);
    
    gettimeofday(&now,NULL);
    
    timeToWait.tv_sec = now.tv_sec+intPart;
    timeToWait.tv_nsec = (now.tv_usec)*1000UL + (fractPart*1000000000UL);
    
    pthread_mutex_lock(&NNGReadDataPtr->readData_mutex);
    pthread_cond_timedwait(&NNGReadDataPtr->readData_cond_mutex, &NNGReadDataPtr->readData_mutex, &timeToWait);
    pthread_mutex_unlock(&NNGReadDataPtr->readData_mutex);   
}

/* 
 * Thread function to receive NNG messages in the background
 */
void* NNGReceiveThread(void* threadArg){
    
    NNGReceiveData_t *NNGReadDataPtr =  (NNGReceiveData_t*)threadArg;
    char *buf = NULL;
    size_t sz;
    int ret;
    
    NNGReadDataPtr->recvThread = pthread_self();

    while(1){
        ret = nng_recv(NNGReadDataPtr->sock, &buf, &sz, NNG_FLAG_ALLOC);
        if(ret == 0){
#ifdef PRINT_NNG_RECV_DEBUG         
            printf("NNG_RECV_DEBUG: Actual length of received data: %d bytes\r\n", sz);
#endif      
            // Critical section to copy the data to shared variable NNGReadDataPtr->dataRead
            if(!pthread_mutex_lock(&NNGReadDataPtr->readData_mutex)){
                if(sz > 0){
                    NNGReadDataPtr->dataRead.newData = true;
                }else{
                    NNGReadDataPtr->dataRead.newData = false;
                }      
                memcpy((void *)NNGReadDataPtr->dataRead.dataReceived, (const void*)buf, NNGReadDataPtr->dataRead.dataLen);
                ret = pthread_mutex_unlock(&NNGReadDataPtr->readData_mutex);
                if(ret){
#ifdef PRINT_NNG_RECV_DEBUG          
            printf("NNG_RECV_DEBUG: Mutex unlock failed and returned %d in receive thread, could result in undesired behaviour.\r\n", ret);        
#endif
                }
            }else{
#ifdef PRINT_NNG_RECV_DEBUG        
            printf("NNG_RECV_DEBUG: Mutex lock failed in receive thread, copying new data skipped\r\n");            
#endif      
            }
            nng_free(buf, sz);
        }else{
#ifdef PRINT_NNG_RECV_DEBUG 
            printf("NNG_RECV_DEBUG: nng_recv returned error number %d\r\n", ret);            
#endif
        }        
        threadWait(NNGReadDataPtr);
    }  
}

NNGSendData_t* MW_NNG_initSendSocket(const char *customURL){
    int ret;
    char url[URL_SIZE];
    NNGSendData_t *NNGSendDataPtr;

    NNGSendDataPtr = (NNGSendData_t *)malloc(sizeof(NNGSendData_t));
    if(NNGSendDataPtr == NULL){
        perror("NNG_SEND_DEBUG: Cannot allocate memory for NNG Send block.");
        return NULL;
    }

    if ((ret = nng_pub0_open(&(NNGSendDataPtr->sock))) != 0) {
        perror("NNG_SEND_DEBUG: nng_pub0_open: ");
    }
    
    sprintf(url, "ipc:///tmp/%s.ipc", customURL);

    if ((ret = nng_listen(NNGSendDataPtr->sock, url, NULL, NNG_FLAG_NONBLOCK)) < 0) {
        perror("NNG_SEND_DEBUG: nng_listen: ");
    }

    return NNGSendDataPtr;
}

NNGReceiveData_t* MW_NNG_initReceiveSocket(const char *customURL, const double sampleTime, uint32_t dataLen){
    int ret;
    char url[URL_SIZE];

    pthread_t tid;
    pthread_attr_t attr;
    
    NNGReceiveData_t *NNGReadDataPtr;
    NNGReadDataPtr = (NNGReceiveData_t *)malloc(sizeof(NNGReceiveData_t));
    if(NNGReadDataPtr == NULL){
        perror("NNG_RECV_DEBUG: Cannot allocate memory for NNG Receive block.");
        return NULL;
    }
    
    if(pthread_mutex_init(&NNGReadDataPtr->readData_mutex, NULL) != 0){
        perror("NNG_RECV_DEBUG: Error in initializing mutex");
        return NULL;
    }
    
    if(pthread_cond_init(&NNGReadDataPtr->readData_cond_mutex, NULL) != 0){
        perror("NNG_RECV_DEBUG: Error in initializing condition variable");
        return NULL;
    }
    
    NNGReadDataPtr->dataRead.dataLen = dataLen;
    NNGReadDataPtr->dataRead.dataReceived = (uint8_t *)malloc(dataLen * sizeof(uint8_t));
	
	/* Use thread wait as half of sample time*/
	NNGReadDataPtr->sampleTime = sampleTime/2;

    if ((ret = nng_sub0_open(&NNGReadDataPtr->sock)) != 0) {
        perror("NNG_RECV_DEBUG: nng_sub0_open");
    }
    
    if((ret = nng_socket_set(NNGReadDataPtr->sock, NNG_OPT_SUB_SUBSCRIBE, "", 0)) != 0) {
        perror("NNG_RECV_DEBUG: nng_setopt");
    }

    sprintf(url, "ipc:///tmp/%s.ipc", customURL);

    if ((ret = nng_dial(NNGReadDataPtr->sock, url, NULL, NNG_FLAG_NONBLOCK)) < 0) {
        perror("NNG_RECV_DEBUG: nng_dial");
    }

    /* Create thread to get NNG received data */
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    pthread_create(&tid,&attr,&NNGReceiveThread,NNGReadDataPtr);
    pthread_attr_destroy(&attr);

    return NNGReadDataPtr;
}

int MW_NNG_send(NNGSendData_t* NNGSendDataPtr, uint8_t *data, uint32_t dataLen){
    int ret;
    int i;
    
    ret = nng_send(NNGSendDataPtr->sock, (void *)data, (size_t)dataLen, NNG_FLAG_NONBLOCK);
    if(ret != 0){
#ifdef PRINT_NNG_SEND_DEBUG 
        printf("NNG_SEND_DEBUG: nng_send returned %d\r\n", ret);
#endif
        return 0;
    }
    
#ifdef PRINT_NNG_SEND_DEBUG 
        printf("NNG_SEND_DEBUG: Sent %d bytes\r\n", dataLen);
#endif

    return 1;
}

int MW_NNG_stepReceive(NNGReceiveData_t *NNGReadDataPtr, uint8_t *data, uint32_t dataLen){
    int ret;
    int val=0;
    
    // Critical section to copy the data from shared variable NNGReadDataPtr->dataRead
    if(!pthread_mutex_lock(&NNGReadDataPtr->readData_mutex)){
        if(NNGReadDataPtr->dataRead.newData){
            memcpy((void *)data, (const void *)NNGReadDataPtr->dataRead.dataReceived, dataLen);
            NNGReadDataPtr->dataRead.newData = false;
            val = 1;
        }
        ret = pthread_mutex_unlock(&NNGReadDataPtr->readData_mutex);
        if(ret){
#ifdef PRINT_NNG_RECV_DEBUG           
            printf("NNG_RECV_DEBUG: Mutex unlock failed and returned %d in MW_NNG_stepReceive, could result in undesired behaviour.\r\n", ret);        
#endif
        }
    }else{
#ifdef PRINT_NNG_RECV_DEBUG          
            printf("NNG_RECV_DEBUG: Mutex lock failed in MW_NNG_stepReceive, copying of new data will be skipped\r\n");            
#endif     
    }

    return val;
}

void MW_NNG_clearSendSocket(NNGSendData_t *NNGSendDataPtr){
    nng_close(NNGSendDataPtr->sock);
}

void MW_NNG_clearReceiveSocket(NNGReceiveData_t *NNGReadDataPtr){
    // Receive thread will be in detached state. Killing the main process 
    // might not kill the receive thread. So, send a kill command to it.
    // Might print a series  of "NNG_DEBUG: nng_recv returned error number 7"
    // before terminating. This error should not be a problem.
    // Err Number: 7: NNG_ECLOSED : Defined in nng.h
    pthread_kill(NNGReadDataPtr->recvThread, SIGTERM);

    free(NNGReadDataPtr->dataRead.dataReceived);
    nng_close(NNGReadDataPtr->sock);
    free(NNGReadDataPtr);
}


#endif //MATLAB_MEX_FILE | RSIM_PARAMETER_LOADING | RSIM_WITH_SL_SOLVER