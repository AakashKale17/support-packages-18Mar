classdef CANReceive < matlab.System & coder.ExternalDependency & matlabshared.svd.BlockSampleTime
    %
    % CAN Message receive block for Shared Linux targets.
    %

%   Copyright 2021 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>n
    
    properties
        %Identifier type
        IdentifierType  (1,:) char {matlab.system.mustBeMember(IdentifierType,{'Standard (11-bit identifier)', 'Extended (29-bit identifier)'})} = 'Standard (11-bit identifier)';
        sockHandle = int32(0);
        sockHandleDataFrames = int32(0);
        sockHandleErrorFrames = int32(0);
    end

    properties (Hidden, Nontunable)
        Logo = 'LINUX';
    end
    
    properties(Nontunable)
        %CAN interface
        DeviceID = 'can0';
        %TypeOfCAN
        TypeofCAN (1,:) char {matlab.system.mustBeMember(TypeofCAN,{'Real', 'Virtual'})} = 'Real';
        %Output data type
        OutputDataType  (1,:) char {matlab.system.mustBeMember(OutputDataType,{'Raw data', 'CAN Msg'})} = 'Raw data';
        %Message ID
        MessageId = 100;
        %Length (bytes)
        MsgLength = 8;
    end
    
    properties (Access = private)
        Initialized = false;
        IsCANSetup = true;
    end

    properties (Nontunable)
        %Output error
        OutputError (1, 1) logical = false;
        %Output remote
        OutputRemote (1, 1) logical = false;
        %Setup CAN Node
        SetupCAN (1, 1) logical = false;
    end
    
    properties(Hidden, Access = protected)
        PreviousData;
    end
    
    properties(Hidden, Transient)
        SetIdentifierType = false;
    end
    
    methods
        function obj = CANReceive(varargin)
            coder.allowpcode('plain');
            setProperties(obj,nargin,varargin{:});
        end
        
        function set.IdentifierType(obj,value)
            obj.IdentifierType = value;
            obj.SetIdentifierType = true; %#ok<MCSUP>
        end
        
        function set.TypeofCAN(obj,value)
            obj.TypeofCAN = value;
        end

        function set.MessageId(obj,value)
            if strcmp(obj.IdentifierType, 'Standard (11-bit identifier)') %#ok<MCSUP>
                msgIdLimit = hex2dec('7FF');
            else
                msgIdLimit = hex2dec('1FFFFFFF');
            end
            if obj.SetIdentifierType %#ok<MCSUP>
                validateattributes(value,...
                    {'numeric'},...
                    {'real','nonnegative','integer','scalar','<=',msgIdLimit},...
                    '', ...
                    'Message ID');
            end
            
            obj.MessageId = value;
        end
        
        function set.DeviceID(obj,value)
		    validateattributes(value, ...
                {'char'}, {'nonempty'}, '', 'CAN interface');
            obj.DeviceID = value;
        end
        
        function set.MsgLength(obj,value)
            validateattributes(value,...
                {'numeric'},...
                {'real','nonnegative','integer','scalar','<=',8},...
                '', ...
                'Message length');
            obj.MsgLength = value;
        end
    end
    
    methods(Access = protected)
        function setupImpl(obj)
            obj.PreviousData = zeros(1,8,'uint8');
            if coder.target('Rtw')
                coder.cinclude('MW_SocketCAN.h');
                canInterface = [obj.DeviceID 0];
                stat = int32(-1);
                isCANSetup = coder.nullcopy(int32(0));
                isCANSetup = coder.ceval('MW_checkIFStatus',coder.rref(canInterface));
                if obj.SetupCAN
                    cmd = getSetupIPLinkCmd(obj);
                    isRealCAN = uint8(strcmp(obj.TypeofCAN,'Real'));
                    coder.ceval('MW_loadCANModules',coder.const(isRealCAN));
                    coder.ceval('MW_setupCANLink',coder.rref(cmd),coder.const(isRealCAN));
                    status = getSetUpIPLinkStatus(obj);
                    if status==0
                        isCANSetup = int32(0);
                    else
                        errString0 = ['Cannot set ' obj.DeviceID newline 0];
                        coder.ceval('MW_printError',coder.rref(errString0));
                        isCANSetup = int32(-1);
                    end
                end
                if isCANSetup==int32(0)
                    stat = coder.ceval('MW_createSocket',coder.rref(canInterface),...
                        coder.rref(obj.sockHandleDataFrames));
                    stat = coder.ceval('MW_createSocket',coder.rref(canInterface),...
                        coder.rref(obj.sockHandleErrorFrames));
                elseif isCANSetup==int32(1)
                    errString1 = [obj.DeviceID ' is not up. Set up ' obj.DeviceID ' before launching the application.'  newline 0];
                    coder.ceval('MW_printError',coder.rref(errString1));
                elseif isCANSetup==int32(2)
                    errString2 = [obj.DeviceID ' does not exist. Select a valid CAN interface.' newline 0];
                    coder.ceval('MW_printError',coder.rref(errString2));
                else
                    errString3 = [obj.DeviceID ' is not set up' newline 0];
                    coder.ceval('MW_printError',coder.rref(errString3));
                end
                if stat==0
                    obj.Initialized = true;
                else
                    obj.Initialized = false;
                end
            end
        end
        
        function  varargout = stepImpl(obj)
            if coder.target('Rtw') && obj.Initialized
                rx = parsePacket(obj);
                if strcmp(obj.OutputDataType,'Raw data')
                    %Output as Raw data
                    varargout{1}     = uint8(rx.data(1:obj.MsgLength));
                    varargout{2}     = uint8(rx.status);

                    if obj.OutputError
                        varargout{3} = uint8(rx.error(1));
                    end

                    if obj.OutputRemote
                        varargout{4} = uint8(rx.rtr(1));
                    end
                    obj.PreviousData = rx.data;
                else
                    %Output as CAN Msg
                    varargout{1} = struct('Extended', uint8(0),...
                        'Length',   uint8(0),...
                        'Remote',   uint8(0),...
                        'Error',    uint8(0),...
                        'ID',       uint32(0),...
                        'Timestamp',0,...
                        'Data',     uint8(zeros(1,obj.MsgLength)')...
                        );

                    varargout{1}.Extended  = uint8(rx.extended);
                    varargout{1}.Length    = rx.dataLength;
                    varargout{1}.Remote    = uint8(rx.rtr);
                    varargout{1}.Error     = uint8(rx.error);
                    varargout{1}.ID        = uint32(rx.id);
                    varargout{1}.Timestamp = 0;
                    varargout{1}.Data      = uint8(rx.data(1:obj.MsgLength)');
                    varargout{2}           = uint8(rx.status);
                end
            else
                if strcmp(obj.OutputDataType,'Raw data')
                    varargout{1} = uint8(zeros(1,obj.MsgLength));
                    varargout{2} = uint8(0);
                    
                    if obj.OutputError
                        varargout{3} = uint8(0);
                    end
                    if obj.OutputRemote
                        varargout{4} = uint8(0);
                    end
                else
                    varargout{1}.Extended  = uint8(0);
                    varargout{1}.Length    = uint8(0);
                    varargout{1}.Remote    = uint8(0);
                    varargout{1}.Error     = uint8(0);
                    varargout{1}.ID        = uint32(0);
                    varargout{1}.Timestamp = 0;
                    varargout{1}.Data      = uint8(zeros(1,obj.MsgLength)');
                    varargout{2}           = uint8(0);
                end
            end
            
        end
        
        function releaseImpl(obj) 
            if coder.target('Rtw')
                coder.cinclude('MW_SocketCAN.h');
                if obj.Initialized
                    canInterface = [obj.DeviceID 0];
                    coder.ceval('MW_clearSocket',coder.wref(obj.sockHandleDataFrames),...
                        coder.rref(canInterface));
                    coder.ceval('MW_clearSocket',coder.wref(obj.sockHandleErrorFrames),...
                        coder.rref(canInterface));
                end
            end
        end

        
        function receivedFrame = parsePacket(obj)
            rxInterface = [obj.DeviceID 0];
            rxid       = uint32(0);
            error      = uint8(0);
            rxData     = zeros(1,8,'uint8');
            status     = uint8(0);
            remote     = uint8(0);
            extended   = uint8(0);
            dataLength = uint8(0);
            sockStatus = int32(0);
            if strcmp(obj.OutputDataType,'Raw data')
                if strcmp(obj.IdentifierType, 'Extended (29-bit identifier)')
                    extended = uint8(1);
                end
                rxid       = uint32(obj.MessageId);
                dataLength = uint8(obj.MsgLength);
                sockStatus = coder.ceval('MW_CAN_receiveRawSimulink',...
                    coder.rref(rxInterface),uint32(obj.MessageId),...
                    coder.wref(rxData(1)),uint8(dataLength),...
                    coder.wref(status),uint8(extended),...
                    coder.wref(remote),coder.wref(error),...
                    obj.sockHandleDataFrames,obj.sockHandleErrorFrames);
            else
                sockStatus = coder.ceval('MW_CAN_receiveCANMsg',...
                    coder.rref(rxInterface),...
                    coder.wref(rxid),coder.wref(rxData),...
                    coder.wref(dataLength),coder.wref(status),...
                    coder.wref(extended),coder.wref(remote),...
                    coder.wref(error),...
                    obj.sockHandleDataFrames,obj.sockHandleErrorFrames);
                if remote==uint8(0)
                    remote=uint8(1);
                else
                    remote=uint8(0);
                end
            end
            if (sockStatus~=0)
                obj.Initialized = false;
            end
            receivedFrame.id         = rxid;
            receivedFrame.rtr        = remote;
            receivedFrame.data       = rxData;
            receivedFrame.error      = error;
            receivedFrame.status     = status;
            receivedFrame.extended   = extended;
            receivedFrame.dataLength = dataLength;
            %Error
            %   bit 0 RXWAR:    Receive Error Warning Flag bit
            %   bit 1 RXEP:     Receive Error-Passive Flag bit
            %   bit 2 RX0OVR:   Receive Buffer Overflow Flag bit
        end

        function cmd = getSetupIPLinkCmd(obj)
            cmd1 = ['sudo touch MW_SocketCAN_Error_IPLink.txt ; ' ...
                'sudo truncate -s 0 MW_SocketCAN_Error_IPLink.txt ;' ...
                ' sudo chmod 777 MW_SocketCAN_Error_IPLink.txt ; sudo ip link set '];
            if strcmp(obj.TypeofCAN,'Real')
                bitRate = coder.nullcopy('10000000');
                len = coder.nullcopy(int32(0));
                len = coder.ceval('MW_bitrate',coder.rref(bitRate));
                cmd = [cmd1 obj.DeviceID ' up type can bitrate ' bitRate(1:len) ' 2>MW_SocketCAN_Error_IPLink.txt' 0];
            else
                cmd = [cmd1 obj.DeviceID ' up type vcan 2>MW_SocketCAN_Error_IPLink.txt' 0];
            end
        end
        
        function status = getSetUpIPLinkStatus(obj)
            fileID = fopen('MW_SocketCAN_Error_IPLink.txt','r');
            assert(fileID~=-1);
            tline = fgetl(fileID);
            fclose(fileID);
            if ischar(tline)
                if isempty(tline)
                    status=0;
                elseif contains(tline,'RTNETLINK answers: Device or resource busy')
                    status=checkBitRate(obj);
                elseif contains(tline,['Cannot find device "' obj.DeviceID '"'])
                    coder.ceval('MW_printError',tline);
                    status=3;
                else
                    coder.ceval('MW_printError',tline);
                    status = -1;
                end
            else
                status = 0;
            end
        end

        function status = checkBitRate(obj)
            cmd = ['sudo touch MW_SocketCAN_GetBitRate.txt ; ' ...
                'sudo truncate -s 0 MW_SocketCAN_GetBitRate.txt ; ' ...
                'sudo chmod 777 MW_SocketCAN_GetBitRate.txt ; ' ...
                'sudo ip -det link show ' obj.DeviceID ' | grep bitrate | ' ...
                'awk ' '''{print $2}''' ' >MW_SocketCAN_GetBitRate.txt' 0];
            coder.ceval('MW_executeCommand',coder.rref(cmd));
            fileID = fopen('MW_SocketCAN_GetBitRate.txt','r');
            assert(fileID~=-1);
            tline = fgetl(fileID);
            fclose(fileID);
            inpBitRate = coder.nullcopy('10000000');
            len = coder.nullcopy(int32(0));
            len = coder.ceval('MW_bitrate',coder.rref(inpBitRate));
            if ischar(tline)
                if(strcmp(tline,inpBitRate(1:len)))
                    status = 0;
                else
                    status = 1;
                    errString1 = [obj.DeviceID ' is already set up with ' tline newline 0];
                    coder.ceval('MW_printError',coder.rref(errString1));
                end
            else
                % File is empty indicating there is no bitrate assiciated
                % with the CAN interface
                errString2 = ['Error fetching bitrate for ' obj.DeviceID newline 0];
                coder.ceval('MW_printError',coder.rref(errString2));
                status = 2;
            end
            cmd1 = 'sudo rm -rf MW_SocketCAN_GetBitRate.txt';
            coder.ceval('MW_executeCommand',coder.rref(cmd1));
        end

        function flag = isInactivePropertyImpl(obj,propertyName)
            switch propertyName
                case {'MessageId','IdentifierType','MsgLength','OutputError','OutputRemote'}
                    if strcmp(obj.OutputDataType,'Raw data')
                        flag = false;
                    else
                        flag = true;
                    end
                case 'TypeofCAN'
                    flag = ~obj.SetupCAN;
                otherwise
                    flag = false;
            end
        end
        
        function num = getNumOutputsImpl(obj)
            num = 2;
            if strcmp(obj.OutputDataType,'Raw data')
                if obj.OutputError
                    num = num + 1;
                end
                if obj.OutputRemote
                    num = num + 1;
                end
            end
        end
        
        function varargout = isOutputComplexImpl(obj)
            for N = 1 : obj.getNumOutputsImpl
                varargout{N} = false;
            end
        end
        
        function varargout = isOutputFixedSizeImpl(obj)
            for N = 1 : obj.getNumOutputsImpl
                varargout{N} = true;
            end
        end
        
        function out = getNumInputsImpl(~)
            out = 0;
        end
        
        function varargout = getOutputSizeImpl(obj)
            N = 1;
            if strcmp(obj.OutputDataType,'Raw data')
                varargout{N} = [1 obj.MsgLength];           % Raw data
                N = N + 1;
                varargout{N} = [1 1];           % Status
                N = N + 1;
                if obj.OutputError
                    varargout{N} = [1 1];
                    N = N + 1;
                end
                if obj.OutputRemote
                    varargout{N} = [1 1];
                end
            else
                varargout{N} = [1 1];           % CAN Msg
                N = N + 1;
                varargout{N} = [1 1];           % Status
            end
        end
        
        function varargout = getOutputDataTypeImpl(obj)
            if strcmp(obj.OutputDataType,'Raw data')
                N = 1;
                varargout{N} = 'uint8';             %Raw data
                N = N + 1;
                varargout{N} = 'uint8';             % Status
                N = N + 1;
                
                if obj.OutputError
                    varargout{N} = 'uint8';
                    N = N + 1;
                end
                if obj.OutputRemote
                    varargout{N} = 'uint8';
                end
            else
                varargout{1} = "Bus: linuxCANMsg";
                varargout{2} = "uint8";
            end
        end
        
        function varargout = getOutputNamesImpl(obj)
            % Return output port names for System block
            N = 1;
            if strcmp(obj.OutputDataType,'Raw data')
                varargout{N} = 'Data';
                N = N + 1;
                varargout{N} = 'Status';
                N = N + 1;
                if obj.OutputError
                    varargout{N} = 'Error';
                    N = N + 1;
                end
                if obj.OutputRemote
                    varargout{N} = 'Remote';
                end
            else
                varargout{N} = 'CAN Msg';
                N = N + 1;
                varargout{N} = 'Status';
            end
        end
        
        function maskDisplayCmds = getMaskDisplayImpl(obj)
            outport_label = [];
            
            maskDisplayCmds = [ ...
                ['color(''white'');', newline]...                                     % Fix min and max x,y co-ordinates for autoscale mask units
                ['plot([100,100,100,100],[100,100,100,100]);',newline]...
                ['plot([0,0,0,0],[0,0,0,0]);',newline]...
                ['color(''blue'');',newline] ...                                     % Drawing mask layout of the block
                ['text(99, 92, ''' obj.Logo ''', ''horizontalAlignment'', ''right'');',newline] ...
                ['color(''black'');',newline] ...
                ];
            
            if strcmp(obj.OutputDataType,'Raw data')
                IDStr = ['Message ID: ',num2str(obj.MessageId)];
                maskDisplayCmds = [maskDisplayCmds,...
                    ['text(50,60,''\fontsize{12}\bfCAN Receive'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline], ...
                    ['text(50,40,''\fontsize{10}' IDStr ''',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline] ...
                    ];
            else
                maskDisplayCmds = [maskDisplayCmds,...
                    ['text(50,50,''\fontsize{12}\bfCAN Receive'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline], ...
                    ];
            end
            
            num = getNumOutputsImpl(obj);
            if num > 1
                outputs = cell(1,num);
                [outputs{1:num}] = getOutputNamesImpl(obj);
                for i = 1:num
                    outport_label = [outport_label 'port_label(''output'',' num2str(i) ',''' outputs{i} ''');' newline]; %#ok<AGROW>
                end
            end
            
            maskDisplayCmds = [maskDisplayCmds,...
                outport_label, ...
                ];
        end
    end
    
    
    methods(Static, Access=protected)
        function header = getHeaderImpl()
            MaskTitle = getString(message('linux:blockmask:CANReceiveMaskTitle'));
            MaskText = getString(message('linux:blockmask:CANReceiveMaskDescription'));
            header = matlab.system.display.Header(mfilename('class'),...
                'ShowSourceLink', false, ...
                'Title',MaskTitle, ...
                'Text', MaskText);
        end
        
        function sts = getSampleTimeImpl(obj)
            sts = getSampleTimeImpl@matlabshared.svd.BlockSampleTime(obj);
        end
        
        function groups = getPropertyGroupsImpl
            % Define section for properties in System block dialog box.
            DeviceIDProp = matlab.system.display.internal.Property(...
                'DeviceID','Description','CAN interface');
            SetupCANProp = matlab.system.display.internal.Property(...
                'SetupCAN','Description','Set up CAN interface');
            TypeofCANProp = matlab.system.display.internal.Property(...
                'TypeofCAN','Description','CAN interface type');
            OutputDataTypeProp = matlab.system.display.internal.Property(...
                'OutputDataType', 'Description', 'Data to be output as');
            IDProp = matlab.system.display.internal.Property(...
                'MessageId', 'Description', 'Message ID');
            IdentifierTypeProp = matlab.system.display.internal.Property(...
                'IdentifierType', 'Description', 'Identifier type');
            MessageLengthProp = matlab.system.display.internal.Property(...
                'MsgLength', 'Description', 'Message length');
            SampleTimeProp = matlab.system.display.internal.Property(...
                'SampleTime', 'Description', 'Sample time');
            
            
            OutputErrorProp = matlab.system.display.internal.Property(...
                'OutputError', 'Description', 'Output error');
            OutputRemoteProp = matlab.system.display.internal.Property(...
                'OutputRemote', 'Description', 'Output remote');
            
            
            paramGroup = matlab.system.display.Section(...
                'Title', 'Parameters', 'PropertyList', ...
                {DeviceIDProp,SetupCANProp,TypeofCANProp,OutputDataTypeProp,...
                IdentifierTypeProp,IDProp,MessageLengthProp,SampleTimeProp});
            
            outputPortsGroup = matlab.system.display.Section(...
                'Title', 'OutputPorts', 'PropertyList', ...
                {OutputErrorProp,OutputRemoteProp});
            
            groups = [paramGroup,outputPortsGroup];
        end
        
        function isVisible = showSimulateUsingImpl
            isVisible = false;
        end
    end
    
    methods (Hidden, Static)
        function name = getDescriptiveName()
            name = 'CAN Receive';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                % Update buildInfo
                rootDir = realtime.internal.getLinuxRoot();
                addIncludePaths(buildInfo, fullfile(rootDir, 'include'));
                addIncludePaths(buildInfo, fullfile(rootDir, 'src'));
                addIncludeFiles(buildInfo, 'MW_SocketCAN.h');
                addSourcePaths(buildInfo, fullfile(rootDir, 'src'));
                addSourceFiles(buildInfo, 'MW_SocketCAN.c', fullfile(rootDir, 'src'), 'BlockModules');
            end
        end
    end
    
end