classdef PanTiltHat < matlab.System & coder.ExternalDependency
    %
    % System object for PCA9685 PWM chip based Pan tilt.
    %
    
    % Copyright 2021-2023 The MathWorks, Inc.
    %#codegen
    %#ok<*EMCA>
    
    properties (Nontunable)
        Mode (1,:) char {matlab.system.mustBeMember(Mode,{'Pan and tilt', 'Pan', 'Tilt'})} = 'Pan and tilt';
        PWMFrequency (1,:) char {matlab.system.mustBeMember(PWMFrequency,{'25','50','75','100','125','150',...
            '175','200','225','250','275','300','325','350','375','400','425','450','475','500','525','550',...
            '575','600','625','650','675','700','725','750','775','800','825','850','875','900','925','950','975',...
            '1000','1025','1050','1075','1100','1125','1150','1175','1200','1225','1250','1275','1300','1325','1350',...
            '1375','1400','1425','1450','1475','1500','1525'})} = '50';
        PanServoChannel = 1;
        TiltServoChannel = 0;
        PanServoPulseDuration = [500e-6 2500e-6];
        TiltServoPulseDuration = [500e-6 2500e-6];
        SampleTime = 0.1;
        blockPlatform = 'LINUX';
    end
    
    properties (Nontunable, Hidden)
        IOProtocol;
        SimulinkIO = false;
        SLIOInfra;
    end

    properties(Hidden,SetAccess = protected)
        PanServo;
        TiltServo;
        PCA9865;
        FileBuffer;
        OpenErrorBuffer;
        WriteErrorBuffer;
        PWMFreq;
    end

    properties(Constant,Hidden)
         %For Connected IO
        SETUP_PANTILTHAT   = hex2dec('F124');
        STEP_PANTILTHAT    = hex2dec('F125');
        RELEASE_PANTILTHAT = hex2dec('F126');  
    end

    methods
        % Constructor
        function obj = PanTiltHat(varargin)
            coder.allowpcode('plain');
            obj.PCA9865 = codertarget.linux.blocks.PCA9685Base;
            setProperties(obj,nargin,varargin{:});
            
            % For connected IO: static buffers in C layer
            obj.FileBuffer = uint8(0);
            obj.OpenErrorBuffer = uint8(0);
            obj.WriteErrorBuffer = uint8(0);
        end

        function set.PanServoChannel(obj,value)
            validateattributes(value, {'numeric'},...
                {'real','nonnegative','integer','scalar','<=',obj.PCA9865.NChannels-1},'','Pan servo channel');
            obj.PanServoChannel = value;
        end

        function set.TiltServoChannel(obj,value)
            validateattributes(value, {'numeric'},...
                {'real','nonnegative','integer','scalar','<=',obj.PCA9865.NChannels-1},'','Tilt servo channel'); %#ok<*MCSUP> 
            obj.TiltServoChannel = value;
        end

        function set.PanServoPulseDuration(obj,value)
            validateattributes(value, {'numeric'},...
                {'real','nonnegative','positive','numel',2},'','Pan servo pulse duration'); 
            obj.PanServoPulseDuration = value;
        end

        function set.TiltServoPulseDuration(obj,value)
            validateattributes(value, {'numeric'},...
                {'real','nonnegative','positive','numel',2},'','Tilt servo pulse duration'); 
            obj.TiltServoPulseDuration = value;
        end

        function freq = get.PWMFreq(obj)
            freq = uint32(real(str2double(obj.PWMFrequency)));
        end

        function set.SampleTime(obj,sampleTime)
            coder.extrinsic('error');
            coder.extrinsic('message');

            validateattributes(sampleTime,{'numeric'},{'nonnan', 'finite','>',500e-6},...
                '','''Sample time''');
            
            % Sample time must be a real scalar value or 2 element array.
            if ~isreal(sampleTime(1)) || numel(sampleTime) > 2
                error(message('linux:utils:InvalidSampleTimeNeedScalar'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) > 0.0 && sampleTime(2) >= sampleTime(1)
                error(message('linux:utils:InvalidSampleTimeNeedSmallerOffset'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) == -1.0 && sampleTime(2) ~= 0.0
                error(message('linux:utils:InvalidSampleTimeNeedZeroOffset'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) == 0.0 && sampleTime(2) ~= 1.0
                error(message('linux:utils:InvalidSampleTimeNeedOffsetOne'));
            end
            obj.SampleTime = sampleTime;
        end

        function result = isEnabled(obj,mode)
            if contains(lower(obj.Mode),mode)
                result = true;
            else
                result = false;
            end
        end

        function pulsens = getPulseDurationNSFromAngle(obj,angle,panortilt)
            % Convert angular input value torequired pulse duration in nano
            % seconds based on the minimum and maximum thresholds given.
            % Ignore values outside [-90,90]. Note that validateInputs method
            % guarantees that degrees is a numeric scalar value
            min = int8(-90);
            max = int8(90);

            if angle < min
                angle = min;
            elseif angle > max
                angle = max;
            end

            angle = angle + 90; % converting to 0-180 range

            if matches(panortilt,'pan')
                pulseDiff = obj.PanServoPulseDuration(2) - obj.PanServoPulseDuration(1);
                pulsens = uint32( ((double(angle) * pulseDiff * 1e9)/ 180) + (obj.PanServoPulseDuration(1)*1e9));
            else
                pulseDiff = obj.TiltServoPulseDuration(2) - obj.TiltServoPulseDuration(1);
                pulsens = uint32( ((double(angle) * pulseDiff * 1e9)/ 180) + (obj.TiltServoPulseDuration(1)*1e9));
            end
        end

        function ex = getServerException(~,errno)
            if errno == -1
                ex = MException(message('linux:build:OpenKernelDeviceFileError', 'PCA9685 PWM'));
            else
                % -2
                ex = MException(message('linux:build:WriteKernelDeviceFileError', 'PCA9685 PWM'));
            end
        end

    end

    methods (Access=protected)
        %% Common functions
        
        function validatePropertiesImpl(obj)
            % Validate related or interdependent property values
            coder.extrinsic('message');
            if obj.isEnabled('pan') && obj.isEnabled('tilt') && (obj.PanServoChannel == obj.TiltServoChannel)
                error(message('linux:blockmask:ServoChannelConflict'));
            end
        end

        function setupImpl(obj)
            panInitPulse = obj.getPulseDurationNSFromAngle(int8(0),'pan');
            tiltInitPulse = obj.getPulseDurationNSFromAngle(int8(0),'tilt');
            if coder.target('Rtw')
                coder.cinclude('MW_i2c_pwm_pca9685.h');
                coder.ceval('i2c_pwm_pca9685_setup',uint8(obj.PanServoChannel), uint8(obj.TiltServoChannel), ...
                    uint8(obj.isEnabled('pan')), uint8(obj.isEnabled('tilt')), uint32(1e9/obj.PWMFreq), ...
                    uint32(panInitPulse), uint32(tiltInitPulse));
            elseif coder.target('MATLAB')
                obj.SimulinkIO = matlabshared.svd.internal.isSimulinkIoEnabled();
                if obj.SimulinkIO
                    %handle to deploy and connect to IO server                       
                    obj.SLIOInfra=matlabshared.ioclient.DeployAndConnectHandle;
                    %get a connected IOclient object
                    obj.SLIOInfra.getConnectedIOClient();
                    obj.IOProtocol = obj.SLIOInfra.IoProtocol;   
                    peripheralPayload = [uint8(obj.PanServoChannel), uint8(obj.TiltServoChannel), ...
                        uint8(obj.isEnabled('pan')), uint8(obj.isEnabled('tilt')), typecast(uint32(1e9/obj.PWMFreq),'uint8'), ...
                        typecast(uint32(panInitPulse),'uint8'), typecast(uint32(tiltInitPulse),'uint8')];
                    responsePeripheralPayloadSize = 4; %status
                    output = rawRead(obj.IOProtocol, obj.SETUP_PANTILTHAT, peripheralPayload, responsePeripheralPayloadSize);
                    status = typecast(uint8(output(1:4)),'int32');
                    if status ~=0
                        throwAsCaller(obj.getServerException(status))
                    end
                else
                    % Nothing for non-SL IO workflows
                end
            end
            
        end
        
        function stepImpl(obj,varargin)
            % Implement output.
            panPulse = uint32(0);
            tiltPulse = uint32(0);
            if (nargin == 3)
                panPulse = uint32(obj.getPulseDurationNSFromAngle(int8(varargin{1}),'pan'));
                tiltPulse = uint32(obj.getPulseDurationNSFromAngle(int8(varargin{2}),'tilt'));
            elseif (nargin == 2) && obj.isEnabled('pan')
                panPulse = uint32(obj.getPulseDurationNSFromAngle(int8(varargin{1}),'pan'));
            elseif (nargin == 2) && obj.isEnabled('tilt')
                tiltPulse = uint32(obj.getPulseDurationNSFromAngle(int8(varargin{1}),'tilt'));
            end

            if coder.target('Rtw')
                coder.ceval('i2c_pwm_pca9685_step',uint8(obj.PanServoChannel), uint8(obj.TiltServoChannel), ...
                    uint8(obj.isEnabled('pan')), uint8(obj.isEnabled('tilt')), panPulse, tiltPulse);
            elseif coder.target('MATLAB')
                if obj.SimulinkIO
                    peripheralPayload = [uint8(obj.PanServoChannel), uint8(obj.TiltServoChannel), ...
                        uint8(obj.isEnabled('pan')), uint8(obj.isEnabled('tilt')), typecast(uint32(panPulse),'uint8'), typecast(uint32(tiltPulse),'uint8')];
                    responsePeripheralPayloadSize = 4; %status
                    output = rawRead(obj.IOProtocol, obj.STEP_PANTILTHAT, peripheralPayload, responsePeripheralPayloadSize);
                    status = typecast(uint8(output(1:4)),'int32');
                    if status ~=0
                        throwAsCaller(obj.getServerException(status))
                    end
                else
                    % Nothing for non-SL IO workflows
                end
            end

        end
        
        function releaseImpl(obj)
            if coder.target('Rtw')
                coder.ceval('i2c_pwm_pca9685_terminate',uint8(obj.PanServoChannel), uint8(obj.TiltServoChannel), ...
                    uint8(obj.isEnabled('pan')), uint8(obj.isEnabled('tilt')));
            elseif coder.target('MATLAB')
                if obj.SimulinkIO
                    peripheralPayload = [uint8(obj.PanServoChannel), uint8(obj.TiltServoChannel), ...
                        uint8(obj.isEnabled('pan')), uint8(obj.isEnabled('tilt'))];
                    responsePeripheralPayloadSize = 4; %status
                    output = rawRead(obj.IOProtocol, obj.RELEASE_PANTILTHAT, peripheralPayload, responsePeripheralPayloadSize);
                    status = typecast(uint8(output(1:4)),'int32');
                    if status ~=0
                        throwAsCaller(obj.getServerException(status))
                    end
                else
                    % Nothing for non-SL IO workflows
                end
            end
        end
    end
    
    methods (Access=protected)
        %% Define output properties
        function num = getNumInputsImpl(obj)
            if strcmp(obj.Mode,'Pan and tilt')
                num = 2;
            else
                num = 1;
            end
        end
        
        function num = getNumOutputsImpl(~)
            num = 0;
        end
        
        function varargout = isOutputFixedSizeImpl(~,~)
            varargout{1} = true;
        end
        
        
        function varargout = isOutputComplexImpl(~)
            varargout{1} = false;
        end
        
        function varargout = getOutputSizeImpl(~)
            varargout{1} = [1,1];
        end

        function validateInputsImpl(obj, varargin)
            for i = 1 : obj.getNumInputsImpl
                validateattributes(varargin{i},{'numeric'},{'integer','>=',-90,'<=',90},'','Input angle value');
            end
        end

        function flag = isInactivePropertyImpl(obj,prop)
            % Return false if property is visible based on object
            % configuration, for the command line and System block dialog
            
            if contains(lower(prop),'pan')
                flag = ~obj.isEnabled('pan');
            elseif contains(lower(prop),'tilt')
                flag = ~obj.isEnabled('tilt');
            else
                flag = false;
            end
        end

        function maskDisplayCmds = getMaskDisplayImpl(obj)
            portLabel = [];
            switch obj.Mode
                case 'Pan and tilt'
                    portLabel = [portLabel, 'port_label(''input'',' num2str(1) ',''pan angle'');', newline];
                    portLabel = [portLabel, 'port_label(''input'',' num2str(2) ',''tilt angle'');', newline];
                case 'Pan'
                    portLabel = [portLabel, 'port_label(''input'',' num2str(1) ',''pan angle'');', newline];
                case 'Tilt'
                    portLabel = [portLabel, 'port_label(''input'',' num2str(1) ',''tilt angle'');', newline];
            end
            maskDisplayCmds = { ...
                ['color(''white'');', newline],...    % Fix min and max x,y co-ordinates for autoscale mask units
                ['plot([100,100,100,100],[100,100,100,100]);', newline],... % Drawing mask layout of the block
                ['plot([0,0,0,0],[0,0,0,0]);', newline],...
                ['color(''black'');', newline] ...
                ['text(60,50,''\fontsize{12}\bfPan Tilt Hat'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline], ...
                portLabel,...
                };

            labelSample = obj.blockPlatform;
            maskDisplayCmdsTarget = { ...
                ['color(''blue'');', newline],...
                ['text(120, 90, ''' labelSample ''', ''horizontalAlignment'', ''right'');', newline]};

            maskDisplayCmds = [maskDisplayCmds maskDisplayCmdsTarget];
        end
    end
    
    methods (Static, Access=protected)
        function simMode = getSimulateUsingImpl(~)
            simMode = 'Interpreted execution';
        end
        
        function isVisible = showSimulateUsingImpl
            isVisible = false;
        end
        
        function header = getHeaderImpl
            %getHeaderImpl Create mask header
            %   This only has an effect on the base mask.
            header = matlab.system.display.Header(mfilename('class'), ...
                'Title', getString(message('linux:blockmask:PanTiltHatMaskTitle')),'Text', ...
                getString(message('linux:blockmask:PanTiltHatMaskDescription')),'ShowSourceLink', false);
        end

        function groups = getPropertyGroupsImpl
            ModeProp = matlab.system.display.internal.Property('Mode', 'Description', 'linux:blockmask:ModeProp');
            PWMFrequencyProp = matlab.system.display.internal.Property('PWMFrequency', 'Description', 'linux:blockmask:PWMFrequencyProp');
            PanServoChannelProp = matlab.system.display.internal.Property('PanServoChannel', 'Description', 'linux:blockmask:ChannelProp');
            PanServoPulseDuration = matlab.system.display.internal.Property('PanServoPulseDuration', 'Description', 'linux:blockmask:PulseDurationProp');
            TiltServoChannelProp = matlab.system.display.internal.Property('TiltServoChannel', 'Description', 'linux:blockmask:ChannelProp');
            TiltServoPulseDuration = matlab.system.display.internal.Property('TiltServoPulseDuration', 'Description', 'linux:blockmask:PulseDurationProp');
            SampleTimeProp = matlab.system.display.internal.Property('SampleTime', 'Description', 'linux:blockmask:SampleTimeProp');
            BlockPlatformProp = matlab.system.display.internal.Property('blockPlatform', 'Description', 'linux:blockmask:BlockPlatformProp','IsGraphical',false);

            BasicGroup = matlab.system.display.Section('PropertyList',{ModeProp,PWMFrequencyProp},'Title','linux:blockmask:BasicGroupTitle');
            PanGroup = matlab.system.display.Section('PropertyList',{PanServoChannelProp,PanServoPulseDuration},'Title','linux:blockmask:PanGroupTitle');
            TiltGroup = matlab.system.display.Section('PropertyList',{TiltServoChannelProp,TiltServoPulseDuration},'Title','linux:blockmask:TiltGroupTitle');
            OtherGroup = matlab.system.display.Section('PropertyList',{SampleTimeProp,BlockPlatformProp});
            
            groups = [BasicGroup,PanGroup,TiltGroup,OtherGroup];
        end
    end
    
    methods (Static)
        function name = getDescriptiveName(~)
            name = 'Pan tilt hat';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                % Update buildInfo
                rootDir = realtime.internal.getLinuxRoot;
                addIncludePaths(buildInfo, fullfile(rootDir, 'include'));
                % Add the following when not in rapid-accel simulation
                systemTargetFile = get_param(buildInfo.ModelName,'SystemTargetFile');
                if isequal(systemTargetFile,'ert.tlc')
                    addSourceFiles(buildInfo,'MW_i2c_pwm_pca9685.c',fullfile(rootDir,'src'));
                end
                
            end
        end
    end
end

