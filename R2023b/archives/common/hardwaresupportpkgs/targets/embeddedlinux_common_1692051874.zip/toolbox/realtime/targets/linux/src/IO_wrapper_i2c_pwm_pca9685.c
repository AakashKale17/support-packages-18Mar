/**
 * @file IO_wrapper_i2c_pwm_pca9685.c
 *
 * Wraps around the C layer MW_i2c_pwm_pca9685.c to provide access to IO
 *
 * @copyright Copyright 2021 The MathWorks, Inc.
 *
 */

#include "IO_wrapper_i2c_pwm_pca9685.h"

void MW_I2C_PWM_PCA9685_Setup_IO_wrapper(uint8_T* payloadBufferRx,
                                     uint8_T* payloadBufferTx,
                                     uint16_T* peripheralDataSizeResponse) {

    uint8_T panChannel, tiltChannel, panEnabled, tiltEnabled;
    uint32_T period, panPulse, tiltPulse;
    int32_T status = 0;
    
    /* Get required inputs for setup function */
    uint16_T index = 0;
    memcpy(&panChannel, &payloadBufferRx[index], sizeof(panChannel));
    index += sizeof(panChannel);
    memcpy(&tiltChannel, &payloadBufferRx[index], sizeof(tiltChannel));
    index += sizeof(tiltChannel);
    memcpy(&panEnabled, &payloadBufferRx[index], sizeof(panEnabled));
    index += sizeof(panEnabled);
    memcpy(&tiltEnabled, &payloadBufferRx[index], sizeof(tiltEnabled));
    index += sizeof(tiltEnabled);
    memcpy(&period, &payloadBufferRx[index], sizeof(period));
    index += sizeof(period);
    memcpy(&panPulse, &payloadBufferRx[index], sizeof(panPulse));
    index += sizeof(panPulse);
    memcpy(&tiltPulse, &payloadBufferRx[index], sizeof(tiltPulse));
    
    status = i2c_pwm_pca9685_setup(panChannel, tiltChannel, panEnabled, tiltEnabled, period, panPulse, tiltPulse);
    
    /*Updating the TX buffer with status and  encoder_id*/
    memcpy(&payloadBufferTx[(*peripheralDataSizeResponse)], &status, sizeof(status));
    (*peripheralDataSizeResponse) += sizeof(status);
    
}


void MW_I2C_PWM_PCA9685_Read_IO_wrapper(uint8_T* payloadBufferRx,
                                    uint8_T* payloadBufferTx,
                                    uint16_T* peripheralDataSizeResponse) {

    uint8_T panChannel, tiltChannel, panEnabled, tiltEnabled;
    uint32_T panPulse, tiltPulse;
    int32_T status = 0;
    
    /* Get required inputs for setup function */
    uint16_T index = 0;
    memcpy(&panChannel, &payloadBufferRx[index], sizeof(panChannel));
    index += sizeof(panChannel);
    memcpy(&tiltChannel, &payloadBufferRx[index], sizeof(tiltChannel));
    index += sizeof(tiltChannel);
    memcpy(&panEnabled, &payloadBufferRx[index], sizeof(panEnabled));
    index += sizeof(panEnabled);
    memcpy(&tiltEnabled, &payloadBufferRx[index], sizeof(tiltEnabled));
    index += sizeof(tiltEnabled);
    memcpy(&panPulse, &payloadBufferRx[index], sizeof(panPulse));
    index += sizeof(panPulse);
    memcpy(&tiltPulse, &payloadBufferRx[index], sizeof(tiltPulse));
    
    status = i2c_pwm_pca9685_step(panChannel, tiltChannel, panEnabled, tiltEnabled, panPulse, tiltPulse);

    /* Updating the TX buffer with status and encoderPos */
    memcpy(&payloadBufferTx[(*peripheralDataSizeResponse)], &status, sizeof(status));
    (*peripheralDataSizeResponse) += sizeof(status);
}

void MW_I2C_PWM_PCA9685_Release_IO_wrapper(uint8_T* payloadBufferRx,
                                       uint8_T* payloadBufferTx,
                                       uint16_T* peripheralDataSizeResponse) {

    uint8_T panChannel, tiltChannel, panEnabled, tiltEnabled;
    int32_T status = 0;
    
    /* Get required inputs for setup function */
    uint16_T index = 0;
    memcpy(&panChannel, &payloadBufferRx[index], sizeof(panChannel));
    index += sizeof(panChannel);
    memcpy(&tiltChannel, &payloadBufferRx[index], sizeof(tiltChannel));
    index += sizeof(tiltChannel);
    memcpy(&panEnabled, &payloadBufferRx[index], sizeof(panEnabled));
    index += sizeof(panEnabled);
    memcpy(&tiltEnabled, &payloadBufferRx[index], sizeof(tiltEnabled));
    index += sizeof(tiltEnabled);
    
    status = i2c_pwm_pca9685_terminate(panChannel, tiltChannel, panEnabled, tiltEnabled);

    /* Updating the TX buffer with status */
    memcpy(&payloadBufferTx[(*peripheralDataSizeResponse)], &status, sizeof(status));
    (*peripheralDataSizeResponse) += sizeof(status);
}

/* EOF */
