classdef NanoMsgSend < matlab.System & ...
        coder.ExternalDependency
    % Send data to a transport layer using nanomsg-next-gen (NNG)
    
	% Copyright 2022 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCA>

    properties (Hidden, Access = private)
        NNGSHandle;
        NNGSHandleInitialized;
    end

    % Public, non-tunable properties
    properties (Nontunable)
        %Custom name
        CustomName = "testing";
        %Byte order
        ByteOrder = 'LittleEndian';
        %Block Platform
        blockPlatform = 'LINUX';
        % PrintDiagnosticMessages Print diagnostic messages
        PrintDiagnosticMessages (1, 1) logical = false;
    end

    properties (Dependent, Access=protected)
        ByteOrderEnum;
    end

    methods
        % Constructor
        function obj = NanoMsgSend(varargin)
            % Support name-value pair arguments when constructing object
            coder.allowpcode('plain');
            setProperties(obj,nargin,varargin{:})
        end

        function set.CustomName(obj, val)
            validateattributes(val, ...
                {'char'}, {'nonempty'}, '', 'Custom name');
            if(length(val) > 20)
                error(message('linux:blockmask:CharLenErr', 'Custom name', 20));
            end
            obj.CustomName = strtrim(val);
        end

        % false if little endian
        % true if big endian
        function ret = get.ByteOrderEnum(obj)
            if isequal(obj.ByteOrder, 'LittleEndian')
                ret = false;
            else
                ret = true;
            end
        end
    end

    methods (Access = protected)
        %% Common functions
        function setupImpl(obj)
            % Perform one-time calculations, such as computing constants
            if coder.target('Rtw')
                coder.cinclude('MW_NNG.h');
                
                obj.NNGSHandleInitialized = false;
				
                obj.NNGSHandle = coder.opaque('NNGSendData_t *','NULL','HeaderFile','MW_NNG.h');
                nullHandle = obj.NNGSHandle;
                obj.NNGSHandle = coder.ceval("MW_NNG_initSendSocket",cstr(obj.CustomName));
                if obj.NNGSHandle ~= nullHandle
                    obj.NNGSHandleInitialized = true;
                end

                if obj.PrintDiagnosticMessages
                    coder.updateBuildInfo('addDefines','PRINT_NNG_SEND_DEBUG');
                end
            end
        end

        function status = stepImpl(obj,u)
            % Implement algorithm. Calculate y as a function of input u and
            % discrete states.
            status = coder.nullcopy(uint8(0));
            if coder.target('Rtw')
                val = uint8(0);
                
                % Send in required byte format
                if obj.ByteOrderEnum
                    TxData = matlabshared.svd.ByteOrder.getSwappedBytes(u);
                else
                    TxData = matlabshared.svd.ByteOrder.concatenateBytes(u, 'uint8');
                end
                if obj.NNGSHandleInitialized
                    val = coder.ceval("MW_NNG_send",obj.NNGSHandle,coder.rref(TxData),uint32(numel(TxData)));
                end
                status = uint8(val);
            end
        end

        function releaseImpl(obj)
            if coder.target('Rtw')
                coder.ceval("MW_NNG_clearSendSocket",obj.NNGSHandle);
            end
        end

        %% Backup/restore functions
        function s = saveObjectImpl(obj)
            % Set properties in structure s to values in object obj

            % Set public properties and states
            s = saveObjectImpl@matlab.System(obj);

            % Set private and protected properties
            %s.myproperty = obj.myproperty;
        end

        function loadObjectImpl(obj,s,wasLocked)
            % Set properties in object obj to values in structure s

            % Set private and protected properties
            % obj.myproperty = s.myproperty; 

            % Set public properties and states
            loadObjectImpl@matlab.System(obj,s,wasLocked);
        end

        %% Simulink functions
        function flag = isInputSizeMutableImpl(obj,index)
            % Return false if input size cannot change
            % between calls to the System object
            flag = false;
        end

        function flag = isInactivePropertyImpl(obj,propertyName)
            flag = false;
        end
        
        function flag = isOutputComplexImpl(obj)
            flag = false;
        end
        
        function num = getNumOutputsImpl(obj)
            num = 1;
        end
        
        function dataType = getOutputDataTypeImpl(obj)%#ok
            dataType = 'uint8';
        end
        
        function out = getOutputSizeImpl(obj)%#ok
            out = [1,1];
        end
        
        function out = getNumInputsImpl(~)
            out = 1;
        end
        
        function validateInputsImpl(obj, data)
            % Run this always in Simulation
            if isempty(coder.target)
                validateattributes(data,{'numeric'},...
                        {'vector'},'','Data');
            end
        end
        
        function maskDisplayCmds = getMaskDisplayImpl(obj)
            
            maskDisplayCmds = [ ...
                ['color(''white'');', newline]...                                     % Fix min and max x,y co-ordinates for autoscale mask units
                ['plot([100,100,100,100],[100,100,100,100]);',newline]...
                ['plot([0,0,0,0],[0,0,0,0]);',newline]...
                ['color(''blue'');',newline] ...                                     % Drawing mask layout of the block
                ['text(99, 92, ''' obj.blockPlatform ''', ''horizontalAlignment'', ''right'');',newline] ...
                ['color(''black'');',newline] ...
                ['port_label(''output'',1,''Status'');', newline]...
                ];

            CustomURL = ['ipc:///tmp/', obj.CustomName, '.ipc'];
            maskDisplayCmds = [maskDisplayCmds,...
                ['text(50,50,''\fontsize{12}\bfNNG Send'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline...
                'text(50,20,''' CustomURL ''',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline, ...
                 ]];             
        end
    end

    methods (Static, Access = protected)
        %% Simulink customization functions
        function simMode = getSimulateUsingImpl
            % Return only allowed simulation mode in System block dialog
            simMode = 'Interpreted execution';
        end
        
        function isVisible = showSimulateUsingImpl
            isVisible = false;
        end

        function header = getHeaderImpl
            % Define header for the System block dialog box.
            header = matlab.system.display.Header(mfilename('class'), ...
                'Title', getString(message('linux:blockmask:NNGSendTitle')), 'Text', ...
                getString(message('linux:blockmask:NNGSendDescription')),'ShowSourceLink', false);
        end

        function group = getPropertyGroupsImpl
            % Define property section(s) for System block dialog
            customNameProp = matlab.system.display.internal.Property('CustomName', 'Description', 'linux:blockmask:NNGCustomNameProp');
            byteOrderProp = matlab.system.display.internal.Property('ByteOrder', 'Description', 'linux:blockmask:ByteOrderProp', 'IsGraphical', false);
            BlockPlatformProp = matlab.system.display.internal.Property('blockPlatform', 'Description', 'linux:blockmask:BlockPlatformProp','IsGraphical',false);
            requiredGroup = matlab.system.display.Section(...
                'Title', 'Parameters',...
                'PropertyList', {customNameProp, byteOrderProp, 'PrintDiagnosticMessages',BlockPlatformProp});
            group = requiredGroup;
        end
    end

     methods (Hidden, Static)
        function name = getDescriptiveName()
            name = 'NNG Send';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                % Update buildInfo
                rootDir = realtime.internal.getLinuxRoot();
                addIncludePaths(buildInfo, fullfile(rootDir, 'include'));
                addIncludePaths(buildInfo, fullfile(rootDir, 'src'));
                addIncludeFiles(buildInfo, 'MW_NNG.h');
                addSourcePaths(buildInfo, fullfile(rootDir, 'src'));
                addSourceFiles(buildInfo, 'MW_NNG.c', fullfile(rootDir, 'src'), 'BlockModules');
                codertarget.linux.remotebuild.addTargetSpecificLibs(buildInfo,'-lnng');

                codertarget.linux.remotebuild.addTargetSpecificLibs(buildInfo,'-latomic');
            end
        end
    end
end

%% Internal functions
function str = cstr(str)
str = [str(:).', char(0)];
end