classdef TCPSend < sharedlinux.TCPSend
                        
    % Send data via tcp
    % Generic LINUX block
    
    %#codegen
    %#ok<*EMCA>    
    properties (Nontunable)
        BlockPlatform = 'LINUX';
    end
    
    methods
        % Constructor
        function obj = TCPSend(varargin)
            %This would allow the code generation to proceed with the
            %p-files in the installed location of the support package.
            coder.allowpcode('plain');
            
            % Support name-value pair arguments when constructing the object.
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    methods (Access=protected)       
        function maskDisplayCmds = getMaskDisplayImpl(obj)
            maskDisplayCmdsShared = getMaskDisplayImpl@sharedlinux.TCPSend(obj);
            maskDisplayCmdsTarget = { ...
                ['color(''blue'');', newline],...
                ['text(145, 90, ''' obj.BlockPlatform ''', ''horizontalAlignment'', ''right'');', newline],...
                };
            maskDisplayCmds = [ maskDisplayCmdsShared, maskDisplayCmdsTarget];
        end
    end
    
    methods(Static, Access = protected)
        %% Simulink customization functions
        function groups = getPropertyGroupsImpl(~)
            groups = getPropertyGroupsImpl@sharedlinux.TCPSend();
            blockPlatformProp = matlab.system.display.internal.Property('BlockPlatform', 'Description', 'Block Platform','IsGraphical', false);
            groups(2).Sections.PropertyList{end+1} = blockPlatformProp;
        end
    end
    
    methods (Static)
        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                updateBuildInfo@sharedlinux.TCPSend(buildInfo, context);
            end
        end
    end

end
