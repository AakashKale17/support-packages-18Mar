/* Copyright 2012-2020 The MathWorks, Inc. */
#ifndef _MW_GPIO_H_
#define _MW_GPIO_H_

#include "rtwtypes.h"

#ifdef __cplusplus
extern "C" {
#endif

#if (defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER))
/* This will be used in Rapid Accelerator Mode */
#define EXT_GPIO_init(gpio, direction)  (0)
#define EXT_GPIO_terminate(gpio)        (0)
#define EXT_GPIO_read(gpio,value)       (0)
#define EXT_GPIO_write(gpio, value)     (0)
    
#else
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>    
    
/* Local defines */
#define SYSFS_GPIO_DIR          "/sys/class/gpio"
#define GPIO_MAX_BUF            (128)
#define GPIO_DIRECTION_INPUT    (0)  
#define GPIO_DIRECTION_OUTPUT   (1)
#define GPIO_DIRECTION_NA       (255)
#ifdef _DEBUG
#define LOG_PRINT(fd, format, ...) fprintf(fd, format, __VA_ARGS__); fflush(fd)
#else 
#define LOG_PRINT(fd, msg, ...)
#endif     

    
/* Error codes */
#define ERR_GPIO_BASE               (2000)
#define ERR_GPIO_INIT_EXPORT        (ERR_GPIO_BASE+1)
#define ERR_GPIO_INIT_DIRECTION     (ERR_GPIO_BASE+2)
#define ERR_GPIO_INIT_OPEN          (ERR_GPIO_BASE+3)
#define ERR_GPIO_INIT_UNEXPORT      (ERR_GPIO_BASE+4)
#define ERR_GPIO_TERMINATE_UNEXPORT (ERR_GPIO_BASE+5)
#define ERR_GPIO_READ_READ          (ERR_GPIO_BASE+6)
#define ERR_GPIO_WRITE_WRITE        (ERR_GPIO_BASE+7)
#define ERR_GPIO_GET_DIRECTION_OPEN (ERR_GPIO_BASE+8)
#define ERR_GPIO_GET_DIRECTION_READ (ERR_GPIO_BASE+9)

/* Function declarations */
int EXT_GPIO_init(const unsigned int gpio, const uint8_T direction);
int EXT_GPIO_terminate(const unsigned int gpio);
int EXT_GPIO_read(const unsigned int gpio, boolean_T *value);
int EXT_GPIO_write(const unsigned int gpio, const boolean_T value);
int EXT_GPIO_getStatus(const unsigned int gpio, uint8_T *pinStatus);

/*Type declarations*/
typedef struct {
    uint32_T pin;               // Pin number
    int fd;                     // File descriptor for the GPIO pin
    boolean_T direction;        // Input or output
} GPIO_info;

#endif

#ifdef __cplusplus
}
#endif
#endif

