classdef HTTPClient < matlab.System & coder.ExternalDependency
    % HTTP Client block
    %
    
    % Copyright 2023 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    
    properties (Nontunable)
        % Block Platform
        blockPlatform = 'LINUX';

        % Request Method
        RequestMethod(1, :) char {matlab.system.mustBeMember(RequestMethod, {'GET', 'POST', 'PUT'})} = 'GET';

        % Content Type
        ContentType(1, :) char {matlab.system.mustBeMember(ContentType, {'application/json', 'text/plain'})} = 'application/json';
        
        % Accept
        Accept(1, :) char {matlab.system.mustBeMember(Accept, {'application/json', 'text/plain'})} = 'application/json';

        % Number of custom header
        NumCustomHeader(1, :) char {matlab.system.mustBeMember(NumCustomHeader, {'0', '1', '2', '3'})} = '0';

        % Update Interval
        UpdateInterval(1,1) {mustBePositive, mustBeFloat, mustBeFinite} = 2;

        % Max Length of the output Message
        MessageLength(1,1) {mustBePositive, mustBeInteger} = 256;

        % Custom Header Key 1
        CustomHeaderKey1(1,:) char {mustBeTextScalar,mustBeValidHttpHeaderKey(CustomHeaderKey1)} = '';
        % Custom Header value 1
        CustomHeaderVal1(1,:) char {mustBeTextScalar,mustBeValidHttpHeaderValue(CustomHeaderVal1)} = '';

        % Custom Header Key 2
        CustomHeaderKey2(1,:) char {mustBeTextScalar,mustBeValidHttpHeaderKey(CustomHeaderKey2)} = '';
        % Custom Header value 2
        CustomHeaderVal2(1,:) char {mustBeTextScalar,mustBeValidHttpHeaderValue(CustomHeaderVal2)} = '';

        % Custom Header Key 3
        CustomHeaderKey3(1,:) char {mustBeTextScalar,mustBeValidHttpHeaderKey(CustomHeaderKey3)} = '';
        % Custom Header value 3
        CustomHeaderVal3(1,:) char {mustBeTextScalar,mustBeValidHttpHeaderValue(CustomHeaderVal3)} = '';
    end

    properties (Hidden)
        LastUpdateTime = uint32(0);
        lastresponse;
    end
    
    % Pre-computed constants
    properties(Hidden, Access = private)
        ClientHandle;
    end
    
    properties (Nontunable)
        % Block has input
        hasBlockInput (1, 1) logical = false;

        % Block has output
        hasBlockOutput (1, 1) logical = true;

        % Block prints diagnostic messages
        PrintDiagnosticMessages (1, 1) logical = false;
    end
       
    properties(Constant)
        %Buffer size for error message
        ErrorMessageBufferSize = 64;
    end
    
    methods
        % Constructor
        function obj = HTTPClient(varargin)
            %This would allow the code generation to proceed with the
            %p-files in the installed location of the support package.
            coder.allowpcode('plain');
            
            % Support name-Value pair arguments when constructing the object.
            setProperties(obj,nargin,varargin{:});
        end
    end
    
    
    methods (Access = protected)
        % Common functions
        function setupImpl(obj,~)
            coder.cinclude('MW_HttpClient.h');
            % Implement tasks that need to be performed only once,
            % such as pre-computed constants.
            if coder.target('Rtw')
                %coder.ceval('MW_HTTPClientSetup');
                if ~obj.hasBlockOutput
                    obj.MessageLength = obj.ErrorMessageBufferSize;
                end
                obj.lastresponse = uint8(zeros(1,obj.MessageLength));
                coder.ceval('MW_HttpClient_init'); 
                obj.ClientHandle = coder.opaque('HTTPReadData_t *','NULL','HeaderFile','MW_HttpClient.h');
                obj.ClientHandle = coder.ceval('MW_HttpClient_getHandle',obj.PrintDiagnosticMessages);
            end
        end
        
        function validateInputsImpl(obj,varargin)
            validateattributes(varargin{1},{'uint8'}, ...
                    {'vector','nonnan', 'finite'}, '', 'URL');
            if isequal(obj.hasBlockInput,true)
                    validateattributes(varargin{2},{'uint8'}, ...
                    {'vector','nonnan', 'finite'}, '', 'Payload');
            end
        end
        
        function varargout=stepImpl(obj,varargin)
            response = uint8(zeros(1,obj.MessageLength));
            urlArr = uint8([varargin{1} 0]);
            contentType=uint8([obj.ContentType 0]);
            accept = uint8([obj.Accept 0]);
            requestMethod = uint8([obj.RequestMethod 0]);
            header1key = uint8([obj.CustomHeaderKey1 0]);
            header1value = uint8([obj.CustomHeaderVal1 0]);
            header2key = uint8([obj.CustomHeaderKey2 0]);
            header2value = uint8([obj.CustomHeaderVal2 0]);
            header3key = uint8([obj.CustomHeaderKey3 0]);
            header3value = uint8([obj.CustomHeaderVal3 0]);
            if length(varargin)>1
                body=uint8([varargin{2} 0]);
            else
                body=uint8(0);
            end
            varargout{1} = uint8(0);
            dataLength = uint32(0);

            switch obj.NumCustomHeader
                case '0'
                    numCustomHeader = uint8(0);
                case '1'
                    numCustomHeader = uint8(1);
                case '2'
                    numCustomHeader = uint8(2);
                case '3'
                    numCustomHeader = uint8(3);
            end
            
            if coder.target('Rtw')
                currentTime = coder.nullcopy(uint32(0));
                currentTime = coder.ceval('MW_getCurrentTimeInMillisHttp');
                if (obj.LastUpdateTime == uint32(0)) || ((currentTime - obj.LastUpdateTime) >= (1000*obj.UpdateInterval))
                    obj.LastUpdateTime = currentTime;
                obj.ClientHandle = coder.opaque('HTTPReadData_t *','NULL','HeaderFile','MW_HttpClient.h');
                obj.ClientHandle = coder.ceval('MW_HttpClient_getHandle',obj.PrintDiagnosticMessages);
                varargout{1} = coder.ceval('MW_HttpClient_step', obj.ClientHandle, coder.rref(requestMethod), coder.rref(urlArr),...
                    obj.hasBlockInput, obj.hasBlockOutput,coder.rref(body), coder.rref(contentType),coder.rref(accept),...
                    uint32(obj.MessageLength), coder.wref(response), coder.wref(dataLength),...
                    numCustomHeader, coder.rref(header1key), coder.rref(header1value), ...
                    coder.rref(header2key), coder.rref(header2value),...
                    coder.rref(header3key), coder.rref(header3value));
                    obj.lastresponse = response;
                    varargout{2} = response;
                else
                    varargout{1} = uint8(2);
                    varargout{2} = obj.lastresponse;
                end
                if obj.hasBlockOutput
                    varargout{3} = dataLength;
                end
            else
                varargout{1} = uint8(0);
                if ~obj.hasBlockOutput
                    varargout{2} = uint8(zeros(1,obj.ErrorMessageBufferSize));
                else
                    varargout{2} = uint8(zeros(1,obj.MessageLength));
                end
                if obj.hasBlockOutput
                    varargout{3} = uint32(0);
                end
            end
        end
        
        function releaseImpl(obj)
            if coder.target('Rtw')
                coder.ceval('MW_HttpClient_terminate',obj.ClientHandle);
            end
        end

        function flag = isInactivePropertyImpl(obj,prop)
            % Return false if property is visible based on object 
            % configuration, for the command line and System block dialog
            flag = false;
            if matches(prop, 'ContentType')
                flag = ~obj.hasBlockInput; % || obj.hasImageInput;
            end
            if matches(prop, 'Accept') || matches(prop, 'MessageLength') || matches(prop, 'retainLastResponse')
                flag = ~obj.hasBlockOutput;
            end
            if matches(prop, 'CustomHeaderKey1') || matches(prop, 'CustomHeaderVal1')
                flag = matches(obj.NumCustomHeader, '0');
            end
            if matches(prop, 'CustomHeaderKey2') || matches(prop, 'CustomHeaderVal2')
                flag = matches(obj.NumCustomHeader, '0') || ...
                    matches(obj.NumCustomHeader, '1');
            end
            if matches(prop, 'CustomHeaderKey3') || matches(prop, 'CustomHeaderVal3')
                flag = matches(obj.NumCustomHeader, '0') || ...
                    matches(obj.NumCustomHeader, '1') || ...
                    matches(obj.NumCustomHeader, '2');
            end
        end

        function maskDisplayCmds = getMaskDisplayImpl(obj)
            iconStr = getString(message('linux:blockmask:HTTPClientBlockName'));
            maskDisplayCmds = { ...
                ['color(''white'');', newline],...    % Fix min and max x,y co-ordinates for autoscale mask units
                ['plot([100,100,100,100],[100,100,100,100]);', newline],... % Drawing mask layout of the block
                ['plot([0,0,0,0],[0,0,0,0]);', newline],...
                ['color(''black'');', newline] ...
                ['text(48, 50,''' iconStr ''', ''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline],...
                ['text(50, 12,''' obj.RequestMethod ''', ''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline]...
                };

            maskDisplayCmdsTarget = { ...
                ['color(''blue'');', newline],...
                ...%['text(28, 92, ','''',obj.blockPlatform,'''',',''horizontalAlignment'', ''right'');',newline],...
                ['text(99, 92, ''' obj.blockPlatform ''', ''horizontalAlignment'', ''right'');', newline]...
                ['color(''black'');', newline] ...
                };
            InputNames = 'port_label(''input'', 1, ''URL'');';
            if isequal(obj.hasBlockInput,true)
                InputNames = [InputNames 'port_label(''input'', 2, ''Payload'');' newline];
            end
            OutputNames = '';
            if obj.hasBlockOutput
                OutputNames = [OutputNames 'port_label(''output'', 1, ''Status'');' newline];
                OutputNames = [OutputNames 'port_label(''output'', 2, ''Response'');' newline];
                OutputNames = [OutputNames 'port_label(''output'', 3, ''Data Size'');' newline];
            else
                OutputNames = [OutputNames 'port_label(''output'', 1, ''Status'');' newline];
                OutputNames = [OutputNames 'port_label(''output'', 2, ''Error'');' newline];
            end
            
            maskDisplayCmds = [maskDisplayCmds, maskDisplayCmdsTarget InputNames OutputNames];
        end        
        
        function N = getNumInputsImpl(obj)
            % Specify number of System inputs
            if isequal(obj.hasBlockInput,false)
                N = 1;
            else
                N = 2;
            end
        end
        
        function N = getNumOutputsImpl(obj)
            % Specify number of System outputs
            if isequal(obj.hasBlockOutput,false)
                N = 2;
            else
                N = 3;
            end
        end
        
        function varargout = getOutputSizeImpl(obj)
            varargout{1} = [1,1];
            if obj.hasBlockOutput
                varargout{2} = [1 obj.MessageLength];
                varargout{3} = [1,1];
            else
                varargout{2} = [1 64];
            end
             
        end
        
        function varargout = getOutputDataTypeImpl(obj)
            varargout{1} = 'uint8';
            varargout{2} = 'uint8';
            if obj.hasBlockOutput
                varargout{3} = 'uint32';
            end
        end

        function varargout = isOutputFixedSizeImpl(obj,~)
            varargout{1} = true;
            varargout{2} = true;
            if obj.hasBlockOutput
                varargout{3} = true;
            end
        end

        function varargout = isOutputComplexImpl (obj,~)
            varargout{1}=false;
            varargout{2}=false;
            if obj.hasBlockOutput
                varargout{3} = false;
            end
        end

        function flag = isInputSizeMutableImpl(~,~)
            flag = false;
        end
        
    end
    
    methods(Static, Access = protected)
        % Simulink customization functions
        function header = getHeaderImpl(~)
            % Define header for the System block dialog box.
            header = matlab.system.display.Header(mfilename('class'), ...
                'ShowSourceLink', false, ...
                'Title', 'linux:blockmask:HTTPClientBlockName', ...
                'Text', 'linux:blockmask:HTTPClientBlockDescription');
        end

        function groups = getPropertyGroupsImpl
            % Define property section(s) for System block dialog
            RequestMethodProp = matlab.system.display.internal.Property('RequestMethod','Description','linux:blockmask:HTTPRequestMethodProp');
            ContentTypeProp = matlab.system.display.internal.Property('ContentType','Description', 'linux:blockmask:HTTPContentTypeProp');
            AcceptProp = matlab.system.display.internal.Property('Accept','Description', 'linux:blockmask:HTTPAcceptProp');
            NumCustomHeaderProp = matlab.system.display.internal.Property('NumCustomHeader','Description', 'linux:blockmask:HTTPNumHeadersProp');
            UpdateIntervalProp = matlab.system.display.internal.Property('UpdateInterval','Description', 'linux:blockmask:HTTPUpdateIntervalProp');
            MessageLengthProp = matlab.system.display.internal.Property('MessageLength','Description', 'linux:blockmask:HTTPMaxOutputLengthProp');
            CustomHeaderKey1Prop = matlab.system.display.internal.Property('CustomHeaderKey1','Description', 'linux:blockmask:HTTPHeaderKeyProp');
            CustomHeaderVal1Prop = matlab.system.display.internal.Property('CustomHeaderVal1','Description', 'linux:blockmask:HTTPHeaderValueProp','Row', matlab.system.display.internal.Row.current);
            CustomHeaderKey2Prop = matlab.system.display.internal.Property('CustomHeaderKey2','Description', 'linux:blockmask:HTTPHeaderKeyProp');
            CustomHeaderVal2Prop = matlab.system.display.internal.Property('CustomHeaderVal2','Description', 'linux:blockmask:HTTPHeaderValueProp','Row', matlab.system.display.internal.Row.current);
            CustomHeaderKey3Prop = matlab.system.display.internal.Property('CustomHeaderKey3','Description', 'linux:blockmask:HTTPHeaderKeyProp');
            CustomHeaderVal3Prop = matlab.system.display.internal.Property('CustomHeaderVal3','Description', 'linux:blockmask:HTTPHeaderValueProp','Row', matlab.system.display.internal.Row.current);

            hasBlockInputProp = matlab.system.display.internal.Property('hasBlockInput','Description', 'linux:blockmask:HTTPHasPayloadInputProp');
            hasBlockOutputProp = matlab.system.display.internal.Property('hasBlockOutput','Description', 'linux:blockmask:HTTPHasResponseOutputProp');
            PrintDiagnosticMessagesProp = matlab.system.display.internal.Property('PrintDiagnosticMessages','Description', 'linux:blockmask:HTTPrintDiagnosticMessagesProp');

            genericGroup = matlab.system.display.Section(...
                'PropertyList',{RequestMethodProp, UpdateIntervalProp});

            inputGroup = matlab.system.display.Section(...
                'Title', 'linux:blockmask:HTTPInputGroupTitle', ...
                'PropertyList',{hasBlockInputProp, ContentTypeProp});
            outputGroup = matlab.system.display.Section(...
                'Title', 'linux:blockmask:HTTPOutputGroupTitle', ...
                'PropertyList', {hasBlockOutputProp, MessageLengthProp, AcceptProp});
            customHeaderGroup = matlab.system.display.Section(...
                'Title', 'linux:blockmask:HTTPCustomHeaderGroupTitle', ...
                'PropertyList', {NumCustomHeaderProp, CustomHeaderKey1Prop, CustomHeaderVal1Prop, ...
                CustomHeaderKey2Prop, CustomHeaderVal2Prop, ...
                CustomHeaderKey3Prop, CustomHeaderVal3Prop}); 
            diagnosticsGroup = matlab.system.display.Section(...
                'Title', 'linux:blockmask:HTTPDiagnosticsGroupTitle', ...
                'PropertyList', {PrintDiagnosticMessagesProp});

            mainTab = matlab.system.display.SectionGroup(...
                'Title', 'linux:blockmask:HTTPMainTabTItle', ...
                'Sections',[genericGroup, inputGroup, outputGroup, diagnosticsGroup],...
                'Type',matlab.system.display.SectionType.tab);
            advanceTab = matlab.system.display.SectionGroup(...
                'Title', 'linux:blockmask:HTTPAdvancedTabTitle', ...
                'Sections',customHeaderGroup,...
                'Type',matlab.system.display.SectionType.tab);
            groups = [mainTab, advanceTab];
            
        end
        
        function simMode = getSimulateUsingImpl
            % Return only allowed simulation mode in System block dialog
            simMode = 'Interpreted execution';
        end
        
        function isVisible = showSimulateUsingImpl
            isVisible = false;
        end
        
    end
    
    methods (Static)
        function name = getDescriptiveName()
            name = 'HTTP Client';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                % Update buildInfo
                rootDir = realtime.internal.getLinuxRoot();
                addIncludePaths(buildInfo, fullfile(rootDir, 'include'));
                addIncludePaths(buildInfo, fullfile(rootDir, 'src'));
                addIncludeFiles(buildInfo, 'MW_HttpClient.h');
                addSourcePaths(buildInfo, fullfile(rootDir, 'src'));
                systemTargetFile = get_param(buildInfo.ModelName,'SystemTargetFile');
                if isequal(systemTargetFile,'ert.tlc')
                    % Add the following when not in rapid-accel simulation
                    buildInfo.addSourceFiles('MW_HttpClient.c',fullfile(rootDir,'src'));
                    codertarget.linux.remotebuild.addTargetSpecificLibs(buildInfo,'-lcurl');
                    codertarget.linux.remotebuild.addTargetSpecificLibs(buildInfo,'-ljson-c');
                end
            end
        end
    end
end

function mustBeValidHttpHeaderKey(key)
    coder.extrinsic("regexp");
    coder.extrinsic("throwAsCaller");
    coder.extrinsic("MException");
    coder.extrinsic("message");
    supportedSpecialChars = '''_'', ''-''';
    key_expression = '[^a-zA-Z_0-9\-]';
    if ~isempty(regexp(key,key_expression,'match'))
        throwAsCaller(MException(message('linux:blockmask:HTTPInvalidHeader', 'Key', supportedSpecialChars)));
    end
end

function mustBeValidHttpHeaderValue(key)
    coder.extrinsic("regexp");
    coder.extrinsic("throwAsCaller");
    coder.extrinsic("MException");
    coder.extrinsic("message");
    supportedChars = ['''_'', '' '', '':'', '';'', ''.'', '','', ''/'', ''"'', '''''', ''?'', ''!'', ''('', '')'', ''{'', ''}'', ' ...
    '''['', '']'', ''@'', ''<'', ''>'', ''='', ''+'', ''*'', ''#'', ''$'', ''&'', ''`'', ''|'', ''~'', ''^'', ''%'', ''-'', ''\'''];
    value_expression = '[^a-zA-Z0-9_ :;.,/"''?!(){}[]@<>=+*#$&`|~^%\-\\]';
    if ~isempty(regexp(key,value_expression,'match'))
        throwAsCaller(MException(message('linux:blockmask:HTTPInvalidHeader', 'Value', supportedChars)));
    end
end

%% Internal functions
function str = cstr(str)
str = [str(:).', char(0)];
end