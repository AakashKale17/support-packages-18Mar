classdef I2CMasterRead < matlabshared.svd.I2CMasterRead ...
        & coder.ExternalDependency
    %I2CMasterRead Read data from an I2C slave device or an I2C slave device register.
    %
    %The block outputs the values received as an 1-D uint8 array.
    %
    % Copyright 2020 The MathWorks, Inc.
    %#codegen
    properties (Nontunable)
        %I2CModule I2C module
        I2CModule = '0';
    end
    
    methods
        function obj = I2CMasterRead(varargin)
            obj.Logo = 'LINUX';
        end
    end
       
    methods (Static)
        function name = getDescriptiveName(~)
            name = 'I2C Master Read';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context) %#ok<INUSD>
        end
    end
end
%[EOF]
