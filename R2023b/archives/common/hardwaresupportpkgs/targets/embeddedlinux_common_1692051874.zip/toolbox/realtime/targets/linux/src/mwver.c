#include <stdio.h>
#include <stdlib.h>

/*#define MW_STACK_VER (1.00)*/

int main(int argc, char *argv[])
{
    /* Print stack version to stdout */
    fprintf(stdout, "%1.2f\n", MW_STACK_VER);

    return 0;
}
