classdef (StrictDefaults)DigitalWrite < matlab.System & ...
        coder.ExternalDependency
    %
    % Set the logical state of a digital output pin.
    %
    
    % Copyright 2016-2022 The MathWorks, Inc.
    %#codegen
    %#ok<*EMCA>
    
    properties (Nontunable)
        PinNumber = 17
    end
    
    properties (Nontunable, Hidden)
        IOProtocol
        DigitalIOClient
        SimulinkIO = false
        SLIOInfra
    end
    
    properties (Constant, Hidden)
        % Error IDs
        GPIO_CONFIG_FAILURE  = 2002
        GPIO_WRITE_FAILURE   = 2007
        GPIO_RELEASE_FAILURE = 2005
    end
    
    methods
        % Constructor
        function obj = DigitalWrite(varargin)
            coder.allowpcode('plain');
            setProperties(obj,nargin,varargin{:});
        end
        
        function set.PinNumber(obj,value)
            % https://www.kernel.org/doc/Documentation/gpio/gpio-legacy.txt
            validateattributes(value,...
                {'numeric'},...
                {'real','nonnegative','integer','scalar'},...
                '', ...
                'PinNumber');
            obj.PinNumber = value;
        end
    end
    
    methods (Access=protected)
        function setupImpl(obj)
            % Does nothing in code generation
            if coder.target('Rtw')
                coder.cinclude('MW_gpio.h');
                % void MW_gpioInit(const uint32_T pin, const boolean_T direction)
                coder.ceval('EXT_GPIO_init',uint32(obj.PinNumber),true);
            elseif coder.target('MATLAB')
                obj.SimulinkIO = matlabshared.svd.internal.isSimulinkIoEnabled();
                if obj.SimulinkIO
                    %handle to deploy and connect to IO server
                    obj.SLIOInfra=matlabshared.ioclient.DeployAndConnectHandle;
                    %get a connected IOclient object
                    obj.SLIOInfra.getConnectedIOClient();
                    obj.IOProtocol = obj.SLIOInfra.IoProtocol;
                    obj.DigitalIOClient = matlabshared.ioclient.peripherals.DigitalIO;
                    status = obj.DigitalIOClient.configureDigitalPinInternal(obj.IOProtocol,uint32(obj.PinNumber),'DigitalOutput');
                    if status ~=0
                        throwAsCaller(MException(message(['raspi:server:ERRNO', num2str(obj.GPIO_CONFIG_FAILURE)])));
                    end
                else
                    % Nothing for non-SL IO workflows
                end
            end
        end
        
        function stepImpl(obj,u)
            if coder.target('Rtw')
                % void MW_gpioWrite(const uint32_T pin, const boolean_T value)
                coder.ceval('EXT_GPIO_write',uint32(obj.PinNumber),uint8(u));
            elseif coder.target('MATLAB')
                if obj.SimulinkIO
                    status = obj.DigitalIOClient.writeDigitalPinInternal(obj.IOProtocol,uint32(obj.PinNumber),uint8(u));
                    if status~=0
                        throwAsCaller(MException(message(['raspi:server:ERRNO', num2str(obj.GPIO_WRITE_FAILURE)])));
                    end
                end
            end
            
        end
        
        function releaseImpl(obj)
            if coder.target('Rtw')
                % void MW_gpioTerminate(const uint32_T pin)
                coder.ceval('EXT_GPIO_terminate',uint32(obj.PinNumber));
            elseif coder.target('MATLAB')
                if obj.SimulinkIO
                    status = obj.DigitalIOClient.unconfigureDigitalPinInternal(obj.IOProtocol,uint32(obj.PinNumber));
                    obj.SLIOInfra.deleteConnectedIOClient(); % Remove the IOProtocol object key
                    if status ~=0
                        throwAsCaller(MException(message(['raspi:server:ERRNO', num2str(obj.GPIO_RELEASE_FAILURE)])));
                    end
                end
            end
            
        end
    end
    
    methods (Access=protected)
        %% Define input properties
        function num = getNumInputsImpl(~)
            num = 1;
        end
        
        function num = getNumOutputsImpl(~)
            num = 0;
        end
        
        
        
        function validateInputsImpl(~, u)
            if isempty(coder.target)
                % Actually the input validation should be the following:
                validateattributes(u,{'numeric','logical'},{'scalar','binary'},'','u');
            end
        end
        
        function icon = getIconImpl(~)
            % Define a string as the icon for the System block in Simulink.
            icon = 'Digital Write';
        end
    end
    
    methods (Static, Access=protected)
        function simMode = getSimulateUsingImpl(~)
            simMode = 'Interpreted execution';
        end
        
        function isVisible = showSimulateUsingImpl
            isVisible = false;
        end
    end
    
    methods (Static)
        function name = getDescriptiveName(~)
            name = 'Digital Write';
        end
        
        function b = isSupportedContext(context)
             b = context.isCodeGenTarget('rtw') || context.isCodeGenTarget('sfun'); % sfun for mlfb
        end
        
        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                % Update buildInfo
                rootDir = realtime.internal.getLinuxRoot;
                addIncludePaths(buildInfo, fullfile(rootDir, 'include'));
                % Add the following when not in rapid-accel simulation
                systemTargetFile = get_param(buildInfo.ModelName,'SystemTargetFile');
                if isequal(systemTargetFile,'ert.tlc')
                    % Link libmwraspiperipherals
                    addLinkFlags(buildInfo,{'-lmwraspiperipheral'},'SkipForSil');
                end
            end
        end
    end
end
