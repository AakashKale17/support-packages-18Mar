classdef ModbusTCPMasterRead < matlab.System & coder.ExternalDependency
    
    % MODBUSTCPMASTERREAD - Provides functionality for Master/Client to
    % communicate with the Slave/Server
    
    %#codegen
    
    % Copyright 2020-2023 The MathWorks, Inc.
    
    properties(Nontunable)
        %Server address
        serverIP = '127.0.0.1';
        %Modbus function
        Function = 'Read Coil';
        %Coil address
        CoilAddress = 0;
        %Discrete input address
        DiscreteInputAddress = 0;
        %Input register address
        InputRegisterAddress = 0;
        %Holding register address
        HoldingRegisterAddress = 0;
        %Number of Coil elements
        numElements_coil = 1;
        %Number of Discrete input elements
        numElements_input = 1;
        %Number of Input register elements
        numElements_inputReg = 1;
        %Number of Holding register elements
        numElements_holdingReg = 1;
        %Sample time
        SampleTime = 0.1;
    end
    
    properties(Hidden, Constant)
        FunctionSet = matlab.system.StringSet({...
            'Read Coil',...
            'Read Discrete input',...
            'Read Holding register',...
            'Read Input register',...            
            'Read Multiple Coils',...
            'Read Multiple Discrete inputs',...
            'Read Multiple Holding registers', ...
            'Read Multiple Input registers'});
    end
    
    properties(Hidden)
        FunctionEnum;
    end
    
    methods
        function obj = ModbusTCPMasterRead(varargin)
            coder.allowpcode('plain');
            setProperties(obj,nargin,varargin{:});
        end
        
        function set.serverIP(obj, val)
            attributes = {'nonempty'};
            paramName = 'IP Address';
            ipVal = convertStringsToChars(val);
            validateattributes(ipVal,{'char'},attributes,'',paramName);            
            if isempty(coder.target)
                ip_expr = '25[0-5]\.|2[0-4][0-9]\.|1[0-9][0-9]\.|[1-9][0-9]\.|[1-9]\.|0\.';
                [match] = regexp([ipVal '.'], ip_expr, 'match');
                if ( length(match) ~= 4 )
                    error(message('linux:utils:InvalidIPAddress'));
                end
                ipStr = [match{1} match{2} match{3} match{4}(1:end-1)];
                if ( ~strcmp(ipStr, ipVal) )
                    error(message('linux:utils:InvalidIPAddress'));
                end
                
                if strcmp(ipVal,'0.0.0.0')
                    error(message('linux:utils:InvalidIPAddress'));
                end
            end
            obj.serverIP = cString(ipVal);
        end
        
        function set.CoilAddress(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',0,'<=',65535},'','Coil Address');
            obj.CoilAddress = val;
        end
        
        function set.DiscreteInputAddress(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',0,'<=',65535},'','Discrete Input Address');
            obj.DiscreteInputAddress = val;
        end
        
        function set.InputRegisterAddress(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',0,'<=',65535},'','Input Register Address');
            obj.InputRegisterAddress = val;
        end
        
        function set.HoldingRegisterAddress(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',0,'<=',65535},'','Holding Register Address');
            obj.HoldingRegisterAddress = val;
        end
        
         function set.numElements_coil(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',1,'<=',65535},'','Number of Coil Elements');
            obj.numElements_coil = val;
         end
         
         function set.numElements_input(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',1,'<=',65535},'','Number of Discrete Input Elements');
            obj.numElements_input = val;
         end
         
         function set.numElements_inputReg(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',1,'<=',65535},'','Number of Input Register Elements');
            obj.numElements_inputReg = val;
         end
         
         function set.numElements_holdingReg(obj, val)
            validateattributes(val,{'numeric'},{'nonempty','nonnan','scalar','integer','>=',1,'<=',65535},'','Number of Holding Register Elements');
            obj.numElements_holdingReg = val;
         end
        
        function set.SampleTime(obj,sampleTime)
            coder.extrinsic('error');
            coder.extrinsic('message');
            
            validateattributes(sampleTime,{'numeric'},...
                {'nonempty','nonnan', 'finite'},...
                '','''Sample time''');
            
            % Sample time must be a real scalar value or 2 element array.
            if ~isreal(sampleTime(1)) || numel(sampleTime) > 2
                error(message('linux:utils:InvalidSampleTimeNeedScalar'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) > 0.0 && sampleTime(2) >= sampleTime(1)
                error(message('linux:utils:InvalidSampleTimeNeedSmallerOffset'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) == -1.0 && sampleTime(2) ~= 0.0
                error(message('linux:utils:InvalidSampleTimeNeedZeroOffset'));
            end
            if numel(sampleTime) == 2 && sampleTime(1) == 0.0 && sampleTime(2) ~= 1.0
                error(message('linux:utils:InvalidSampleTimeNeedOffsetOne'));
            end
            if numel(sampleTime) ==1 && sampleTime(1) < 0 && sampleTime(1) ~= -1.0
                error(message('linux:utils:InvalidSampleTimeNeedPositive'));
            end
            obj.SampleTime = sampleTime;
        end
        
        function val = get.FunctionEnum(obj)
            switch (obj.Function)
                case 'Read Coil'
                    val = 1;
                case 'Read Discrete input'
                    val = 2;
                case 'Read Input register'
                    val = 3;
                case 'Read Holding register'
                    val = 4;
                case 'Read Multiple Coils'
                    val = 5;
                case 'Read Multiple Discrete inputs'
                    val = 6;
                case 'Read Multiple Input registers'
                    val = 7;
                case 'Read Multiple Holding registers'
                    val = 8;
            end
        end
        
        function val = getTargetName(obj) %#ok<MANU>
            val = 'LINUX';
        end
    end
    
    methods(Access = protected)
        function setupImpl(obj, varargin)
           if coder.target('Rtw')
              coder.cinclude('MW_Modbus_TCP_Client.h');
              coder.ceval('MW_Modbus_Client_InitializeClient',obj.serverIP);
            end
        end       
        
        
        function [data, status] = stepImpl(obj, varargin)
            switch (obj.FunctionEnum)
                case {1, 2}
                    Mdata = coder.nullcopy(false);
                case {3, 4}
                    Mdata = zeros(1, 1, 'uint16');
                case 5
                    Mdata = zeros(1, obj.numElements_coil, 'logical');
                case 6
                    Mdata = zeros(1, obj.numElements_input, 'logical');
                case 7
                    Mdata = zeros(1, obj.numElements_inputReg, 'uint16');
                case 8
                    Mdata = zeros(1, obj.numElements_holdingReg, 'uint16');
            end
            Mstatus = int8(0);
            if coder.target('Rtw')
                
                switch (obj.FunctionEnum)
                    case 1
                        coder.ceval('MW_Modbus_Client_ReadCoil', obj.serverIP, uint16(obj.CoilAddress), coder.ref(Mdata), coder.ref(Mstatus));
                    case 2
                        coder.ceval('MW_Modbus_Client_ReadInput', obj.serverIP, uint16(obj.DiscreteInputAddress), coder.ref(Mdata), coder.ref(Mstatus));
                    case 3
                        coder.ceval('MW_Modbus_Client_ReadInputRegister', obj.serverIP, uint16(obj.InputRegisterAddress), coder.ref(Mdata), coder.ref(Mstatus));
                    case 4
                        coder.ceval('MW_Modbus_Client_ReadHoldingRegister', obj.serverIP, uint16(obj.HoldingRegisterAddress), coder.ref(Mdata), coder.ref(Mstatus));
                    case 5
                        coder.ceval('MW_Modbus_Client_ReadMultipleCoils', obj.serverIP, uint16(obj.CoilAddress), uint8(obj.numElements_coil), coder.ref(Mdata), coder.ref(Mstatus));
                    case 6
                        coder.ceval('MW_Modbus_Client_ReadMultipleInputs', obj.serverIP, uint16(obj.DiscreteInputAddress), uint8(obj.numElements_input), coder.ref(Mdata), coder.ref(Mstatus));
                    case 7
                        coder.ceval('MW_Modbus_Client_ReadMultipleInputRegister', obj.serverIP, uint16(obj.InputRegisterAddress), uint8(obj.numElements_inputReg), coder.ref(Mdata), coder.ref(Mstatus));
                    case 8
                        coder.ceval('MW_Modbus_Client_ReadMultipleHoldingRegister', obj.serverIP, uint16(obj.HoldingRegisterAddress), uint8(obj.numElements_holdingReg), coder.ref(Mdata), coder.ref(Mstatus));
                end
            end
            data = Mdata;
            status = Mstatus;
        end
        
        
        function releaseImpl(obj)
            if coder.target('Rtw')
                coder.ceval('MW_Modbus_Client_TerminateClient', obj.serverIP);
            end
        end
        
        function varargout = isOutputComplexImpl(~)
            % Return true for each output port with complex data
            varargout{1} = false;
            varargout{2} = false;
        end
        
        function varargout = isOutputFixedSizeImpl(~)
            % Return true for each output port with fixed size
            varargout{1} = true;
            varargout{2} = true;
        end
        
        function N = getNumInputsImpl(~)
            % Specify number of System inputs
            N = 0;
        end
        
        function N = getNumOutputsImpl(~)
            % Specify number of System outputs
            N = 2;
        end
       
        function varargout = getOutputNamesImpl(~)
            % Return output port names for System block
            varargout{1} = 'Data';
            varargout{2} = 'Status';
        end
        
        function varargout = getOutputSizeImpl(obj)
            % Return size for each output port
            switch obj.FunctionEnum
                case {1,2,3,4}
                    varargout{1} = [1 1];
                case 5
                    varargout{1} = [1 obj.numElements_coil];
                case 6
                    varargout{1} = [1 obj.numElements_input];
                case 7
                    varargout{1} = [1 obj.numElements_inputReg];
                case 8
                    varargout{1} = [1 obj.numElements_holdingReg];
            end
            varargout{2} = [1 1];
        end
        
        function varargout = getOutputDataTypeImpl(obj)
            % Return data type for each output port
            if ((obj.FunctionEnum == 1) || (obj.FunctionEnum == 5) || (obj.FunctionEnum == 2) || (obj.FunctionEnum == 6))
                varargout{1} = 'logical';
            else
                varargout{1} = 'uint16';
            end
            varargout{2} = 'int8';
        end
        
        function st = getSampleTimeImpl(obj)
            st = createSampleTime(obj, 'Type', 'Discrete', 'SampleTime', obj.SampleTime);
        end
        
        function flag = isInactivePropertyImpl(obj,prop)
            % Return false if property is visible based on object
            % configuration, for the command line and System block dialog
            switch prop
                case'serverIP'
                    flag = false;
                case'Function'
                    flag = false;
                case'SampleTime'
                    flag = false;
                case'CoilAddress'
                    if ((obj.FunctionEnum == 1) ||(obj.FunctionEnum == 5))
                        flag = false;
                    else
                        flag = true;
                    end
                case'DiscreteInputAddress'
                    if ((obj.FunctionEnum == 2) ||(obj.FunctionEnum == 6))
                        flag = false;
                    else
                        flag = true;
                    end
                case'InputRegisterAddress'
                    if ((obj.FunctionEnum == 3) ||(obj.FunctionEnum == 7))
                        flag = false;
                    else
                        flag = true;
                    end
                case'HoldingRegisterAddress'
                    if ((obj.FunctionEnum == 4) ||(obj.FunctionEnum == 8))
                        flag = false;
                    else
                        flag = true;
                    end
                case'numElements_coil'
                    if (obj.FunctionEnum == 5)
                        flag = false;
                    else
                        flag = true;
                    end
                case'numElements_input'
                    if (obj.FunctionEnum == 6)
                        flag = false;
                    else
                        flag = true;
                    end
                case'numElements_inputReg'
                    if (obj.FunctionEnum == 7)
                        flag = false;
                    else
                        flag = true;
                    end
                case'numElements_holdingReg'
                    if (obj.FunctionEnum == 8)
                        flag = false;
                    else
                        flag = true;
                    end
            end
        end
        
        
        function maskDisplayCmds = getMaskDisplayImpl(obj)
            function_label =  obj.Function;
            outport_label = '';
            num = getNumOutputsImpl(obj);
            if num > 0
                outputs = cell(1,num);
                [outputs{1:num}] = getOutputNamesImpl(obj);
                for i = 1:num
                    outport_label = [outport_label 'port_label(''output'',' num2str(i) ',''' outputs{i} ''');' ]; %#ok<AGROW>
                end
            end
            maskDisplayCmds = { ...
                'color(''white'');',...
                'plot([100,100,100,100]*1,[100,100,100,100]*1);',...
                'plot([100,100,100,100]*0,[100,100,100,100]*0);',...
                'color(''blue'');', ...
                ['text(99, 92, ''' getTargetName(obj) ''', ''horizontalAlignment'', ''right'');'],...
                'color(''black'');', ...
                'text(50,60,''\fontsize{12}\bfMODBUS TCP/IP'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');', ...
                'text(50,40,''\fontsize{10}\bfClient Read'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',...
                ['text(50,15,''\fontsize{8}', function_label  '' ''',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');'],...
                outport_label
                };
        end
    end
    
    methods(Static, Access = protected)
        %% Simulink customization functions
        function header = getHeaderImpl(~)
            % Define header for the System block dialog box.
            header = matlab.system.display.Header(mfilename('class'), ...
                'Title', 'Modbus TCP/IP Client Read', 'Text', getString(message('linux:blockmask:ModbusTCPMasterRead')), ...
                'ShowSourceLink', false);
        end
        
        function simMode = getSimulateUsingImpl
            % Return only allowed simulation mode in System block dialog
            simMode = 'Interpreted execution';
        end
        
        function flag = showSimulateUsingImpl
            % Return false if simulation mode hidden in System block dialog
            flag = false;
        end
        
        
        function [groups, PropertyList] = getPropertyGroupsImpl
            serverIPProp = matlab.system.display.internal.Property('serverIP', 'Description', 'Server address');
            FunctionProp = matlab.system.display.internal.Property('Function', 'Description', 'Function');
            coilAddressProp = matlab.system.display.internal.Property('CoilAddress', 'Description', 'Coil Address');
            DiscreteInputAddressProp = matlab.system.display.internal.Property('DiscreteInputAddress', 'Description', 'Discrete Input Address');
            InputRegisterAddressProp = matlab.system.display.internal.Property('InputRegisterAddress', 'Description', 'Input Register Address');
            HoldingRegisterAddressProp = matlab.system.display.internal.Property('HoldingRegisterAddress', 'Description', 'Holding Register Address');
            SampleTimeProp = matlab.system.display.internal.Property('SampleTime', 'Description', 'Sample Time');
            numElementsCoilProp = matlab.system.display.internal.Property('numElements_coil', 'Description', 'Number of Coils');
            numElementsInputProp = matlab.system.display.internal.Property('numElements_input', 'Description', 'Number of Discrete Inputs');
            numElementsInputRegProp = matlab.system.display.internal.Property('numElements_inputReg', 'Description', 'Number of Input registers');
            numElementsHoldingRegProp = matlab.system.display.internal.Property('numElements_holdingReg', 'Description', 'Number of Holding registers');
            
            % Property list
            PropertyList ={
                serverIPProp,...
                FunctionProp,...
                coilAddressProp, ...
                DiscreteInputAddressProp, ...
                InputRegisterAddressProp, ...
                HoldingRegisterAddressProp,...
                numElementsCoilProp,...
                numElementsInputProp, ...
                numElementsInputRegProp, ...
                numElementsHoldingRegProp,...
                SampleTimeProp };
            
            % Create mask display
            Group = matlab.system.display.Section(...
                'PropertyList',PropertyList);
            
            groups = Group;
            
            % Return property list if required
            if nargout > 1
                PropertyList = PropertyListOut;
            end
        end
        
    end
    
    methods (Static)
        function name = getDescriptiveName()
            name = 'Modbus TCP/IP Client Read';
        end      
      
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                spkgRootDir = realtime.internal.getLinuxRoot;
                % Include Paths
                addIncludePaths(buildInfo, fullfile(spkgRootDir, 'include'));               
                systemTargetFile = get_param(buildInfo.ModelName,'SystemTargetFile');
                if isequal(systemTargetFile,'ert.tlc')                  
                    addSourcePaths(buildInfo, fullfile(spkgRootDir, 'src'));
                    addSourceFiles(buildInfo, 'MW_Modbus_TCP_Client.c', fullfile(spkgRootDir, 'src'), 'BlockModules');     
                    mb_linkflags = '`pkg-config --libs --cflags libmodbus`';                    
                    addLinkFlags(buildInfo,mb_linkflags,'SkipForSil');
                    codertarget.linux.remotebuild.addTargetSpecificLibs(buildInfo,'-lmodbus');
                end
            end
        end
    end
end

% Local functions
function str = cString(str)
str = [str uint8(0)];
end