classdef ThingSpeakTalkBackWrite < matlab.System & ...
        coder.ExternalDependency
    % Write to ThingSpeak TalkBack using API EndPoints
    
	% Copyright 2021-2022 The MathWorks, Inc.
	
    %#codegen
    %#ok<*EMCA>


    % Public, non-tunable properties
    properties(Nontunable)
        %TalkBack API
        TalkBackMode (1,:) char {matlab.system.mustBeMember(TalkBackMode,{'Add a command', 'Delete all commands'})} = 'Add a command';
        %TalkBack ID      
        TalkBackID = 123456;
        %API key    
        APIKey = 'ABCDEFGHIJKLMNOP';
        % Command type
        CommandType (1,:) char {matlab.system.mustBeMember(CommandType,{'String', 'ASCII vector'})} = 'String';
        % Block platform
        blockPlatform = 'LINUX';
        % TalkBack url
        TalkBackUrl =  'https://api.thingspeak.com/talkbacks/';

        % Specify position
        SpecifyPosition (1, 1) logical = false;
        % Print diagnostic messages
        PrintDiagnosticMessages (1, 1) logical = false;
    end

    properties(Hidden, Access = private)
        TBWriteHandle;
    end
    
    methods
        % Constructor
        function obj = ThingSpeakTalkBackWrite(varargin)
            % Support name-value pair arguments when constructing object
            coder.allowpcode('plain');
            setProperties(obj,nargin,varargin{:})
        end
        
        function set.APIKey(obj, val)
            validateattributes(val, ...
                {'char'}, {'nonempty'}, '', 'APIKey');
            obj.APIKey = strtrim(val);
        end
        
        function set.TalkBackID(obj, val)
            validateattributes(val, {'numeric'}, ...
                {'real', 'positive', 'integer', 'scalar', 'nonempty'}, '', 'TalkbackID');
            obj.TalkBackID = val;
        end
        
    end

    methods(Access = protected)
        %% Common functions
        function setupImpl(obj)
            % Perform one-time calculations, such as computing constants
            if coder.target('Rtw')
                coder.cinclude('MW_thingspeak_talkback.h');
                coder.ceval('MW_talkback_init', cstr(obj.TalkBackUrl), cstr(int2str(obj.TalkBackID)), cstr(obj.APIKey), obj.PrintDiagnosticMessages);  
            end
        end

        function stepImpl(obj, TriggerPort, CommandString, Position)
            % Implement algorithm. Calculate y as a function of input u and
            % discrete states.
            if coder.target('MATLAB')
                if strcmp(obj.TalkBackMode, 'Delete all commands') && (TriggerPort ~= 0)
                    deleteURL = [obj.TalkBackUrl, int2str(obj.TalkBackID), '/commands?api_key=', obj.APIKey];
                    options = weboptions('RequestMethod','delete');
                    try
                        webwrite(deleteURL, options);
                    catch 
                    end
                elseif strcmp(obj.TalkBackMode, 'Add a command') && (TriggerPort ~= 0)
                    if obj.SpecifyPosition
                        cPosition = int32(Position);
                    else
                        cPosition = int32(0);
                    end
                    try
                        webwrite([obj.TalkBackUrl, num2str(obj.TalkBackID), '/commands'], 'api_key', char(obj.APIKey) , 'command_string', strrep(char(CommandString),char(0),'') , 'position', num2str(cPosition));
                    catch
                    end
                end
            elseif coder.target('Rtw')
                obj.TBWriteHandle = coder.opaque('TBReadData_t *','NULL','HeaderFile','MW_thingspeak_talkback.h');
                
                if strcmp(obj.TalkBackMode, 'Delete all commands')
                    cmdType = int32(2);
                elseif strcmp(obj.TalkBackMode, 'Add a command')
                    cmdType = int32(1);
                end
                
                if((TriggerPort ~= 0))
                    obj.TBWriteHandle = coder.ceval('MW_talkBack_writeHandle',cstr(obj.TalkBackUrl), cstr(int2str(obj.TalkBackID)), cstr(obj.APIKey), cmdType, obj.PrintDiagnosticMessages);
                end
            
                if strcmp(obj.TalkBackMode, 'Delete all commands') && (TriggerPort ~= 0)
                    coder.ceval('MW_talkBack_deleteAll', obj.TBWriteHandle);
                elseif strcmp(obj.TalkBackMode, 'Add a command') && (TriggerPort ~= 0)
                    if obj.SpecifyPosition
                        cPosition = int32(Position);
                    else
                        cPosition = int32(0);
                    end
                    coder.ceval('MW_talkBack_addCommand', obj.TBWriteHandle, cstr(obj.APIKey), cstr(int2str(cPosition)), CommandString);
                end
            end
        end

        %% Backup/restore functions
        function s = saveObjectImpl(obj)
            % Set properties in structure s to values in object obj

            % Set public properties and states
            s = saveObjectImpl@matlab.System(obj);

            % Set private and protected properties
            %s.myproperty = obj.myproperty;
        end

        function loadObjectImpl(obj,s,wasLocked)
            % Set properties in object obj to values in structure s

            % Set private and protected properties
            % obj.myproperty = s.myproperty; 

            % Set public properties and states
            loadObjectImpl@matlab.System(obj,s,wasLocked);
        end

        %% Simulink functions
        function ds = getDiscreteStateImpl(obj)
            % Return structure of properties with DiscreteState attribute
            ds = struct([]);
        end

        function flag = isInputSizeMutableImpl(obj,index)
            % Return false if input size cannot change
            % between calls to the System object
            flag = false;
        end

        function out = getOutputSizeImpl(obj)
            % Return size for each output port
            out = 0;

            % Example: inherit size from first input port
            % out = propagatedInputSize(obj,1);
        end
        
        function out = getNumInputsImpl(obj)
            % Specify number of System inputs
            out = 1;
            if strcmp(obj.TalkBackMode, 'Add a command')
                out = out+1;
                if obj.SpecifyPosition     
                    out = out+1;
                end
            end
        end
        
        function varargout = getInputNamesImpl(obj)
            varargout{1} = '';
            if strcmp(obj.TalkBackMode, 'Add a command')
                varargout{1} = 'Trigger';
                if strcmp(obj.CommandType, 'String')
                    varargout{2} = 'Command string';
                else
                    varargout{2} = 'ASCII command';
                end
                if obj.SpecifyPosition
                    varargout{3} = 'Position';
                end
            end
        end
        
        function maskDisplayCmds = getMaskDisplayImpl(obj)
            inport_label = '';
            num = getNumInputsImpl(obj);
            if num > 0
                inputs = cell(1,num);
                [inputs{1:num}] = getInputNamesImpl(obj);
                for i = 1:num
                    inport_label = [inport_label 'port_label(''input'',' num2str(i) ',''' inputs{i} ''');' ]; %#ok<AGROW>
                end
            end
            talkBackID = int2str(obj.TalkBackID);
            talkBackDisp = '';
            talkBackDisp = ['text(50, 15, ''TalkBack ID:  ' talkBackID ''', ''horizontalAlignment'', ''center'',''verticalAlignment'',''middle'');'];
            maskDisplayCmds = { ...
                'color(''white'');',...
                'plot([100,100,100,100]*1,[100,100,100,100]*1);',...
                'plot([100,100,100,100]*0,[100,100,100,100]*0);',...
                'color(''black'');', ...
                'text(50,60,''\fontsize{12}\bfTalkBack'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');', ...
                'text(50,40,''\fontsize{10}\bfWrite'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',...
                talkBackDisp,...
                inport_label
                };
            
            labelSample = obj.blockPlatform;
            maskDisplayCmdsTarget = { ...
                ['color(''blue'');', newline],...
                ['text(99, 92, ''' labelSample ''', ''horizontalAlignment'', ''right'');', newline],...
                };
            maskDisplayCmds = [maskDisplayCmds maskDisplayCmdsTarget];
        end
        
        function validateInputsImpl(obj, TriggerPort, CommandString, Position)
            validateattributes(TriggerPort,{'numeric','logical'}, ...
                    {'scalar','nonnan','finite'},'','Trigger');
            if strcmp(obj.TalkBackMode, 'Add a command')
                if isequal(obj.CommandType, 'String')
                    % String->ascii blocks converts to row vector
                    validateattributes(CommandString,{'uint8'}, ...
                          {'nonnan','finite','row','size',[1, min(length(CommandString), 255)]},'','CommandString');
                else
                    % Normal ascii input from a constant block will be a
                    % column vector
                    validateattributes(CommandString,{'uint8'}, ...
                          {'nonnan','finite','column','size',[min(length(CommandString), 255), 1]},'','CommandString');
                end
                if obj.SpecifyPosition   
                    validateattributes(Position,{'uint16'}, ...
                        {'scalar','nonnan','finite'},'','Position');
                end
            end
        end
        
        function flag = isInactivePropertyImpl(obj,prop)
            % Return false if property is visible based on object 
            % configuration, for the command line and System block dialog
            flag = false;
            switch prop
                case {'CommandType', 'SpecifyPosition'}
                    flag = ~strcmp(obj.TalkBackMode, 'Add a command');
            end
        end
    end

    methods(Static, Access = protected)
        %% Simulink customization functions        
        function simMode = getSimulateUsingImpl
            % Return only allowed simulation mode in System block dialog
            simMode = 'Interpreted execution';
        end
        
        function isVisible = showSimulateUsingImpl
            isVisible = false;
        end
        
        function header = getHeaderImpl(~)
            % Define header for the System block dialog box.
            header = matlab.system.display.Header(mfilename('class'), ...
                'Title', 'TalkBack Write', 'Text', ...
                'Write to ThingSpeak TalkBack');
        end
        
        function group = getPropertyGroupsImpl
            % Define property section(s) for System block dialog
            blockPlatformProp = matlab.system.display.internal.Property('blockPlatform', 'Description', 'Block Platform','IsGraphical',false);
            talkBackUrlProp = matlab.system.display.internal.Property('TalkBackUrl', 'Description', 'TalkBack Url','IsGraphical',false);
            requiredGroup = matlab.system.display.Section(...
                'Title', 'Parameters',...
                'PropertyList', {'TalkBackMode','TalkBackID', 'APIKey', 'CommandType','SpecifyPosition', ...
                'PrintDiagnosticMessages', blockPlatformProp, talkBackUrlProp});
            group = requiredGroup;
        end
    end
    
     methods (Static)
        function name = getDescriptiveName(~)
            name = 'TalkBack Add Command';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context)
            % Update the build-time buildInfo
            if context.isCodeGenTarget('rtw')
                % Header paths
                rootDir = realtime.internal.getLinuxRoot();
                buildInfo.addIncludePaths(fullfile(rootDir,'include'));
                buildInfo.addIncludeFiles('MW_thingspeak_talkback.h');
                systemTargetFile = get_param(buildInfo.ModelName,'SystemTargetFile');
                if isequal(systemTargetFile,'ert.tlc')
                    % Add the following when not in rapid-accel simulation
                    buildInfo.addSourceFiles('MW_thingspeak_talkback.c',fullfile(rootDir,'src'));
                    codertarget.linux.remotebuild.addTargetSpecificLibs(buildInfo,'-lcurl');
                    codertarget.linux.remotebuild.addTargetSpecificLibs(buildInfo,'-ljson-c');
                end
            end
        end
    end
end

%% Internal functions
function str = cstr(str)
str = [str(:).', char(0)];
end