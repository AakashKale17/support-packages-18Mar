/*MW_SPI_Helper for Matlab Targeting*/

#ifndef _MW_SPI_HELPER_MTARGETING_H_
#define _MW_SPI_HELPER_MTARGETING_H_

#ifndef SPI0_CE0
#define SPI0_CE0 0
#define SPI0_CE1 1
#endif

#endif