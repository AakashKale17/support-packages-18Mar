/* Copyright 2016 The MathWorks, Inc. */
/*MW_SPI_Helper*/
#ifndef _MW_SPI_HELPER_H_
#define _MW_SPI_HELPER_H_

#ifdef __MW_TARGET_USE_HARDWARE_RESOURCES_H__
#include "MW_target_hardware_resources.h"
#endif

#ifndef MW_SPI_SPI0CE0BUSSPEED
#define MW_SPI_SPI0CE0BUSSPEED 0
#endif

#ifndef MW_SPI_SPI0CE1BUSSPEED
#define MW_SPI_SPI0CE1BUSSPEED 0
#endif


#ifndef SPI0_CE0
#define SPI0_CE0 0
#define SPI0_CE1 1
#endif

#ifdef __cplusplus

extern "C" {

#endif
void set_spi_ce0_speed(uint8_T value); 
void set_spi_ce1_speed(uint8_T value);
#ifdef __cplusplus

}
#endif

#define SETSPI0CE0SPEED() (set_spi_ce0_speed(MW_SPI_SPI0CE0BUSSPEED))
#define SETSPI0CE1SPEED() (set_spi_ce1_speed(MW_SPI_SPI0CE1BUSSPEED))

typedef struct {
    int fd;
    uint32_T SlaveSelectPin;
    uint32_T speed;
    uint8_T bitsPerWord;
    MW_SPI_Mode_type lsbFirst;
    MW_SPI_FirstBitTransfer_Type mode;
} SPI_dev_t;

extern SPI_dev_t spiDev[2];

#endif