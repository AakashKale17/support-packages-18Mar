classdef NanoMsgReceive < matlab.System & ...
        matlabshared.svd.BlockSampleTime & coder.ExternalDependency
    % Receive data from a transport layer using nanomsg-next-gen (NNG)
    
	% Copyright 2022 The MathWorks, Inc.

    %#codegen
    %#ok<*EMCA>

    properties (Hidden, Access = private)
        NNGRHandle;
        NNGRHandleInitialized;
    end

    % Public, non-tunable properties
    properties (Nontunable)
        %Custom URL name
        CustomName = "testing";
        %Data type
        DataType (1,:) char {matlab.system.mustBeMember(DataType,{'uint8','int8','uint16','int16','uint32','int32','single','double'})} = 'uint8';
        %Data length (N)
        DataLength = 1;
        %Byte order
        ByteOrder = 'LittleEndian';
        % Block platform
        blockPlatform = 'LINUX';
        % PrintDiagnosticMessages Print diagnostic messages
        PrintDiagnosticMessages (1, 1) logical = false;
    end
    
    properties(SetAccess = private, Nontunable)
        Property = '';
    end

    properties (Dependent, Access=protected)
        ByteOrderEnum;
    end

    methods
        % Constructor
        function obj = NanoMsgReceive(varargin)
            % Support name-value pair arguments when constructing object
            coder.allowpcode('plain');
            setProperties(obj,nargin,varargin{:})
        end

        function set.DataLength(obj, value)            
            validateattributes(value,{'numeric'}, {'real','positive','scalar','integer','finite','nonnan','nonempty','<',2^31}, '', 'Data length (N)');
            
            obj.DataLength = value;
        end

        function set.CustomName(obj, val)
            validateattributes(val, ...
                {'char'}, {'nonempty'}, '', 'Custom name');
            if(length(val) > 20)
                error(message('linux:blockmask:CharLenErr', 'Custom name', 20));
            end
            obj.CustomName = strtrim(val);
        end

        function val = get.Property(obj)
           val = obj.CustomName;
        end

        % false if little endian
        % true if big endian
        function ret = get.ByteOrderEnum(obj)
            if isequal(obj.ByteOrder, 'LittleEndian')
                ret = false;
            else
                ret = true;
            end
        end
    end

    methods (Access = protected)
        %% Common functions
        function setupImpl(obj)
            % Perform one-time calculations, such as computing constants
            if coder.target('Rtw')
                coder.cinclude('MW_NNG.h');
                
                obj.NNGRHandleInitialized = false;
				
                obj.NNGRHandle = coder.opaque('NNGReceiveData_t *','NULL','HeaderFile','MW_NNG.h');
                nullHandle = obj.NNGRHandle;
                datalen = cast(obj.getNumberOfBytes(obj.DataType)*obj.DataLength, 'uint32');
                obj.NNGRHandle = coder.ceval("MW_NNG_initReceiveSocket",cstr(obj.CustomName), obj.SampleTime, datalen);
                if obj.NNGRHandle ~= nullHandle
                    obj.NNGRHandleInitialized = true;
                end

                if obj.PrintDiagnosticMessages
                    coder.updateBuildInfo('addDefines','PRINT_NNG_RECV_DEBUG');
                end
            end
        end

        function [data, status] = stepImpl(obj)
            % Implement algorithm. Calculate y as a function of input u and
            % discrete states.
            
            datalen = cast(obj.getNumberOfBytes(obj.DataType)*obj.DataLength, 'uint32');
            RxDataChar = coder.nullcopy(cast(zeros(datalen, 1), 'uint8'));
            status = uint8(0);
            val = int32(0);
            if coder.target('Rtw')
                if obj.NNGRHandleInitialized
                    val = coder.ceval("MW_NNG_stepReceive",obj.NNGRHandle,coder.wref(RxDataChar),datalen);
                    status = uint8(val);
                end
            end

            % Arrange according to Byteorder
            if obj.ByteOrderEnum
                data = matlabshared.svd.ByteOrder.changeByteOrder(RxDataChar, obj.DataType);
            else
                % Reform the data to required data type
                data = matlabshared.svd.ByteOrder.concatenateBytes(RxDataChar, obj.DataType);
            end
        end

        function releaseImpl(obj)
            if coder.target('Rtw')
                coder.ceval("MW_NNG_clearReceiveSocket",obj.NNGRHandle);
            end
        end

        %% Backup/restore functions
        function s = saveObjectImpl(obj)
            % Set properties in structure s to values in object obj

            % Set public properties and states
            s = saveObjectImpl@matlab.System(obj);

            % Set private and protected properties
            %s.myproperty = obj.myproperty;
        end

        function loadObjectImpl(obj,s,wasLocked)
            % Set properties in object obj to values in structure s

            % Set private and protected properties
            % obj.myproperty = s.myproperty; 

            % Set public properties and states
            loadObjectImpl@matlab.System(obj,s,wasLocked);
        end

        %% Simulink functions
        function flag = isInputSizeMutableImpl(obj,index)
            % Return false if input size cannot change
            % between calls to the System object
            flag = false;
        end

        function flag = isInactivePropertyImpl(obj,propertyName)
            flag = false; 
        end
        
        function varargout = isOutputFixedSizeImpl(obj)
            for N = 1 : obj.getNumOutputsImpl
                varargout{N} = true;
            end
        end

        function varargout = isOutputComplexImpl(obj)
            for N = 1 : obj.getNumOutputsImpl
                varargout{N} = false;
            end
        end
        
        function num = getNumOutputsImpl(~)
            num = 2;
        end
        
        function varargout = getOutputDataTypeImpl(obj)
            N = 1;
            varargout{N} = obj.DataType;             %data
            N = N + 1;
            varargout{N} = 'uint8';             % Status
        end

        function varargout = getOutputNamesImpl(~)
            % Return output port names for System block
            N = 1;
            varargout{N} = 'Data';
            N = N + 1;
            varargout{N} = 'Status';
        end
        
        function varargout = getOutputSizeImpl(obj)%#ok
            N = 1;
            varargout{N} = [obj.DataLength 1];  %data
            N = N + 1;
            varargout{N} = [1 1];           % Status
        end
        
        function out = getNumInputsImpl(~)
            out = 0;
        end
        
        function maskDisplayCmds = getMaskDisplayImpl(obj)
            
            maskDisplayCmds = [ ...
                ['color(''white'');', newline]...                                     % Fix min and max x,y co-ordinates for autoscale mask units
                ['plot([100,100,100,100],[100,100,100,100]);',newline]...
                ['plot([0,0,0,0],[0,0,0,0]);',newline]...
                ['color(''blue'');',newline] ...                                     % Drawing mask layout of the block
                ['text(99, 92, ''' obj.blockPlatform ''', ''horizontalAlignment'', ''right'');',newline] ...
                ['color(''black'');',newline] ...
                ['port_label(''output'',1,''Data'');', newline]...
                ['port_label(''output'',2,''Status'');', newline]...
                ];
            
            CustomURL = ['ipc:///tmp/', obj.CustomName, '.ipc'];
            maskDisplayCmds = [maskDisplayCmds,...
                ['text(50,50,''\fontsize{12}\bfNNG Receive'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline, ...
                 'text(50,20,''' CustomURL ''',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline, ...
                 ]];            
        end
    end

    methods(Static)
        function NumberOfBytes = getNumberOfBytes(DataType)
            switch (DataType)
                case {'int8','uint8'}
                    NumberOfBytes = 1;
                case {'int16','uint16'}
                    NumberOfBytes = 2;
                case {'int32','uint32','single'}
                    NumberOfBytes = 4;
                case {'int64','uint64','double'}
                    NumberOfBytes = 8;
                otherwise
                    error('Invalid datatype');
            end
        end
    end

    methods (Static, Access = protected)
        %% Simulink customization functions        
        function simMode = getSimulateUsingImpl
            % Return only allowed simulation mode in System block dialog
            simMode = 'Interpreted execution';
        end
        
        function isVisible = showSimulateUsingImpl
            isVisible = false;
        end
        
        function header = getHeaderImpl(~)
            % Define header for the System block dialog box.
            header = matlab.system.display.Header(mfilename('class'), ...
                'Title', getString(message('linux:blockmask:NNGReceiveTitle')), 'Text', ...
                getString(message('linux:blockmask:NNGReceiveDescription')),'ShowSourceLink', false);
        end
        
        function sts = getSampleTimeImpl(obj)
            sts = getSampleTimeImpl@matlabshared.svd.BlockSampleTime(obj);
        end

        function group = getPropertyGroupsImpl
            % Define property section(s) for System block dialog
            customNameProp = matlab.system.display.internal.Property('CustomName', 'Description', 'linux:blockmask:NNGCustomNameProp');
            dataTypeNameProp = matlab.system.display.internal.Property('DataType', 'Description', 'linux:blockmask:DataTypeProp');
            dataLenNameProp = matlab.system.display.internal.Property('DataLength', 'Description', 'linux:blockmask:DataLengthProp');
            SampleTimeProp = matlab.system.display.internal.Property('SampleTime', 'Description', 'linux:blockmask:SampleTimeProp');
            byteOrderProp = matlab.system.display.internal.Property('ByteOrder', 'Description', 'linux:blockmask:ByteOrderProp','IsGraphical',false);
            BlockPlatformProp = matlab.system.display.internal.Property('blockPlatform', 'Description', 'linux:blockmask:BlockPlatformProp','IsGraphical',false);
            requiredGroup = matlab.system.display.Section(...
                'Title', 'Parameters',...
                'PropertyList', {customNameProp,dataTypeNameProp, dataLenNameProp, byteOrderProp,...
                'PrintDiagnosticMessages', SampleTimeProp, BlockPlatformProp});
            group = requiredGroup;
        end
    end

     methods (Hidden, Static)
        function name = getDescriptiveName()
            name = getString(message('linux:blockmask:NNGReceiveTitle'));
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                % Update buildInfo
                rootDir = realtime.internal.getLinuxRoot();
                addIncludePaths(buildInfo, fullfile(rootDir, 'include'));
                addIncludePaths(buildInfo, fullfile(rootDir, 'src'));
                addIncludeFiles(buildInfo, 'MW_NNG.h');
                addSourcePaths(buildInfo, fullfile(rootDir, 'src'));
                addSourceFiles(buildInfo, 'MW_NNG.c', fullfile(rootDir, 'src'), 'BlockModules');
                codertarget.linux.remotebuild.addTargetSpecificLibs(buildInfo,'-lnng');
                codertarget.linux.remotebuild.addTargetSpecificLibs(buildInfo,'-latomic');
            end
        end
    end
end

%% Internal functions
function str = cstr(str)
str = [str(:).', char(0)];
end