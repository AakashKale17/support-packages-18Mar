classdef SPIMasterTransfer < matlabshared.svd.SPIMasterBlock ...
        & coder.ExternalDependency
    %SPIMasterTransfer Set the logical value of a digital output pin.
    %
    % Copyright 2020 The MathWorks, Inc.
    
    %#codegen
    
    properties (Nontunable)
        %SPIModule SPI module
        SPIModule = 0;
    end
    
    properties
        Pin
    end
    
    methods
        function obj = SPIMasterTransfer(varargin)
            obj.Logo = 'LINUX';
        end
    end
    
    methods (Static)
        function name = getDescriptiveName(~)
            name = 'SPI Master Transfer';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context) %#ok<INUSD>
        end
    end
end
%[EOF]
