/* Copyright 2023 The MathWorks, Inc. */
#include "MW_HttpClient.h"

static int initHTTPClientOnce;

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp)
{
    HTTPReadData_t *HTTPReadDataPtr = (HTTPReadData_t *)userp;
    HTTPReadChunk_t *mem = (HTTPReadChunk_t *)&HTTPReadDataPtr->dataRead;

    size_t realsize = size * nmemb;

    if(mem->dataReceived != NULL){
        free(mem->dataReceived);
    }
    
    mem->dataReceived = (char *)malloc(realsize + 1);
    if(mem->dataReceived == NULL) {
        perror("Not enough memory (malloc returned NULL)\n");
        return 0;
    }
    
    memcpy(mem->dataReceived, contents, realsize);
    mem->size += realsize;
    mem->dataReceived[mem->size] = 0;
    
    return realsize;
}


void MW_HttpClient_init(void)
{
    if(initHTTPClientOnce == 0){
        curl_global_init(CURL_GLOBAL_ALL);
        initHTTPClientOnce = 1;
    }
}

// Send data to ThingSpeak using curl
uint8_t MW_HttpClient_step(
    HTTPReadData_t *HTTPReadDataPtr,
    char* httpMethod,
    const char *URL,
    uint8_t doInput, 
    uint8_t doOutput, 
    char* payload, 
    char* contentType,
    char* accept,
    uint32_t responseStringMaxLength, 
    char* response, 
    uint32_t *responseSize,
    uint8_t numCustomHeaders,
    char* header1Key, char* header1Value,
    char* header2Key, char* header2Value,
    char* header3Key, char* header3Value)
{
    int strSize;
    pthread_t thread;
    CURLcode resp;

    if(HTTPReadDataPtr->printDiagnosticMessages){
        printf("HTTP_CLIENT_DIAG_MSG: MW_HttpClient_step with httpMethod=%s, "
               "URL=%s, doInput=%d, doOutput=%d, payload=%s, contentType=%s, "
               "accept=%s, responseStringMaxLength=%d, numCustomHeaders=%d, "
               "header1Key=%s, header1Value=%s, header2Key=%s, header2Value=%s, "
               "header3Key=%s, header3Value=%s\r\n", httpMethod, 
               URL, doInput, doOutput, payload, contentType, 
               accept, responseStringMaxLength, numCustomHeaders, 
               header1Key, header1Value, header2Key, header2Value, 
               header3Key, header3Value);
        fflush(stdout);
    }

    curl_easy_setopt(HTTPReadDataPtr->curl_handle, CURLOPT_URL, URL);
    curl_easy_setopt(HTTPReadDataPtr->curl_handle, CURLOPT_CUSTOMREQUEST, httpMethod);

    struct curl_slist *headersList = NULL;
    char *contentTypeHeader = NULL;
    char *acceptHeader = NULL;
    char *addditionalHeader1 = NULL;
    char *addditionalHeader2 = NULL;
    char *addditionalHeader3 = NULL;

    if(doInput){
        contentTypeHeader = (char*)malloc(strlen("content-type:")+strlen(contentType)+1);
        sprintf(contentTypeHeader,"content-type:%s",contentType);
        headersList = curl_slist_append(headersList, contentTypeHeader);
        curl_easy_setopt(HTTPReadDataPtr->curl_handle, CURLOPT_POSTFIELDS, payload);
    }

    if(doOutput){
        acceptHeader = (char*)malloc(strlen("accept:")+strlen(accept)+1);
        sprintf(acceptHeader,"accept:%s",accept);
        headersList = curl_slist_append(headersList, acceptHeader);
    }

    switch(numCustomHeaders){
        case 3:
            addditionalHeader3= (char*)malloc(strlen(header3Key)+strlen(header3Value)+1);
            sprintf(addditionalHeader3,"%s:%s",header3Key,header3Value);
            headersList = curl_slist_append(headersList, addditionalHeader3);
        case 2:
            addditionalHeader2= (char*)malloc(strlen(header2Key)+strlen(header2Value)+1);
            sprintf(addditionalHeader2,"%s:%s",header2Key,header2Value);
            headersList = curl_slist_append(headersList, addditionalHeader2);
        case 1:
            addditionalHeader1= (char*)malloc(strlen(header1Key)+strlen(header1Value)+1);
            sprintf(addditionalHeader1,"%s:%s",header1Key,header1Value);
            headersList = curl_slist_append(headersList, addditionalHeader1);
    }
    curl_easy_setopt(HTTPReadDataPtr->curl_handle, CURLOPT_HTTPHEADER, headersList);
    
    if (HTTPReadDataPtr->curl_handle != NULL){
        resp = curl_easy_perform(HTTPReadDataPtr->curl_handle);
        if(HTTPReadDataPtr->printDiagnosticMessages){
            printf("HTTP_CLIENT_DIAG_MSG: curl_easy_perform status - %s\r\n", curl_easy_strerror(resp));
            fflush(stdout);
        }
        if(resp != CURLE_OK){
                perror("curl_easy_perform failed");
                return 0;
        }
        
    }else{
        if(HTTPReadDataPtr->printDiagnosticMessages){
            printf("HTTP_CLIENT_DIAG_MSG: Invalid curl handle");
            fflush(stdout);
        }
        return 0;
    }

    if(HTTPReadDataPtr->dataRead.dataReceived != NULL){
        if(HTTPReadDataPtr->printDiagnosticMessages){
            printf("HTTP_CLIENT_DIAG_MSG: Data Received - %s\r\n", HTTPReadDataPtr->dataRead.dataReceived);
            fflush(stdout);
        }
        strncpy(response, HTTPReadDataPtr->dataRead.dataReceived,responseStringMaxLength);
        *responseSize=strlen(response);
    }

    if(contentTypeHeader)free(contentTypeHeader);
    if(acceptHeader)free(acceptHeader);
    if(addditionalHeader1)free(addditionalHeader1);
    if(addditionalHeader2)free(addditionalHeader2);
    if(addditionalHeader3)free(addditionalHeader3);
    curl_slist_free_all(headersList);
    curl_easy_cleanup(HTTPReadDataPtr->curl_handle);
    free(HTTPReadDataPtr);
    return 1;
}

HTTPReadData_t *MW_HttpClient_getHandle(boolean_T printDiagnosticMessages)
{
    CURLcode resp;
    HTTPReadData_t *HTTPReadDataPtr;
    HTTPReadDataPtr = (HTTPReadData_t *)malloc(sizeof(HTTPReadData_t));
    
    // Mallocs in this function are freed in MW_HttpClient_step
    if(HTTPReadDataPtr == NULL){
        perror("Cannot allocate memory for HTTP Client Execute block.");
        return NULL;
    }
    
    HTTPReadDataPtr->printDiagnosticMessages = printDiagnosticMessages;
    HTTPReadDataPtr->dataRead.size = 0;
    HTTPReadDataPtr->dataRead.dataReceived = NULL;
        
    HTTPReadDataPtr->curl_handle = curl_easy_init();
    if(HTTPReadDataPtr->curl_handle == NULL){
        perror("curl_easy_init failed");
    }else{
        curl_easy_setopt(HTTPReadDataPtr->curl_handle, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(HTTPReadDataPtr->curl_handle, CURLOPT_WRITEDATA, (void *)HTTPReadDataPtr);
        curl_easy_setopt(HTTPReadDataPtr->curl_handle, CURLOPT_USERAGENT, "libcurl-agent/1.0");
    }
       
    return HTTPReadDataPtr;
}


void MW_HttpClient_terminate(HTTPReadData_t *HTTPReadDataPtr){
        curl_global_cleanup();
}

uint32_T MW_getCurrentTimeInMillisHttp(void){
    struct timespec ts;
    uint32_T ms;

    clock_gettime(CLOCK_MONOTONIC , &ts);
    ms = ts.tv_sec * 1000.0 + round(ts.tv_nsec / 1.0e6); 

    return (ms);
}