classdef CANTransmit < matlab.System & coder.ExternalDependency
    %
    % CAN Message transmit block for Shared Linux targets.
    %

%   Copyright 2021 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>n
    
    properties
        %Identifier Type
        IdentifierType  (1,:) char {matlab.system.mustBeMember(IdentifierType,{'Standard (11-bit identifier)', 'Extended (29-bit identifier)'})} = 'Standard (11-bit identifier)';
        sockHandleDataFrames = int32(0);
        sockHandleErrorFrames = int32(0);
        notFirstStep = false;
    end
    
    properties (Hidden, Nontunable)
        Logo = 'LINUX'
    end
    
    properties (Nontunable)
        %CAN interface
        DeviceID = 'can0';
        %TypeOfCAN
        TypeofCAN (1,:) char {matlab.system.mustBeMember(TypeofCAN,{'Real', 'Virtual'})} = 'Real';
        %Message ID
        MessageId = 100;
        %Input data type
        InputDataType  (1,:) char {matlab.system.mustBeMember(InputDataType,{'Raw data', 'CAN Msg'})} = 'Raw data';
        %Length (bytes)
        MsgLength = 8;
        %Timeout in seconds
        BlockTimeout_ = 1;
    end  

    properties (Access = private)
        Initialized = false;
        IsCANSetup = true;
    end
    
    properties (Nontunable)
        %Remote frame
        RemoteFrame (1, 1) logical = false;
        %Output status
        OutputStatus (1, 1) logical = false;
        %Wait until data sent
        BlockingMode_ (1, 1) logical = false;
        %Setup CAN Node
        SetupCAN (1, 1) logical = false;
    end
    
    properties(Hidden, Transient)
        SetIdentifierType = false;
    end
    
    methods
        function obj = CANTransmit(varargin)
            coder.allowpcode('plain');
            setProperties(obj,nargin,varargin{:});
        end
        
        function set.IdentifierType(obj,value)
            obj.IdentifierType = value;
            obj.SetIdentifierType = true; %#ok<MCSUP>
        end
       
        function set.TypeofCAN(obj,value)
            obj.TypeofCAN = value;
        end

        function set.MessageId(obj,value)
            if obj.IdentifierType == "Standard (11-bit identifier)" %#ok<MCSUP>
                msgIdLimit = hex2dec('7ff');
            else
                msgIdLimit = hex2dec('1fffffff');
            end
            if obj.SetIdentifierType %#ok<MCSUP>
                validateattributes(value,...
                    {'numeric'},...
                    {'real','nonnegative','integer','scalar','<=',msgIdLimit},...
                    '', ...
                    'Message ID');
            end
            obj.MessageId = value;
        end
        
        function set.DeviceID(obj,value)
            validateattributes(value, ...
                {'char'}, {'nonempty'}, '', 'CAN interface');
            obj.DeviceID = value;
        end
        
        function set.MsgLength(obj,value)
            validateattributes(value,...
                {'numeric'},...
                {'real','nonnegative','integer','scalar','<=',8},...
                '', ...
                'Message length');
            obj.MsgLength = value;
        end
        
        function set.BlockTimeout_(obj, val)
            classes = {'numeric'};
            attributes = {'nonempty','nonnan','real','nonnegative','nonzero','scalar', 'finite'};
            paramName = 'Timeout in seconds';
            validateattributes(val,classes,attributes,'',paramName);
            obj.BlockTimeout_ = val;
        end
    end
    
    methods(Access = protected)
        function setupImpl(obj) 
            if coder.target('Rtw')
                coder.cinclude('MW_SocketCAN.h');
                canInterface = [obj.DeviceID 0];
                stat1 = int32(-1);
                stat2 = int32(-1);
                isCANSetup = coder.nullcopy(int32(-1));
                isCANSetup = coder.ceval('MW_checkIFStatus',coder.rref(canInterface));
                if obj.SetupCAN
                    cmd = getSetupIPLinkCmd(obj);
                    isRealCAN = uint8(strcmp(obj.TypeofCAN,'Real'));
                    coder.ceval('MW_loadCANModules',coder.const(isRealCAN));
                    coder.ceval('MW_setupCANLink',coder.rref(cmd),coder.const(isRealCAN));
                    status = getSetUpIPLinkStatus(obj);
                    if status==0
                        isCANSetup = int32(0);
                    else
                        errString0 = ['Cannot set ' obj.DeviceID newline 0];
                        coder.ceval('MW_printError',coder.rref(errString0));
                        isCANSetup = int32(-1);
                    end
                end
                if isCANSetup==int32(0)
                    stat1 = coder.ceval('MW_createSocket',coder.rref(canInterface),...
                        coder.rref(obj.sockHandleDataFrames));
                    stat2 = coder.ceval('MW_createSocket',coder.rref(canInterface),...
                        coder.rref(obj.sockHandleErrorFrames));
                elseif isCANSetup==int32(1)
                    errString1 = [obj.DeviceID ' is not up. Set up ' obj.DeviceID ' before launching the application.'  newline 0];
                    coder.ceval('MW_printError',coder.rref(errString1));
                elseif isCANSetup==int32(2)
                    errString2 = [obj.DeviceID ' does not exist. Select a valid CAN interface.' newline 0];
                    coder.ceval('MW_printError',coder.rref(errString2));
                else
                    errString3 = [obj.DeviceID ' is not set up' newline 0];
                    coder.ceval('MW_printError',coder.rref(errString3));
                end
                if stat1==0 && stat2==0
                    obj.Initialized = true;
                else
                    obj.Initialized = false;
                end
            end
        end
        
        function status = stepImpl(obj,data)
            status = uint8(0);
            waitforInitialStep = uint8(obj.notFirstStep);
            if coder.target('Rtw')
                if obj.Initialized
                    txData = zeros(1,8,'uint8');
                    sockStatus = int32(0);
                    rxInterface = [obj.DeviceID 0];
                    isblocking = uint8(obj.BlockingMode_);
                    blockingTimeOut = double(obj.BlockTimeout_);
                    if strcmp(obj.InputDataType,'Raw data')
                        if ~obj.RemoteFrame
                            for i = 1:obj.MsgLength
                                if i <= length(data)
                                    txData(i) = uint8(data(i));
                                else
                                    txData(i) = uint8(0);
                                end
                            end
                        end
                        msgId = obj.MessageId;
                        msgLen = obj.MsgLength;
                        idType = strcmp(obj.IdentifierType,'Standard (11-bit identifier)');
                        sockStatus = coder.ceval('MW_CAN_transmitRaw',...
                            coder.rref(rxInterface),uint8(idType),uint32(msgId),...
                            uint8(msgLen),coder.rref(txData),...
                            uint8(obj.RemoteFrame),coder.wref(status),...
                            coder.const(isblocking),coder.const(blockingTimeOut),...
                            obj.sockHandleDataFrames,obj.sockHandleErrorFrames,...
                            waitforInitialStep);
                    else
                        %Input will be canMsg
                        if ~data.Remote
                            for i=1:data.Length
                                txData(i) = data.Data(i);
                            end
                        end

                        if data.Extended
                            idType = 0;
                        else
                            idType = 1;
                        end
                        sockStatus = coder.ceval('MW_CAN_transmitCANMsg',...
                            coder.rref(rxInterface),...
                            uint8(idType),uint32(data.ID),uint8(data.Length),...
                            coder.rref(txData),data.Remote,coder.wref(status),...
                            coder.const(isblocking),coder.const(blockingTimeOut),...
                            obj.sockHandleDataFrames,obj.sockHandleErrorFrames,...
                            waitforInitialStep);
                    end
                    if obj.BlockingMode_
                        obj.notFirstStep = true;
                    end
                    if (sockStatus~=0)
                        obj.Initialized = false;
                    end
                end
            else
                %Simulation part
            end
        end
        
        function releaseImpl(obj)
            if coder.target('Rtw')
                coder.cinclude('MW_SocketCAN.h');
                if obj.Initialized
                    canInterface = [obj.DeviceID 0];
                    coder.ceval('MW_clearSocket',coder.wref(obj.sockHandleDataFrames),...
                        coder.rref(canInterface));
                    coder.ceval('MW_clearSocket',coder.wref(obj.sockHandleErrorFrames),...
                        coder.rref(canInterface));
                end
            end
        end
        
        function cmd = getSetupIPLinkCmd(obj)
            cmd1 = ['sudo touch MW_SocketCAN_Error_IPLink.txt ; ' ...
                'sudo truncate -s 0 MW_SocketCAN_Error_IPLink.txt ;' ...
                ' sudo chmod 777 MW_SocketCAN_Error_IPLink.txt ; sudo ip link set '];
            if strcmp(obj.TypeofCAN,'Real')
                bitRate = coder.nullcopy('10000000');
                len = coder.nullcopy(int32(0));
                len = coder.ceval('MW_bitrate',coder.rref(bitRate));
                cmd = [cmd1 obj.DeviceID ' up type can bitrate ' bitRate(1:len) ' 2>MW_SocketCAN_Error_IPLink.txt' 0];
            else
                cmd = [cmd1 obj.DeviceID ' up type vcan 2>MW_SocketCAN_Error_IPLink.txt' 0];
            end
        end

        function status = getSetUpIPLinkStatus(obj)
            fileID = fopen('MW_SocketCAN_Error_IPLink.txt','r');
            assert(fileID~=-1);
            tline = fgetl(fileID);
            fclose(fileID);
            if ischar(tline)
                if isempty(tline)
                    status=0;
                elseif contains(tline,'RTNETLINK answers: Device or resource busy')
                    status=checkBitRate(obj);
                elseif contains(tline,['Cannot find device "' obj.DeviceID '"'])
                    coder.ceval('MW_printError',tline);
                    status=3;
                else
                    coder.ceval('MW_printError',tline);
                    status = -1;
                end
            else
                status = 0;
            end
        end

        function status = checkBitRate(obj)
            cmd = ['sudo touch MW_SocketCAN_GetBitRate.txt ; ' ...
                'sudo truncate -s 0 MW_SocketCAN_GetBitRate.txt ; ' ...
                'sudo chmod 777 MW_SocketCAN_GetBitRate.txt ; ' ...
                'sudo ip -det link show ' obj.DeviceID ' | grep bitrate | ' ...
                'awk ' '''{print $2}''' ' >MW_SocketCAN_GetBitRate.txt' 0];
            coder.ceval('MW_executeCommand',coder.rref(cmd));
            fileID = fopen('MW_SocketCAN_GetBitRate.txt','r');
            assert(fileID~=-1);
            tline = fgetl(fileID);
            fclose(fileID);
            inpBitRate = coder.nullcopy('10000000');
            len = coder.nullcopy(int32(0));
            len = coder.ceval('MW_bitrate',coder.rref(inpBitRate));
            if ischar(tline)
                if(strcmp(tline,inpBitRate(1:len)))
                    status = 0;
                else
                    status = 1;
                    errString1 = [obj.DeviceID ' is already set up with ' tline newline 0];
                    coder.ceval('MW_printError',coder.rref(errString1));
                end
            else
                % File is empty indicating there is no bitrate assiciated
                % with the CAN interface
                errString2 = ['Error fetching bitrate for ' obj.DeviceID newline 0];
                coder.ceval('MW_printError',coder.rref(errString2));
                status = 2;
            end
        end

        function flag = isInactivePropertyImpl(obj,propertyName)
            flag = false;
            switch propertyName
                case {'MessageId','IdentifierType','MsgLength','RemoteFrame'}
                    if ~(strcmp(obj.InputDataType,'Raw data'))
                        flag = true;
                    end
                case 'TypeofCAN'
                    flag = ~obj.SetupCAN;
                case 'BlockTimeout_'
                    flag = ~obj.BlockingMode_;
                otherwise
                    flag = false;
            end
        end
        
        function flag = isOutputComplexImpl(obj)
            if obj.OutputStatus
                flag = false;
            end
        end
        
        function num = getNumOutputsImpl(obj)
            if obj.OutputStatus
                num = 1;
            else
                num = 0;
            end
        end
        
        function dataType = getOutputDataTypeImpl(obj)%#ok
            dataType = 'uint8';
        end
        
        function out = getOutputSizeImpl(obj)%#ok
            out = [1,1];
        end
        
        function out = getNumInputsImpl(~)
            out = 1;
        end
        
        function validateInputsImpl(obj, data)
            if strcmp(obj.InputDataType,'Raw data')
                validateattributes(data, {'uint8'},{'nonnan','finite','size',[obj.MsgLength,1]}, '', 'data');
            else
                if  ~isstruct(data)
                    error(message('linux:utils:CANInvalidBusInput'));
                end
                if (~(isfield(data,'Extended') && isfield(data,'Length') ...
                        && isfield(data,'Remote') && isfield(data,'Error') ...
                        && isfield(data,'ID') && isfield(data,'Timestamp') ...
                        && isfield(data,'Data')))
                    error(message('linux:utils:CANInvalidBusInput'));
                end
            end
        end
        
        function maskDisplayCmds = getMaskDisplayImpl(obj)
            
            IDStr = ['Message ID: ',num2str(obj.MessageId)];
            
            maskDisplayCmds = [ ...
                ['color(''white'');', newline]...                                     % Fix min and max x,y co-ordinates for autoscale mask units
                ['plot([100,100,100,100],[100,100,100,100]);',newline]...
                ['plot([0,0,0,0],[0,0,0,0]);',newline]...
                ['color(''blue'');',newline] ...                                     % Drawing mask layout of the block
                ['text(99, 92, ''' obj.Logo ''', ''horizontalAlignment'', ''right'');',newline] ...
                ['color(''black'');',newline] ...
                ];
            
            if strcmp(obj.InputDataType,'Raw data')
                maskDisplayCmds = [maskDisplayCmds,...
                    ['text(50,60,''\fontsize{12}\bfCAN Transmit'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline], ...
                    ['text(50,40,''\fontsize{10}' IDStr ''',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline] ...
                    ];
            else
                maskDisplayCmds = [maskDisplayCmds,...
                    ['text(50,50,''\fontsize{12}\bfCAN Transmit'',''texmode'',''on'',''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline], ...
                    ];
            end
            
        end
    end
    
    
    methods(Static, Access=protected)
        function header = getHeaderImpl()
            MaskTitle = getString(message('linux:blockmask:CANTransmitMaskTitle'));
            MaskText = getString(message('linux:blockmask:CANTransmitMaskDescription'));
            header = matlab.system.display.Header(mfilename('class'),...
                'ShowSourceLink', false, ...
                'Title',MaskTitle, ...
                'Text', MaskText);
        end
        
        function  groups = getPropertyGroupsImpl
            % Define section for properties in System block dialog box.
            DeviceIDProp = matlab.system.display.internal.Property(...
                'DeviceID','Description','CAN interface');
            SetupCANProp = matlab.system.display.internal.Property(...
                'SetupCAN','Description','Set up CAN interface');
            TypeofCANProp = matlab.system.display.internal.Property(...
                'TypeofCAN','Description','CAN interface type');
            InputDataTypeProp = matlab.system.display.internal.Property(...
                'InputDataType', 'Description', 'Data is input as');
            IDProp = matlab.system.display.internal.Property(...
                'MessageId', 'Description', 'Message ID');
            IdentifierTypeProp = matlab.system.display.internal.Property(...
                'IdentifierType', 'Description', 'Identifier type');
            MessageLengthProp = matlab.system.display.internal.Property(...
                'MsgLength', 'Description', 'Message length');
            RemoteFrameProp = matlab.system.display.internal.Property(...
                'RemoteFrame', 'Description', 'Request remote frame');
            OutputStatusProp = matlab.system.display.internal.Property(...
                'OutputStatus', 'Description', 'Output status');
            BlockingModeProp = matlab.system.display.internal.Property(...
                'BlockingMode_', 'Description', 'Wait until data sent');
            BlockTimeoutProp = matlab.system.display.internal.Property(...
                'BlockTimeout_', 'Description', 'Timeout in seconds');
            
            paramGroup = matlab.system.display.Section(...
                'Title', 'Parameters', 'PropertyList', ...
                {DeviceIDProp,SetupCANProp,TypeofCANProp,...
                InputDataTypeProp,BlockingModeProp,BlockTimeoutProp,...
                OutputStatusProp});
            
            messageGroup = matlab.system.display.Section(...
                'Title', 'Message', 'PropertyList', ...
                {IdentifierTypeProp,IDProp,MessageLengthProp,RemoteFrameProp});
            
            groups = [paramGroup,messageGroup];
        end
        
        function isVisible = showSimulateUsingImpl
            isVisible = false;
        end
    end
    
    methods (Hidden, Static)
        function name = getDescriptiveName()
            name = 'CAN Transmit';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        
        function updateBuildInfo(buildInfo, context)
            if context.isCodeGenTarget('rtw')
                % Update buildInfo
                rootDir = realtime.internal.getLinuxRoot();
                addIncludePaths(buildInfo, fullfile(rootDir, 'include'));
                addIncludeFiles(buildInfo, 'MW_SocketCAN.h');
                systemTargetFile = get_param(buildInfo.ModelName,'SystemTargetFile');
                if isequal(systemTargetFile,'ert.tlc')
                    addSourcePaths(buildInfo, fullfile(rootDir, 'src'));
                    addSourceFiles(buildInfo, 'MW_SocketCAN.c', fullfile(rootDir, 'src'), 'BlockModules');
                end
            end
        end
    end
    
end