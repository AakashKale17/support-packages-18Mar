/* Copyright 2012-2016 The MathWorks, Inc.*/
#include "MW_gpio.h"
#if !( defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER) )

int numGpio = 0;                // Number of GPIO modules used
GPIO_info *gpioInfo = NULL;     // Structure array holding GPIO info

int GPIO_isExported(const uint32_T gpio)
{
    char buf[GPIO_MAX_BUF];
    struct stat statBuf;
    
    snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR  "/gpio%d", gpio);
    if (stat(buf, &statBuf) == -1) {
        return 0;
    }
    else {
        return 1;
    }
}

// Export specified GPIO pin
static int GPIO_export(const uint32_T gpio)
{
    int fd, len;
    char buf[GPIO_MAX_BUF];
    ssize_t bytesWritten;
    
    // If the pin is exported, return        
    if (GPIO_isExported(gpio)) {
        return 0;
    }
    
    // Write GPIO pin number to /sys/class/gpio/export file
    fd = open(SYSFS_GPIO_DIR "/export", O_WRONLY);
    if (fd < 0) {
        perror("GPIO_export/open");
        return -1;
    }
    len = snprintf(buf, sizeof(buf), "%d", gpio);
    bytesWritten = write(fd, buf, len);
    close(fd);
    if (bytesWritten < 0) {
        perror("GPIO_export/write");
        return -2;
    }
    
    return 0;
}

// Remove specified GPIO pin from export list
static int GPIO_unexport(const uint32_T gpio)
{
    int fd, len;
    char buf[GPIO_MAX_BUF];
    ssize_t bytesWritten;
    
    fd = open(SYSFS_GPIO_DIR "/unexport", O_WRONLY);
    if (fd < 0) {
        perror("GPIO_unexport/open");
        return -1;
    }
    len = snprintf(buf, sizeof(buf), "%d", gpio);
    bytesWritten = write(fd, buf, len);
    close(fd);
    if (bytesWritten < 0) {
        perror("GPIO_unexport/write");
        return -2;
    }
    
    return 0;
}

// Set direction of the GPIO pin
static int GPIO_setDirection(const uint32_T gpio, const uint32_T direction)
{
    int fd;
    char buf[GPIO_MAX_BUF];
    ssize_t bytesWritten;
    
    snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR  "/gpio%d/direction", gpio);
    
    // Open device file
    fd = open(buf, O_WRONLY);
    if (fd < 0) {
        perror("GPIO_setDirection/open");
        return -1;
    }
    
    // Set direction
    if (direction == GPIO_DIRECTION_INPUT) {
        bytesWritten = write(fd, "in", 3);
    }
    else {
        bytesWritten = write(fd, "out", 4);
    }
    close(fd);
    if (bytesWritten < 0) {
        perror("GPIO_setDirection/write");
        return -2;
    }
    
    return 0;
}

// Get direction of the GPIO pin
static uint8_T GPIO_getDirection(const uint32_T gpio)
{
    int fd;
    char buf[GPIO_MAX_BUF];
    ssize_t ret;

    // Open device file
    snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR  "/gpio%d/direction", gpio);
    fd = open(buf, O_RDONLY);
    if (fd < 0) {
        perror("GPIO_getDirection/open");
        return GPIO_DIRECTION_NA;
    }
    
    // Read direction
    ret = read(fd, buf, 16);
    close(fd);
    if (ret < 0) {
        perror("GPIO_getDirection/read");
        return GPIO_DIRECTION_NA;
    }
    buf[ret] = 0;
    if (strncmp(buf, "in", 2) == 0) {
        return GPIO_DIRECTION_INPUT;
    }
    else {
        return GPIO_DIRECTION_OUTPUT;
    }
}

/* Return the direction of the given digital pin */
int EXT_GPIO_getStatus(unsigned int gpio, uint8_T *pinStatus)
{
    char buf[GPIO_MAX_BUF];
    struct stat statBuf;
    
    snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR  "/gpio%d/direction", gpio);
    if (stat(buf, &statBuf) == -1) {
        LOG_PRINT(stdout, "Cannot stat gpio%d\n", gpio);
        if (GPIO_export(gpio) != 0) {
            LOG_PRINT(stdout, "Cannot export gpio%d\n", gpio);
            *pinStatus = GPIO_DIRECTION_NA;
        }
        else {
            *pinStatus = GPIO_getDirection(gpio);
            GPIO_unexport(gpio);
        }
    }
    else {
        *pinStatus = GPIO_getDirection(gpio);
    }
    
    return 0;
}

// Open GPIO device
static int GPIO_open(const uint32_T pin, const uint32_T direction)
{
    int fd;
    char buf[GPIO_MAX_BUF];
    ssize_t bytesWritten;
    
    snprintf(buf, sizeof(buf), SYSFS_GPIO_DIR "/gpio%d/value", pin);
    if (direction == GPIO_DIRECTION_INPUT) {
        fd = open(buf, O_RDONLY | O_NONBLOCK);
    }
    else {
        fd = open(buf, O_WRONLY | O_NONBLOCK);
    }
    if (fd < 0) {
        perror("GPIO_open/open");
    }
    return fd;
}

// Close GPIO device
static int GPIO_close(int fd)
{
    int ret;
    
    ret = close(fd);
    if (ret < 0) {
        // EBADF, EINTR, EIO: In all cases, descriptor is torn down
        perror("GPIO_close/close");
        return -1;
    }
    return 0;
}

// Return resources used for GPIO gpioExit
static void GPIO_exit(void)
{
    if (gpioInfo != NULL) {
        free(gpioInfo);
    }
    exit(EXIT_FAILURE);
}

// Return a pointer to GPIO info structure for a given GPIO
GPIO_info *MW_getGpioInfo(const uint32_T pin)
{
    int i;
    GPIO_info *ptr = NULL;
    
    for (i = 0; i < numGpio; i++) {
        if (gpioInfo[i].pin == pin) {
            ptr = &gpioInfo[i];
            break;
        }
    }
    
    return ptr;
}

// Dump GPIO information to command line
void MW_dumpGpioInfo(const uint8_T *text)
{
    int i;
    
    printf("%s:\n", text);
    if (gpioInfo == NULL) {
        printf("Nothing to dump. gpioInfo == NULL\n");
    }
    for (i = 0; i < numGpio; i++) {
        printf("GPIO = %d, dir = %d, res = %d, fd = %d\n",
                gpioInfo[i].pin, gpioInfo[i].direction, gpioInfo[i].fd);
    }
}

// Initialize GPIO module
int EXT_GPIO_init(const unsigned int gpio, const uint8_T direction)
{
    GPIO_info *gpioInfoPtr = NULL;
    
    // Get GPIO information pointer if already allocated
    gpioInfoPtr = MW_getGpioInfo(gpio);
    if (gpioInfoPtr == NULL) {
        gpioInfo = realloc(gpioInfo, (numGpio + 1) * sizeof(GPIO_info));
        if (gpioInfo == NULL) {
            fprintf(stderr, "Error allocating memory for GPIO pin %d.\n", gpio);
            GPIO_exit();
        }
        gpioInfoPtr = gpioInfo + numGpio;
    }
    
    //Fill in GPIO info structure for the GPIO module
    gpioInfoPtr->pin       = gpio;
    gpioInfoPtr->direction = direction;
    gpioInfoPtr->fd        = -1;
    numGpio++;

    if (GPIO_export(gpio) != 0) {
        return ERR_GPIO_INIT_EXPORT;
    }
	if (GPIO_setDirection(gpio, direction) != 0) { 
        return ERR_GPIO_INIT_DIRECTION;
    }
    gpioInfoPtr->fd = GPIO_open(gpio, direction);
    if (gpioInfoPtr->fd < 0) {
        return ERR_GPIO_INIT_OPEN;
    }
    
    // Success
    return 0;
}

// Close GPIO module
int EXT_GPIO_terminate(const unsigned int gpio)
{
    GPIO_info *gpioInfoPtr = NULL;
    static int32_T numClosedGpio = 0;
    
    // Get GPIO information pointer and close the GPIO file descriptor
    gpioInfoPtr = MW_getGpioInfo(gpio);
    if (gpioInfoPtr == NULL) {
        return -1;
    }
    
    /* Close and unexport only those GPIO which are initilaized */
    if (GPIO_close(gpioInfoPtr->fd) < 0) {
        fprintf(stderr, "Error closing GPIO module.\n");
    }
    if (GPIO_unexport(gpio) < 0) {
        fprintf(stderr, "Error closing GPIO module.\n");
    }
    numClosedGpio++;
    if ((numClosedGpio == numGpio) && !gpioInfo) {
        free(gpioInfo);
    }
    
    // Success
    return 0;
}

// Read value from given GPIO pin
int EXT_GPIO_read(const unsigned int gpio, boolean_T *value)
{
    GPIO_info *gpioInfoPtr = NULL;
    char strVal;
    
    printf(" RJ EXT_GPIO_read trying to read gpio %d\n",gpio);
    
    // Get GPIO information pointer
    gpioInfoPtr = MW_getGpioInfo(gpio);
    lseek(gpioInfoPtr->fd, 0, SEEK_SET);
    if (read(gpioInfoPtr->fd, &strVal, 1) < 0) {
        return ERR_GPIO_READ_READ;
    }
    
     printf(" RJ EXT_GPIO_read done reading gpio %d, val = %c\n",gpio,strVal);
    // The sysfs returns the value as a char. Convert the value to bool.
    *value = (boolean_T)(strVal - '0');
    
    // Success
    return 0;
}

// Write value to given GPIO pin
int EXT_GPIO_write(const unsigned int gpio, const boolean_T value)
{
    GPIO_info *gpioInfoPtr = NULL;
    ssize_t ret;
    
    // Get GPIO information pointer
    gpioInfoPtr = MW_getGpioInfo(gpio);
    lseek(gpioInfoPtr->fd, 0, SEEK_SET);
    if (value) {
        ret = write(gpioInfoPtr->fd, "1", 2);
        printf(" RJ EXT_GPIO_write write 1 to gpio %d\n",gpio);
    }
    else {
        ret = write(gpioInfoPtr->fd, "0", 2);
        printf(" RJ EXT_GPIO_write write 0 to gpio %d\n",gpio);
    }
    if (ret < 0) {
        return ERR_GPIO_WRITE_WRITE;
    }
    
    // Success
    return 0;
}
#endif
/* [EOF] */