/* Copyright 2016 The MathWorks, Inc. */
#ifndef __MW_SDL_VIDEO_DISPLAY_H__
#define __MW_SDL_VIDEO_DISPLAY_H__
#include "rtwtypes.h"
#ifdef __cplusplus
extern "C" {
#endif

#if (defined(MATLAB_MEX_FILE) || defined(EXT_MODE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER))
 /* Rapid Accelerator Mode */
 #define MW_SDL_videoDisplayInit(pixelFormat,pixelOrder,rowMajor,width,height,windowTitle) 0
 #define MW_SDL_videoDisplayOutput(pln0,pln1,pln2,displayId)
 #define MW_SDL_videoDisplayTerminate(width,height,displayId)   
 #define MW_SDL_videoDisplayTitle(title,displayId)   
#else
/* Code generation */ 
#if defined(__linux__) 
 #include "SDL2/SDL.h"
#else
 #include "SDL.h"
#endif
int MW_SDL_videoDisplayInit(
    int32_T pixelFormat, 
    int32_T pixelOrder, 
    int32_T rowMajor,
    int32_T width, 
    int32_T height,
    char* windowTitle);
void MW_SDL_videoDisplayOutput(const uint8_T *pln0, const uint8_T *pln1, const uint8_T *pln2, const int displayId);
void MW_SDL_videoDisplayTerminate(int32_T width, int32_T height, int32_T displayId);
void MW_SDL_videoDisplayTitle(char* title, int32_T displayId);
#endif

#ifdef __cplusplus
}
#endif
#endif