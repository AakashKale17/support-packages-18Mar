classdef MQTTPublish < matlab.System & coder.ExternalDependency
    % Publish data to MQTT broker.
    
    % Copyright 2018-2023 The MathWorks, Inc.
    
    %#codegen
    %#ok<*EMCA>
    
    properties (Nontunable)
        % Topic
        Topic = 'topic/level';
        % QoS
        QoS = '0';
        % Block platform
        blockPlatform = 'LINUX';
    
        % Retain message
        RetainMsg (1, 1) logical = false;
    end
    
    properties (Hidden,Nontunable)
        QoSIntVal = int32(0);
        RetainFlag = 0;
    end
    
    properties (Constant, Hidden)
        QoSSet = matlab.system.StringSet({'0', '1', '2'});
        Wildcard1 = '#';
        Wildcard2 = '+';
        MAXTOPICLEN = 128;
    end
    
    properties (Hidden)
        MW_dataType
    end
    
    methods
        % Constructor
        function obj = MQTTPublish(varargin)
            %This would allow the code generation to proceed with the
            %p-files in the installed location of the support package.
            coder.allowpcode('plain');
            setProperties(obj,nargin,varargin{:});
        end
        
        function set.Topic(obj, val)
            coder.extrinsic('error');
            coder.extrinsic('message');
            
            validateattributes(val, ...
                {'char'}, {'nonempty'}, '', 'Topic');
            
            topicLen = numel(val);
            if (topicLen > obj.MAXTOPICLEN)
                error(message('linux:utils:InvalidTopicLength'));
            end
            
            val = strtrim(val);
            
            % Wildcards are not allowed in publish topic
            if (contains(val,'#') || contains(val,'+'))
                error(message('linux:utils:InvalidTopicStr'));
            end
            
            obj.Topic = val;
        end
        
    end
    
    methods (Access = protected)
        %% Common functions
        function setupImpl(obj, varargin)
            % Implement tasks that need to be performed only once,
            % such as pre-computed constants.
            obj.QoSIntVal = int32(obj.getQoSIntVal);
            if obj.RetainMsg
                obj.RetainFlag = int32(1);
            else
                obj.RetainFlag = int32(0);
            end
            
            if ~isempty(coder.target)
                coder.cinclude('MW_MQTT.h');
                coder.ceval('MW_MQTT_publish_setup');
            end
        end
        
        function valOut = getQoSIntVal(obj)
            valIn = obj.QoS;
            switch valIn
                case '0'
                    valOut = 0;
                case '1'
                    valOut = 1;
                case '2'
                    valOut = 2;
                otherwise
                    valOut = 0;
            end
        end
        
        function status = stepImpl(obj, dataIn)
            % Implement algorithm. Calculate y as a function of
            % input u and discrete states.
            status = int8(0);
            dataPayloadLen = uint32(numel(dataIn));
            stringPayloadLen = uint32(0);
            if ~isempty(coder.target)
                payLoadStr = coder.opaque('char*','NULL');
                coder.ceval('MW_sprintf_mqtt', dataPayloadLen, coder.ref(dataIn), coder.wref(payLoadStr), coder.wref(stringPayloadLen));
                topicStr = cstr(obj.Topic);
                coder.ceval('MW_MQTT_publish_step',obj.RetainFlag, obj.QoSIntVal, stringPayloadLen, coder.ref(payLoadStr), coder.ref(topicStr), coder.wref(status));
            end
        end
        
        function N = getNumInputsImpl(~)
            % Specify number of System inputs
            N = 1;
        end
        
        function N = getNumOutputsImpl(~)
            % Specify number of System outputs
            N = 1;
        end
        
        function N = getOutputSizeImpl(~)
            N = [1,1];
        end
        
        function validateInputsImpl(~, Msg)
            validateattributes(Msg,{'uint8'},{'2d','nonnan','finite'},'','Msg');
            if (numel(Msg) > 64)
                error(message('linux:utils:InvalidInputVector'));
            end
        end
        
        function out = getOutputDataTypeImpl(~)
            % Return data type for each output port
            out = 'int8';
        end
        
        
        
        function maskDisplayCmds = getMaskDisplayImpl(obj)
            %Icon display
            iconstr = obj.Topic;
            if ~isempty(regexp(iconstr,'\'' *\''','match'))
                iconstr = '';
            end
            
            maskDisplayCmds = { ...
                ['color(''white'');', newline],...    % Fix min and max x,y co-ordinates for autoscale mask units
                ['plot([100,100,100,100],[100,100,100,100]);', newline],... % Drawing mask layout of the block
                ['plot([0,0,0,0],[0,0,0,0]);', newline],...
                ['color(''black'');', newline] ...
                ['port_label(''input'',1,''Message'');', newline]...
                ['port_label(''output'',1,''Status'');', newline]...
                ['text(70, 12,''' iconstr ''', ''horizontalAlignment'',''center'',''verticalAlignment'',''middle'');',newline]...
                };
            
            labelSample = obj.blockPlatform;
            maskDisplayCmdsTarget = { ...
                ['color(''blue'');', newline],...
                ['text(145, 90, ''' labelSample ''', ''horizontalAlignment'', ''right'');', newline]...
                };
            maskDisplayCmds = [maskDisplayCmds maskDisplayCmdsTarget];
        end
        
    end
    
    methods(Static, Access = protected)
        %% Simulink customization functions
        function simMode = getSimulateUsingImpl(~)
            simMode = 'Interpreted execution';
        end
        
        function isVisible = showSimulateUsingImpl
            isVisible = false;
        end
        
         function [groups, PropertyList] = getPropertyGroupsImpl 
            %BlockLabel Block Label
            TopicProp = matlab.system.display.internal.Property('Topic', 'Description', 'Topic');
            %ServerIPAddress Server IP address
            QoSProp = matlab.system.display.internal.Property('QoS', 'Description', 'QoS');
            % Retain messgae
            RetainMsgProp = matlab.system.display.internal.Property('RetainMsg', 'Description', 'Retain Message');
            %BlockPlatform
            BlockPlatformProp = matlab.system.display.internal.Property('blockPlatform', 'Description', 'Block Platform','IsGraphical',false);
            
            % Property list
            PropertyList ={ TopicProp, QoSProp, RetainMsgProp, BlockPlatformProp};
            
            % Create mask display
            Group = matlab.system.display.Section(...
                'PropertyList',PropertyList);
            
            groups = Group;

            % Return property list if required
            if nargout > 1
                PropertyList = PropertyListOut;
            end
        end
        
        function header = getHeaderImpl(~)
            % Define header for the System block dialog box.
            MaskText = getString(message('linux:blockmask:MQTTPublishMask'));
            header = matlab.system.display.Header(mfilename('class'),...
                'ShowSourceLink', false, ...
                'Title','MQTT Publish', ...
                'Text', MaskText);
        end
        
    end
    
    methods (Static)
        function name = getDescriptiveName(~)
            name = 'MQTT Publish';
        end
        
        function b = isSupportedContext(context)
            b = context.isCodeGenTarget('rtw');
        end
        
        function updateBuildInfo(buildInfo, context)
            % Update the build-time buildInfo
            if context.isCodeGenTarget('rtw')
                % Header paths
                rootDir = realtime.internal.getLinuxRoot();
                buildInfo.addIncludePaths(fullfile(rootDir,'include'));
                buildInfo.addIncludeFiles('MW_MQTT.h');
                systemTargetFile = get_param(buildInfo.ModelName,'SystemTargetFile');
                if isequal(systemTargetFile,'ert.tlc')
                    % Add the following when not in rapid-accel simulation
                    buildInfo.addSourceFiles('MW_MQTT.c',fullfile(rootDir,'src'));
                    codertarget.linux.remotebuild.addTargetSpecificLibs(buildInfo,'-lpaho-mqtt3as');
                end
            end
        end
    end
end

% Internal functions
function str = cstr(str)
str = [str(:).', char(0)];
end