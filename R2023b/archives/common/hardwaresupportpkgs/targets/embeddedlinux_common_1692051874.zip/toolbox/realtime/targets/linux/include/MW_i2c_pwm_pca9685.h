/* Copyright 2021 The MathWorks, Inc. */
#ifndef _MW_I2C_PWM_PCA9685_H_
#define _MW_I2C_PWM_PCA9685_H_

#include "rtwtypes.h"

#ifdef __cplusplus
extern "C" {
#endif

#if (defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER))
/* This will be used in Rapid Accelerator Mode */

#define i2c_pwm_pca9685_writeToFile(a)       (0)
#define i2c_pwm_pca9685_setup(a,b,c,d,e,f,g)       (0)
#define i2c_pwm_pca9685_step(a,b,c,d,e,f)            (0)
#define i2c_pwm_pca9685_terminate(a,b,c,d)         (0)
    
#else

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>    
    
/* Local defines */
#define SYSFS_I2C_PWM_PCA9685_DIR    "/sys/class/pwm/pwmchip0"

/* Function declarations */
int i2c_pwm_pca9685_writeToFile(uint32_T data);
int i2c_pwm_pca9685_setup(uint8_T panChannel, uint8_T tiltChannel, uint8_T panEnabled, uint8_T tiltEnabled, uint32_T period, uint32_T panPulse, uint32_T tiltPulse);
int i2c_pwm_pca9685_step(uint8_T panChannel, uint8_T tiltChannel, uint8_T panEnabled, uint8_T tiltEnabled, uint32_T panPulse, uint32_T tiltPulse);
int i2c_pwm_pca9685_terminate(uint8_T panChannel, uint8_T tiltChannel, uint8_T panEnabled, uint8_T tiltEnabled);

#endif

#ifdef __cplusplus
}
#endif
#endif

