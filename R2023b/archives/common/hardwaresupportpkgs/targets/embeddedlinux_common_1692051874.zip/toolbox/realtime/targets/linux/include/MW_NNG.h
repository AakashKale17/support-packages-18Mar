/* Copyright 2022 The MathWorks, Inc. */
/* MW_NNG.c*/

#ifndef _MW_NNG_H_
#define _MW_NNG_H_

#ifdef __cplusplus
extern "C" { /* sbcheck:ok:extern_c */
#endif

#include "rtwtypes.h"
#include <stdio.h>
#include <stdint.h>

#if (defined(MATLAB_MEX_FILE)  || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER))
// Rapid Accelerator Mode
#define NNGReceiveChunk_t void
#define NNGReceiveData_t void
#define NNGSendData_t void

#define MW_NNG_initSendSocket(a) (NULL)
#define MW_NNG_initReceiveSocket(a,b,c) (NULL)
#define MW_NNG_send(a,b,c) 0
#define MW_NNG_stepReceive(a,b,c) 0
#define MW_NNG_clearSendSocket(a)
#define MW_NNG_clearReceiveSocket(a)

#else

#include <pthread.h>
#include <nng/nng.h>

typedef struct {
    uint8_t *dataReceived;
    size_t dataLen;
    bool newData;
} NNGReceiveChunk_t;
        
typedef struct {
    nng_socket sock;
    double sampleTime;
    NNGReceiveChunk_t dataRead;
    pthread_mutex_t readData_mutex;
    pthread_cond_t readData_cond_mutex;
    pthread_t recvThread;
} NNGReceiveData_t;

typedef struct {
    nng_socket sock;
} NNGSendData_t;

NNGSendData_t* MW_NNG_initSendSocket(const char *customURL);
NNGReceiveData_t* MW_NNG_initReceiveSocket(const char *customURL, const double sampleTime, uint32_t dataLen);
int MW_NNG_send(NNGSendData_t* NNGSendDataPtr, uint8_t *data, uint32_t dataLen);
int MW_NNG_stepReceive(NNGReceiveData_t *NNGReadDataPtr, uint8_t *data, uint32_t dataLen);
void MW_NNG_clearSendSocket(NNGSendData_t *NNGSendDataPtr);
void MW_NNG_clearReceiveSocket(NNGReceiveData_t *NNGReadDataPtr);

#endif //Rapid accel

#ifdef __cplusplus
}
#endif

#endif //_MW_NNG_H_