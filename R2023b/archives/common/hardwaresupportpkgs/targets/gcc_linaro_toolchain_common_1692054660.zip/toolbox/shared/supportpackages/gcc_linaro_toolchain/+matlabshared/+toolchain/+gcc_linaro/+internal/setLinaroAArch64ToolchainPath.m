function setLinaroAArch64ToolchainPath(toolchainPath)
% This function is called internally from DeepLearningConfig.Prebuild.ValidateCrossCompile function.
% This function is primarily to validate the path specified by the user and set env Var for 64 bit .
    envVar = matlab.lang.makeValidName('LINARO_TOOLCHAIN_6.3.1_AARCH64');
    validationSuccess = matlabshared.toolchain.gcc_linaro.internal.validateLinaroAArch64ToolchainPath(toolchainPath);
    if validationSuccess
       setenv(envVar, toolchainPath) 
       disp(['###  Linaro AArch64 Toolchain Path was set to "' toolchainPath '" successfully.']);
    else
       error(message('gpucoder:cnnconfig:InvaidToolchainPathSpecified', toolchainPath, 'AArch64'))
    end
end