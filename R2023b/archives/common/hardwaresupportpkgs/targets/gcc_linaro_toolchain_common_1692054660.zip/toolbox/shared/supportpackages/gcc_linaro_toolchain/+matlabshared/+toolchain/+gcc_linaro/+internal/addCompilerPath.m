function addCompilerPath(varargin)
%ADDCOMPILERPATH Add Linaro compiler path to the MATLAB shell path

% Common for both 32 and 64 bit.
%   Copyright 2018 The MathWorks, Inc.
narginchk(2,2);
% First argument accepts the Version and the Second argument accepts ARM Architecture.
% Validate Arm Architecture
validatestring(varargin{2},{'AARCH32','AARCH64'},'addCompilerPath','ARM Architecture',2);
armArch = varargin{2};
% 32 bit toolchain previously accepts two versions.
% 64 bit toolchain previously defaults to '6.3.1' version.
if contains(armArch, 'aarch32','IgnoreCase',true)
    % Validate Toolchain Binary Version
    validatestring(varargin{1},{'6.2.1','6.3.1'},'addCompilerPath','GCC Version',1);
    thirdpartyTool = 'linarogcctoolchain_aarch32.instrset';
    thirdpartyToolSoC = 'linarogcctoolchain_aarch32_soc.instrset';
else
    % Validate Toolchain Binary Version
    validatestring(varargin{1},{'6.3.1'},'addCompilerPath','GCC Version',1);
    thirdpartyTool = 'linarogcctoolchain_6_3.instrset';
    thirdpartyToolSoC = 'linarogcctoolchain_6_3_soc.instrset';
end
gccVersion = varargin{1};
% Generate the env var based on the Arch and the Version.
% Mantain the uniform environment variable name for both 64 bit and 32 bit. This env Var is not exposed. This is internal env var used to set the path for toolchain binaries.
envVar = matlab.lang.makeValidName(['LINARO_TOOLCHAIN_',gccVersion,'_', upper(armArch)]);
% Get the value of the environment variable set.
compilerPath = getenv(envVar);


if isempty(compilerPath) % User doesn't specify the path for toolchain binaries.
    % when the env var is not set. Get the 3p Install Location.
    rootDir =  matlab.internal.get3pInstallLocation(thirdpartyTool); % Looking for 3p binaries .
    if isempty(rootDir) % If 3p binaries were not found. Check other 3p component for ARM 64 bit.
        rootDir =  matlab.internal.get3pInstallLocation(thirdpartyToolSoC);
    end
    binFolder = fullfile(rootDir, 'bin');
    if ispc
        compilerPath  = RTW.transformPaths(binFolder, 'pathType', 'alternate');
        compilerPath  = strrep(compilerPath, '\', '/');
    else
        compilerPath  = binFolder;
    end
end
% Specify the path for toolchain binaries.
setenv(envVar, compilerPath);
if contains(armArch, 'aarch64','IgnoreCase',true)
    envVar = matlab.lang.makeValidName(['LINARO_TOOLCHAIN_',gccVersion,'_', '64_BIT']);   % for soc back port
    setenv(envVar, compilerPath);
end
end
