function setLinaroToolchainPath(varargin)
%setLinaroToolchainPath - sets the location of the Linaro 6.3.1 

%   Copyright 2018 The MathWorks, Inc.

tpLocation = matlab.internal.get3pInstallLocation('linarogcctoolchain_6_3.instrset');
if isempty(tpLocation)
    tpLocation = matlab.internal.get3pInstallLocation('linarogcctoolchain_6_3_soc.instrset');
end

setenv('LINARO_TOOLCHAIN_v631_INSTALL_PATH', tpLocation);

