function out = getLinaroToolchainPath
%getLinaroToolchainPath - gets the location of the Linaro 6.3.1 Toolchain

%   Copyright 2018 The MathWorks, Inc.

out = matlab.internal.get3pInstallLocation('linarogcctoolchain_6_3.instrset');
if isempty(out)
    out = matlab.internal.get3pInstallLocation('linarogcctoolchain_6_3_soc.instrset');
end
