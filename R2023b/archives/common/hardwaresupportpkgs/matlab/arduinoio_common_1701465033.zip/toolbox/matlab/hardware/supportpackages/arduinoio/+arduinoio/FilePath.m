function out = FilePath(filename)

%   Copyright 2015-2018 The MathWorks, Inc.

[out,~,~] = fileparts(filename);

end