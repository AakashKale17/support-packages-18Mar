classdef WindowsUtility < arduinoio.internal.Utility
%   Utility class used on Windows platform

%   Copyright 2014-2020 The MathWorks, Inc.
    
    methods(Access = {?arduinoio.internal.UtilityCreator, ?arduino.accessor.UnitTest})
        % Private constructor with limited access to only utility factory class
        % and test class
        function obj = WindowsUtility
        end
    end
    
    methods(Access = public)
        function buildInfo = setProgrammer(~, buildInfo)
            buildInfo.Programmer = fullfile(buildInfo.IDEPath, 'arduino_debug');
            buildInfo.TempDirPath = fullfile(tempdir,strcat('ArduinoServer',buildInfo.Board));
        end
    end
end



