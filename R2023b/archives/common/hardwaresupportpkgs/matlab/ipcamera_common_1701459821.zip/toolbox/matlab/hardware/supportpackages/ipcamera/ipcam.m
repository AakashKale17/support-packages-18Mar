classdef ipcam < matlab.mixin.CustomDisplay & handle & matlab.mixin.SetGet...
        & ipcamera.internal.DataUtilityHelper
    %IPCAM Creates an ipcam object to acquire frames from your IP Camera.
    %
    %    CAMOBJ = IPCAM(URL) returns a ipcam object, CAMOBJ, that acquires
    %    images from the specified URL. The URL is the MJPEG over HTTP/RTSP
    %    or H.264 over RTSP URL provided by your IP camera.
    %
    %    CAMOBJ = IPCAM(URL, USERNAME, PASSWORD) returns an ipcam object,
    %    CAMOBJ, that acquires images from the specified URL with
    %    authentication provided by the USERNAME and PASSWORD. The URL is
    %    the MJPEG over HTTP/RTSP or H.264 over RTSP URL provided by your
    %    IP camera.
    %
    %    CAMOBJ = IPCAM(..., P1, V1) constructs an ipcam object, CAMOBJ,
    %    with the specified property values. If an invalid property name or
    %    property value is specified, the ipcam object is not created.
    %
    %    Example:
    %       % Construct an ipcam object
    %       camObj = ipcam('http://192.168.0.20/video/mjpg.cgi');
    %
    %       % Preview a stream of image frames.
    %       preview(camObj);
    %
    %       % Acquire and display a single image frame.
    %       img = snapshot(camObj);
    %       imshow(img);
    
    % Copyright 2015-2023 The MathWorks, Inc.
    properties (SetAccess = private, GetAccess = public)
        
        %URL A String specifying the MJPEG over HTTP/RTSP or H.264 over
        %RTSP URL
        URL
        
        %Username A String specifying the Username for authentication of IP
        %Camera
        Username
        
        %Password A String specifying the Password for authentication of IP
        %Camera
        Password
        
    end
    
    properties (SetAccess = private, GetAccess = public, Hidden)
        AuthenticationType = "NA";
        CompressionFormat = "NA";
        URLType = "NA";
    end
    
    properties (Access = public)
        %Timeout Specifies the time in seconds the snapshot method will
        %wait to get an image data from the camera
        Timeout (1,1) {mustBeNumeric, mustBeNonempty, mustBePositive} = 10
    end
    
    methods (Access = public)
        
        function obj = ipcam(url, username, password, options)
            arguments
                url (1,:) {mustBeTextScalar, mustBeNonzeroLengthText}
                username (1,:) {mustBeTextScalar} = ""
                password (1,:) {mustBeTextScalar} = ""
                options.Timeout (1,1) {mustBeNumeric, mustBeNonempty, mustBePositive} = 10
            end
            try 
                % Initialize clean up function
                c = onCleanup(@() integrateData(obj, obj.Timeout, obj.URLType,...
                    obj.CompressionFormat, obj.AuthenticationType));
                ipcamera.internal.Utility.loadResources();
                % Validate the MATLAB preference for H.264 decoding
                % This function will create a new MATLAB_H264 preference if
                % one doesn't exist
                initH264pref(obj);

                % Trim URL. We should ignore any whitespace from the front
                % and rear of url
                url = strtrim(char(url));

                % Validate URL
                ipcamera.internal.Utility.validateURL(url);

                % Check if the input URL is HTTP or RTSP
                urlType = ipcamera.internal.Utility.checkURL(url);

                % Assign input arguments to ipcam properties
                obj.URL = url;
                username = char(username);
                obj.Username = username;
                password = char(password);
                obj.Password = password;
                obj.Timeout = options.Timeout;
                obj.URLType = urlType;

                if nargin == 2
                    % Either Username or Password is missing.
                    ipcamera.internal.Utility.localizedError('MATLAB:ipcamera:ipcam:invalidInputArgs');
                end

                % Getting video compression format as both MJPEG and H264
                % is supported over RTSP
                if (strcmpi(urlType,"RTSP"))

                    % Creating string array to pass username, password
                    % and url of the IP Camera to MEX file
                    credentials = string(username)+":"+string(password);
                    URL = string(url);
                    connectionInfo = [credentials, URL];
                    % Calling MEX file to get compression format. If the
                    % compression format is found the errorFlag is set to
                    % 0. If the errorFlag is 1 there is a connection error.
                    % If there is an unsopported authentication type that is
                    % showm with errorFlag set to 2. At last If the error flag is 
                    % set to 3, there is an authentication error.
                    [errorFlag, obj.CompressionFormat, obj.AuthenticationType] = ...
                        extractsessioninfomex(connectionInfo);
                    % Compression format is returned as empty for unsupported
                    % authentication type or incorrect credential error
                    if(isempty(obj.CompressionFormat))
                        obj.CompressionFormat = "NA";
                    end
                    % Cases to deal with different error conditions
                    switch errorFlag

                            % Compression format returned is not H264/MJPEG
                        case ipcamera.internal.ErrorFlagEnum.UnsupportedFormat
                            ipcamera.internal.Utility.localizedError...
                                ('MATLAB:ipcamera:ipcam:unsupportedFormatType',obj.CompressionFormat);

                            % If there is a connection error present.
                        case ipcamera.internal.ErrorFlagEnum.ConnectionError
                            ipcamera.internal.Utility.localizedError...
                                ('MATLAB:ipcamera:ipcam:cannotConnect');

                        case ipcamera.internal.ErrorFlagEnum.IncorrectCredentials
                            % Incorrect username or password
                                ipcamera.internal.Utility.localizedError...
                                    ('MATLAB:ipcamera:ipcam:incorrectCredentials');
                        case ipcamera.internal.ErrorFlagEnum.UnsupportedAuthentication
                            % If the authenticationType is not set to Basic, Digest or Digest/Basic
                            ipcamera.internal.Utility.localizedError...
                                ('MATLAB:ipcamera:ipcam:unsupportedAuthentication', obj.AuthenticationType);
                    end
                else
                    % Only MJPEG is supported for HTTP stream.
                    obj.CompressionFormat = "MJPEG";
                end

                % creating controller
                obj.Controller = ipcamera.internal.IpcamController(url, ...
                    username, ...
                    password, obj.CompressionFormat);
                obj.Controller.open();

                % checking for availability of 2 or more frames
                ipcamera.internal.IpcamController.DataAvailable( ...
                    obj.Controller, obj.Timeout);

                % H.264 RTSP stream and decoding using OpenH264 library is enabled
                if (strcmpi(obj.CompressionFormat,"H264") && ~getpref('MATLAB_H264', 'Status'))
                    ipcamera.internal.Utility.localizedError('MATLAB:ipcamera:ipcam:h264Disabled');
                end

                obj.PreviewController = ipcamera.internal.PreviewController(url,obj.Controller);
                
            catch e
                integrateErrorKey(obj, e.identifier);
                throwAsCaller(e)
            end
        end

        function hImage = preview(obj, varargin)
            try
                if (isa(obj,'ipcam') && isvalid(obj))
                    % Initialize clean up function
                    c = onCleanup(@() integrateData(obj,varargin));
                end
                % Invalid number of input arguments.
                narginchk(1, 2);
            
                % Type checking if image handle was passed in.
                if (nargin==2)
                    imHandle = varargin{1};
                    validateattributes(imHandle, {'matlab.graphics.primitive.Image'}, {'scalar'}, 'preview', 'Image Handle', 2)
                    if ~isvalid(imHandle)
                        ipcamera.internal.Utility.localizedError('MATLAB:ipcamera:ipcam:invalidImageHandle');
                    end
                end
            
                imHandle = obj.PreviewController.preview(obj.getWidth(),obj.getHeight(),varargin);
            catch e
                if (isa(obj,'ipcam') && isvalid(obj))
                    integrateErrorKey(obj, e.identifier);
                end
                throwAsCaller(e)
            end
            
            % Assign output only if requested.
            if(nargout > 0)
                hImage = imHandle;
            end
        end
        
        function closePreview(obj)
            % CLOSEPREVIEW(OBJ) closes the live preview window for IPcamera
            % object, OBJ.
            %
            % See also preview.

            try
                % Initialize clean up function
                if isvalid(obj)
                    c = onCleanup(@() integrateData(obj));
                end
                obj.PreviewController.closePreview();
            catch e
                if isvalid(obj)
                    integrateErrorKey(obj, e.identifier);
                end
                throwAsCaller(e);
            end
        end
        
        
        function [ frame, elapsedTime] = snapshot(obj)
            try
                if isvalid(obj)
                    % Initialize clean up function
                    c = onCleanup(@() integrateData(obj));
                end
                [ frame, elapsedTime] = snapshot(obj.Controller, obj.Timeout);
            catch e
                if isvalid(obj)
                    integrateErrorKey(obj, e.identifier);
                end
                throwAsCaller(e)
            end
        end
        
        function delete(obj)
            try
                if (~isempty(obj.Controller)&& isvalid(obj.Controller))
                    obj.Controller.delete();
                    obj.Controller = [];
                end
                if (~isempty(obj.PreviewController)&& isvalid(obj.PreviewController))
                    obj.PreviewController.delete();
                    obj.PreviewController = [];
                end
            catch excep
                throwAsCaller(excep);
            end
        end
        
        
    end
    
    methods
        
        function password = get.Password(obj)
            % Password is returned as a string containing '*'. However, the
            % object stores the value of the Password property as plain
            % text.
            standardPasswordLength = 6;
            if ~isempty(obj.Password)
                password = repmat('*',1,standardPasswordLength);
            else
                password = '';
            end
        end
        
        function set.Timeout(obj,value)
            try
                % Initialize clean up function
                functionStack = dbstack('-completenames');
                functionStackNames = {functionStack(:).name};
                % Register cleanup only if this function is called directly
                if isvalid(obj) && (length(functionStackNames) == 1 ...
                    || ~(matches(functionStackNames{2}, ...
                    ipcamera.internal.DataUtilityConstants.APIsToLog)))
                    c = onCleanup(@() integrateData(obj,'Timeout', value));
                end
                obj.Timeout = value;
            catch excep
                if isvalid(obj)
                    integrateErrorKey(obj, excep.identifier);
                end
                throwAsCaller(excep);
            end
        end  
    end
    
    methods (Hidden)
        
        function closepreview(~)
            try
                ipcamera.internal.Utility.localizedError('MATLAB:ipcamera:ipcam:invalidClosePreview');
            catch e
                correction = matlab.lang.correction.ReplaceIdentifierCorrection('closepreview', 'closePreview');
                e = e.addCorrection(correction);
                throwAsCaller(e);
            end
        end
        
        function c = horzcat(varargin)
            %HORZCAT Horizontal concatenation of ipcam objects.
            if (nargin == 1)
                c = varargin{1};
            else
                ipcamera.internal.Utility.localizedError('MATLAB:ipcamera:ipcam:noconcatenation');
            end
        end
        
        function c = vertcat(varargin)
            %VERTCAT Vertical concatenation of ipcam objects.
            
            if (nargin == 1)
                c = varargin{1};
            else
                ipcamera.internal.Utility.localizedError('MATLAB:ipcamera:ipcam:noconcatenation');
            end
        end
        
        function c = cat(varargin)
            %CAT Concatenation of ipcam objects.
            if (nargin > 2)
                ipcamera.internal.Utility.localizedError('MATLAB:ipcamera:ipcam:noconcatenation');
            else
                c = varargin{2};
            end
        end
        
        % Hidden methods from the handle super class.
        function res = eq(obj, varargin)
            res = eq@handle(obj, varargin{:});
        end
        
        function res =  fieldnames(obj, varargin)
            res = fieldnames@handle(obj,varargin{:});
        end
        
        function res = ge(obj, varargin)
            res = ge@handle(obj, varargin{:});
        end
        
        function res = gt(obj, varargin)
            res = gt@handle(obj, varargin{:});
        end
        
        function res = le(obj, varargin)
            res = le@handle(obj, varargin{:});
        end
        
        function res = lt(obj, varargin)
            res = lt@handle(obj, varargin{:});
        end
        
        function res = ne(obj, varargin)
            res = ne@handle(obj, varargin{:});
        end
        
        function res = findobj(obj, varargin)
            res = findobj@handle(obj, varargin{:});
        end
        
        function res = findprop(obj, varargin)
            res = findprop@handle(obj, varargin{:});
        end
        
        function res = addlistener(obj, varargin)
            res = addlistener@handle(obj, varargin{:});
        end
        
        function res = notify(obj, varargin)
            res = notify@handle(obj, varargin{:});
        end
        
        function getdisp(obj, varargin)
            getdisp@handle(obj, varargin{:});
        end
        
        function setdisp(obj, varargin)
            setdisp@handle(obj, varargin{:});
        end
    end
    
    % Helper methods to get width and height
    methods( Access = private)
        function width = getWidth(obj)
            waitTime = tic;
            img = getCurrentPreviewFrame(obj.Controller);
            while(isempty(img) && toc(waitTime) < obj.Timeout)
                img = getCurrentPreviewFrame(obj.Controller);
            end
            width  = size(img,2);
        end
        
        function height = getHeight(obj)
            waitTime = tic;
            img = getCurrentPreviewFrame(obj.Controller);
            while(isempty(img) && toc(waitTime) < obj.Timeout)
                img = getCurrentPreviewFrame(obj.Controller);
            end
            height  = size(img,1);
        end
        
        function initH264pref(~)
            % Function to check if H.264 support is enabled/disabled
            % Create a new preference, if one does not exist
            if(~ispref('MATLAB_H264', 'Status'))
                addpref('MATLAB_H264', 'Status', true);
            end
        end
    end
    properties ( Hidden, Access = private)
        Controller;
        PreviewController;
    end
end
